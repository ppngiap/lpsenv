/* 
* (C) Copyright 2000-2004 by Kivera, Inc.  All rights reserved. >>./client/examples/source/kiv_clearAll_poi_ex.c.new
echo * 
* This material is protected by U.S. and international 
* copyright laws and may not be reproduced, modified, 
* distributed, publicly displayed or used to create derivative 
* works without the express written consent of Kivera, Inc.  
* The information contained herein is considered a trade 
* secret as defined in section 499C of the penal code of the 
* State of California. This copyright notice may not be 
* altered or removed. 
* 
*/ 
/******************************************************
 * File: kiv_clearAll_poi_ex.c                        *
 * -------------------------------------------------- *
 * Description:  An example program for exhibiting    *
 *               proper usage of the                  *
 *               kiv_clearAllPoiData function for     *
 *               deleting all pois belonging to a     *
 *               particular vendor and category       *
 *               in the dynamic pois database.        *
 ******************************************************/

/******************************************************
 *Library Includes                                    *
 ******************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "capis.h"
#include "iso_codes.h"

#ifdef _MSC_VER
#include "win_getopt.h"
#include "WinSock2.h"
#endif

#ifdef LINUX
#include <unistd.h>
#endif


/******************************************************
 * Constant Definitions
 ******************************************************/

/******************************************************
 * Utility function prototypes
 ******************************************************/
/* gets host and port from command-line arguments */
int get_host_and_port(int argc, char *argv[], char **host, int * port);


/******************************************************
 * Poi clearAll example function prototypes
 ******************************************************/

/* Demonstrates the use of clearAll API */
int poi_clearAll( NWC_CLIENT *handle, POI_CLEARALL_REQ *req );


/******************************************************
 * Main program
 ******************************************************/
int main(int argc, char *argv[]) 
{

    /******************************************************
     * Declarations
     ******************************************************/
    int status = NW_OK;                   /* function return status */

    char *host                   = NULL;  /* host on which server is running */
    int   port                   = 0;     /* port on which server running */
    NWC_CLIENT *handle           = NULL;  /* server connection handle */

	POI_CLEARALL_REQ poiClearAllReq;      /* the clearAll request */

    /**********************************************************************
     * Initialize structures
     **********************************************************************/
    memset(&poiClearAllReq, 0, sizeof(POI_CLEARALL_REQ));

    /**********************************************************************
     * Get host and port command line arguments
     **********************************************************************/
    if (get_host_and_port(argc, argv, &host, &port) == FALSE)
        exit(0);

    /**********************************************************************
     * Initialize client options
     **********************************************************************/
    handle = nwc_init_client_option(UNPROJECTED);

    if ( NULL == handle )
    {
        printf("Error initializing client options\n");
        exit( 1 );
    }

    /**********************************************************************
     * Connect to location server
     **********************************************************************/
    status = nwc_connect(handle, host, (u_short)port);

    if (status < 0)
    {
        printf("Error connecting to server, status = %d\n", status);
        exit( 1 );
    }

    
    /**********************************************************************
     * poi clearAll example
     **********************************************************************/
    printf("\n\n"
           "==============================================================\n"
           "Poi clearAll example\n"
           "==============================================================\n");

    status = poi_clearAll( handle, &poiClearAllReq);

    
    /* --- Exit Program --- */
    status = nwc_disconnect(handle);

    if (NW_OK != status)
    {
        printf("Error disconnecting from server, status = %d\n", status);
        exit(1);
    }
    
    status = nwc_delete_client_option(handle);

    if (NW_OK != status)
    {
        printf("Error cleaning up client handler, status = %d\n", status);
        exit(1);
    }

    exit ( 0 );
  
}

/******************************************************
 * Print information on how to use this program
 ******************************************************/
void print_usage(char *prog_name)
{
    printf("Usage: %s [-?] -h <host> -p <port>\n"
           "       -? print this message\n"
           "       -h host machine name\n"
           "       -p port number\n\n",
           prog_name);
}

/******************************************************
 * Get host and port command line arguments
 ******************************************************/
int get_host_and_port(int argc, char *argv[], char **host, int * port){

    int helpFlag = FALSE, c;

    while ((c = getopt(argc, argv, "h:p:")) != EOF) {
        switch (c) {
        case 'p':
            /* get the port */
            *port = atoi(optarg);
            break;
        case 'h':
            /* get the host */
            *host = optarg;
            break;
        case '?':
        default:
            /* if unknown argument or "help" flag was specified, turn
             * on the help flag */
            helpFlag = TRUE;
            break;
        }
    }

    /* if host or port was not specified, turn on the help flag */
    if ((*host == NULL) || (*port == 0))
    {
        helpFlag = TRUE;
    }

    if(helpFlag)
    {
        print_usage(argv[0]);
        return FALSE;
    }
    return TRUE;
}


/************************************************************************
 * A poi clearAll example.
 ************************************************************************/
int poi_clearAll(
    NWC_CLIENT *handle,                /* location server handle */
    POI_CLEARALL_REQ   *poi_clr_req    /* poi clearAll request */
    )
{
    int    status = 0;                 /* for checking error returns */
    char dateTimeStamp[16];

    if ( (NULL == poi_clr_req) )
    {
        printf("Error in parameters to poi_clearAll\n");
        return -1;
    }


	/**********************************************************************
	 * Populate the poi clearAll request
	 **********************************************************************/
	 poi_clr_req->clientId  = 911;        /* Unique id identifying the client*/
         sprintf(dateTimeStamp, "%ld", time(0));
         strcpy(poi_clr_req->dateTimeStamp , dateTimeStamp);

	 poi_clr_req->vendorId  = 911;        /* the vendor id */
	 poi_clr_req->categoryId= 1200;       /* category id */

    
    /*********************************************************************
     * Call clearAll API
     *********************************************************************/
    status = kiv_clearAllPoiData( handle, poi_clr_req);

    if (status < 0)
    {
        printf("poi_clearAll failed, status = %d\n", status);
        return status;
    }
    else
    {
        printf("poi_clearAll successful, status = %d\n", status);
        return status;
    }

    return NW_OK;
}
