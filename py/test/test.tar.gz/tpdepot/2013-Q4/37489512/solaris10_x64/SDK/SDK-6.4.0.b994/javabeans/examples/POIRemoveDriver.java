/*
 * � 2001, Kivera, Inc.  This material is protected by U.S. and international
 * copyright laws and may not be reproduced, modified, distributed, publicly
 * displayed or used to create derivative works without the express written
 * consent of Kivera, Inc.  This copyright notice may not be altered or
 * removed.
 *
 */

//package com.kivera.kle;

import java.lang.*;
import java.io.*;
import java.util.*;
import java.beans.*;
import com.kivera.klc.*;
import com.kivera.klc.poi.*;
import java.awt.event.*;

/**
 * This driver class demonstrates how to delete a POI into the dynamic
 * poi database.
 * This driver makes use of Kivera's client beans package to access the Kivera
 * Location Engine.
 * It reads the client Id, vendor Id and POI Id values from the
 * poiRemoveData.properties file and deletes the poi having these values.
 *
 * @version 1.0
 */
public class POIRemoveDriver
{

	public static void main(String [] args) 
	{

		// Get the host and port from command line
		int intCounter = 0;
		int intPort    = 0;
		char parm      = '?';
		String strHost = "";

		for(intCounter=0;intCounter<args.length;intCounter++)
		{
			if (args[intCounter].charAt(0)=='-')
			{
				parm = Character.toLowerCase(args[intCounter].charAt(1));
			}
			switch(parm)
			{
				case 'h':
				    strHost = args[++intCounter];
				    break;
				case 'p':
				    intPort = Integer.parseInt(args[++intCounter]);
				    break;
				default:
				    showUsage();
				    break;
			}
		}
		if(strHost==null||strHost.equals("")||intPort<=0)
			showUsage();


		try
		{
			// Obtain the RequestProcessor object which is connected to the
			// KLE at the port and host input.

			RequestProcessor processor     = getProcessor(strHost, intPort);


			KivPOIManageBean manageBean = new KivPOIManageBean();
			manageBean.addRequestListener(processor);

			// Pick up the id values of the poi from the data file
			readPoiIds();


			int status = 0;
			// Set the necessary input fields in the bean
			if(POIRemoveDriver.clientId != -2147483648 && POIRemoveDriver.vendorId != -2147483648 &&
			   POIRemoveDriver.poiId != -2147483648)
			{
				KivPOIKey key = new KivPOIKey();
				key.setId(POIRemoveDriver.poiId);
				key.setVendorId(POIRemoveDriver.vendorId);

				status = manageBean.doDelete(key,
											 POIRemoveDriver.clientId,
											 POIRemoveDriver.poiDateTime);
			}
			else
			{
				throw new Exception("Could not obtain PoiId, VendorId or ClientId of poi from data file.");
			}

			// Check the result

			if(status < 0)
			{
				System.out.println("\n");
				System.out.println("The delete operation failed with status:" + status);
				System.out.println("\n");
			}
			else
			{
				System.out.println("\n");
				System.out.println("The delete operation was successful. Status = " + status + "\n");
				System.out.println("The id of the POI deleted is :: " + POIRemoveDriver.poiId);
				System.out.println("\n");
			}

		}
		catch(Exception e)
		{
			System.out.println("\n");
			System.out.println("Exception resolving bean\n");
			e.printStackTrace();
			System.out.println("\n");
		}

	}


	/**
	 * Display executable usage.
	 */
	public static void showUsage()
	{
		System.out.println("usage: " + POIRemoveDriver.class.getName() + " -h <host> -p <port>");
		System.exit(0);
	}

	private static RequestProcessor getProcessor(String strHost, int intPort)
	{
		RequestProcessor processor = new RequestProcessor();
		processor.setHost(strHost);
		processor.setPort(intPort);
		processor.setProjection(new NoProjection());

		// Connect to the KLE
		processor.setStatus(Constants.CLIENT_STATUS_CONNECTED);

		return processor;
	}


	/**
	 * This method picks up the "id" values of the poi to be deleted
	 * from the "poiRemoveData.properties" file
	 *
	 */
	private static void readPoiIds()
	{
		// Reading the poi data from the poiRemoveData.properties file
		java.util.Locale theLocale = new java.util.Locale("en", "");
		PropertyResourceBundle poiRemoveDataBundle = 
			(PropertyResourceBundle)ResourceBundle.getBundle("poiRemoveData", theLocale);

		String strTemp           = null;

		// Id of the POI which needs to be deleted.

		strTemp                  = poiRemoveDataBundle.getString("clientId");
		POIRemoveDriver.clientId = getIntValue(strTemp);

		// We don't pick up the date from the data file
		String format            = "MM.dd.yyyy hh:mm";
		java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat(format);
		POIRemoveDriver.poiDateTime    = sdf.format(new Date());

		 strTemp                 = poiRemoveDataBundle.getString("poiKey-vendorId");
		POIRemoveDriver.vendorId = getIntValue(strTemp);

		 strTemp                 = poiRemoveDataBundle.getString("poiKey-poiId");
		POIRemoveDriver.poiId    = getIntValue(strTemp);

	}


	private static int getIntValue(String strValue)
	{
		int intValue = 0;

		try
		{
			intValue = Integer.parseInt(strValue);
		}
		catch(NumberFormatException e)
		{
			intValue = 0;
		}
		return intValue;
	}
	
	private static int poiId    = -2147483648; 
	private static int vendorId = -2147483648; 
	private static int clientId = -2147483648; 
	private static String poiDateTime = null;
}
