#!/bin/sh

DEFAULT_INSTALLATION_PATH="/TCS/local/tomcat/webapps/xml"
DEFAULT_KLS_HOST_NAME="localhost"
DEFAULT_IMAGE_HOST_NAME="localhost"
DEFAULT_IMAGE_PORT_NUMBER=80
DEFAULT_KLS_PORT_NUMBER=30200
DEFAULT_KIVERA_BEANS_JAR="../javabeans/klc/KiveraBeans.jar"
DEFAULT_DTD_HOST_NAME="localhost"
DEFAULT_DTD_URL_PATH="http://$DEFAULT_DTD_HOST_NAME/xml/dtd/"
DEFAULT_DTD_RELATIVE_PATH="dtd/"
DEFAULT_CID=10
DEFAULT_COUNTRY_NAME='USA'
DEFAULT_MAX_POIS=25
DEFAULT_OFFSET_X=0
DEFAULT_OFFSET_Y=0
DEFAULT_FORMAT=1
DEFAULT_GRAY=0
DEFAULT_VALIDATION_FILE='WEB-INF/validator-tcs.xml'

# Check to see that all these directories are present. Proceed if and only if
# that is the case
if [ ! -d dtd -o ! -d jar -o ! -d jsp -o ! -d setup ]
then
	echo "All directories for install not present. Please check distribution"
	exit 99
fi

# Shud make this a function later if someone changes this file, please do so
echo "Enter the webapps directory[$DEFAULT_INSTALLATION_PATH] :\c"
read installationPath
if [ -z "$installationPath" ]
then
	installationPath="$DEFAULT_INSTALLATION_PATH"
fi

if [ ! -d $installationPath ]
then
	yesNo="n"
	echo "Webapps directory does not exist. Do you want me to create it[y] \c"
	while [ "$yesNo" != "y" -a "$yesNo" != "Y" ]
	do
		read yesNo
		if [ -z "$yesNo" ]
		then
			yesNo="y"		
		fi
		if [ "$yesNo" = "n" -o "$yesNo" = "N" ]
		then
			echo "Exiting install...."
			exit 100
		fi
		if [ "$yesNo" != "y" -a "$yesNo" != "Y" ]
		then
			echo "Invalid option....please enter y/n\c"
		fi
	done
	mkdir $installationPath
	if [ $? -ne 0 ]
	then
		echo "Cant create webapps directory...Check permissions"
		exit 101
	fi
fi

echo "Enter the fully qualified image host name[$DEFAULT_IMAGE_HOST_NAME] :\c"
read imageHostName
if [ -z "$imageHostName" ]
then
	imageHostName="$DEFAULT_IMAGE_HOST_NAME"
fi

echo "Enter the image server port number[$DEFAULT_IMAGE_PORT_NUMBER] :\c"
read imagePortNumber
if [ -z "$imagePortNumber" ]
then
	imagePortNumber="$DEFAULT_IMAGE_PORT_NUMBER"
fi

echo "Enter the name of the machine on which XMS is running[$DEFAULT_KLS_HOST_NAME] : \c"
read klsHostName
if [ -z "$klsHostName" ]
then
	klsHostName="$DEFAULT_KLS_HOST_NAME"
fi

echo "Enter the port number for the XMS[$DEFAULT_KLS_PORT_NUMBER] :\c"
read klsPortNumber
if [ -z "$klsPortNumber" ]
then
	klsPortNumber="$DEFAULT_KLS_PORT_NUMBER"
fi

echo "Enter the path for the KiveraBeans.jar[$DEFAULT_KIVERA_BEANS_JAR] :\c"
read kiveraBeansJar
if [ -z "$kiveraBeansJar" ]
then
        kiveraBeansJar="$DEFAULT_KIVERA_BEANS_JAR"
fi

dtdUrlPath="$DEFAULT_DTD_RELATIVE_PATH"
echo "Use relative dtd path?[y] \c"
read relativeDtd
if [ -z "$relativeDtd" ]
then
	relativeDtd="y"
fi
if [ "$relativeDtd" != "y" -a "$relativeDtd" != "Y" ]
then
	echo "Enter the full url path ending with / for the dtd files[$DEFAULT_DTD_URL_PATH] : \c"
	read dtdUrlPath
	if [ -z "$dtdUrlPath" ]
	then
		dtdUrlPath="$DEFAULT_DTD_URL_PATH"
	fi
fi

echo "Enter the customer id for image[$DEFAULT_CID] :\c"
read imageCid
if [ -z "$imageCid" ]
then
        imageCid="$DEFAULT_CID"
fi
echo "Enter the default country name[$DEFAULT_COUNTRY_NAME] : \c"
read countryName
if [ -z "$countryName" ]
then
	countryName="$DEFAULT_COUNTRY_NAME"
fi

echo "Enter the number of max pois[$DEFAULT_MAX_POIS] : \c"
read maxPoisNumber
if [ -z "$maxPoisNumber" ]
then
	maxPoisNumber="$DEFAULT_MAX_POIS"
fi

echo "Enter the value of offset X [$DEFAULT_OFFSET_X] : \c"
read offsetXVal
if [ -z "$offsetXVal" ]
then
	offsetXVal="$DEFAULT_OFFSET_X"
fi
echo "Enter the value of offset Y [$DEFAULT_OFFSET_Y] : \c"
read offsetYVal
if [ -z "$offsetYVal" ]
then
	offsetYVal="$DEFAULT_OFFSET_Y"
fi

echo "Enter the value of format [$DEFAULT_FORMAT] : \c"
read formatVal
if [ -z "$formatVal" ]
then
	formatVal="$DEFAULT_FORMAT"
fi

echo "Enter the value of gray [$DEFAULT_GRAY] : \c"
read grayVal
if [ -z "$grayVal" ]
then
	grayVal="$DEFAULT_GRAY"
fi

echo "Enter the Validation file path for validation file [$DEFAULT_VALIDATION_FILE] :\c"
read validationFilePath
if [ -z "$validationFilePath" ]
then
        validationFilePath="$DEFAULT_VALIDATION_FILE"
fi


# Create the directory structure
mkdir -p $installationPath/dtd
mkdir -p $installationPath/xslt
mkdir -p $installationPath/mapping
mkdir -p $installationPath/WEB-INF/lib
mkdir -p $installationPath/WEB-INF/classes
sed -e "s/localhost/$klsHostName/g" -e "s/10200/$klsPortNumber/g" -e "s/imagehost/$imageHostName/g" -e "s/imageport/$imagePortNumber/g" -e "s~%%DTD_URL_PATH%%~$dtdUrlPath~g" -e "s/%%COUNTRY%%/$countryName/g" -e "s/%%MAXPOIS%%/$maxPoisNumber/g" -e "s/%%CID%%/$imageCid/g" -e "s/%%OFFSETX%%/$offsetXVal/g" -e "s/%%OFFSETY%%/$offsetYVal/g" -e "s/%%FORMAT%%/$formatVal/g" -e "s/%%GRAY%%/$grayVal/g" -e "s~%%VALIDATION_FILE%%~$validationFilePath~g" setup/web.xml >$installationPath/WEB-INF/web.xml

cp jsp/* $installationPath
cp xslt/* $installationPath/xslt
cp mapping/* $installationPath/mapping
cp jar/* $installationPath/WEB-INF/lib
cp setup/log4j.properties $installationPath/WEB-INF/classes
cp $kiveraBeansJar $installationPath/WEB-INF/lib
cp setup/validator-denso.xml $installationPath/WEB-INF
cp setup/validator-tcs.xml $installationPath/WEB-INF

if [ "$relativeDtd" = "y" -o "$relativeDtd" = "Y" ]
then
	dtdUrlPath=""
fi
cd dtd
for file in *
do	
sed -e "s~%%DTD_URL_PATH%%~$dtdUrlPath~g" $file >$installationPath/dtd/$file
done

echo "Install done"

