#ifndef IMP_REVGEO_DEF_H
#define IMP_REVGEO_DEF_H

/**
 * The reverse geocoding definitions.
 *
 * @file  nw_imp_revgeo.h
 *
 * � 200, Kivera, Inc.  This material is protected by U.S. and
 * international copyright laws and may not be reproduced, modified,
 * distributed, publicly displayed or used to create derivative works
 * without the express written consent of Kivera, Inc.  This copyright
 * notice may not be altered or removed.
 **/

#include "geostd_def.h"

#define NW_INTER_REGULAR         0 /* regular intersection - street and street*/
#define NW_INTER_RAMP_STREET     1 /* traversing a ramp and intersecting either HW or street */
#define NW_INTER_RAMP_RAMP       2 /* ramp with another ramp */
#define NW_INTER_STREET_OFF_RAMP 3 /* on a HW/street  and intersectionf off ramp */
#define NW_INTER_STREET_ON_RAMP  4 /* on a HW/street  and intersectionf on ramp */
#define NW_INTER_REFSTREETENDS   5 /* reference street ends in this intersection */
#define NW_INTER_CROSSSTREETENDS 6 /* cross street ends in the reference street */

typedef struct
{
    int world_long;
    int world_lat;
    int distance;
    char unit;
    int mapDbPref;
    unsigned char lang[NW_LINE_MAX];
    unsigned char partial_street_name[NW_LINE_MAX];
    int count;
    char output_strt_flags;
} STREETS_REVGEO_REQ;


/** street info in component form with addition info
 *  src_id, artery level and name_id
 */

typedef struct
{
    unsigned char house_number[2*NW_ADDRESS_SIZE];   
    unsigned char street_name[NW_STREET_SIZE];
    unsigned char city[NW_CITY_SIZE];
    // state (USA) or province (CAN)
    unsigned char admin1[NW_STATE_SIZE];
    // region; e.g. county in USA; i.e. line3 in GEO_REQ
    unsigned char admin2[NW_LINE_MAX];
    unsigned char postal_code[NW_ZIP_SIZE];
    unsigned char country[NW_COUNTRY_SIZE];
    STREET streetnames;   // Componentized street name
    int src_id;
    int artery_level;
    double distance; /* distance from teh point */
    int type;
    int speed;
} STREET_INFO;

/**
 * Output from streets rev geo request
 */
typedef struct
{
    int status;
    int num_streets;
    STREET_INFO *street_list;  /*sorted list of streets               */
    RT_POINT *rt_points;       /*closest point on each street in the above list */
} STREETS_REVGEO_INFO;


typedef struct
{
    STREET_INFO street; /* street picked by the user from a list of streets */
    RT_POINT rt_point;  /* closest point on the above street */
    int distance;       /* search radius */
    int count;          /* limit on num of streets to bring back */
    char unit;
    unsigned char lang[NW_LINE_MAX];        
} INTERSECTIONS_REVGEO_REQ;


typedef struct
{
    char    street[NW_LINE_MAX];   /* closest street */
    char    xstreet[NW_LINE_MAX];  /* cross street with the street */
    STREET  streetnames;           /* Componentized street names */
    STREET  xstreetnames;          /* Componentized street names */
    double  distance;              /* distance of the intersection from the point on the street */
    int     type;                  /* intersection type see #define NW_INTER_ */
    char    relative_dir;          /* intersection relative direction */
} INTERSECTION;


/**
 * Output from intersections rev geo request
 */

typedef struct
{
    int status;
    int num_intersections;
    INTERSECTION *inter_list;/* list of intersections */
    RT_POINT      *rt_point;  /* list of points corresponding to intersections */   
} INTERSECTIONS_REVGEO_INFO;

#endif
