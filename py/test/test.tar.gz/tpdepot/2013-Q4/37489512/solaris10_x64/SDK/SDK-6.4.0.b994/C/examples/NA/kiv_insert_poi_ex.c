/* 
* (C) Copyright 2000-2004 by Kivera, Inc.  All rights reserved. >>./client/examples/source/kiv_insert_poi_ex.c.new
echo * 
* This material is protected by U.S. and international 
* copyright laws and may not be reproduced, modified, 
* distributed, publicly displayed or used to create derivative 
* works without the express written consent of Kivera, Inc.  
* The information contained herein is considered a trade 
* secret as defined in section 499C of the penal code of the 
* State of California. This copyright notice may not be 
* altered or removed. 
* 
*/ 
/******************************************************
 * File: kiv_insert_poi_ex.c                          *
 * -------------------------------------------------- *
 * Description:  An example program for exhibiting    *
 *               proper usage of the                  *
 *               kiv_managePoiData function for       *
 *               inserting pois in the                *
 *               dynamic pois database      .         *
 ******************************************************/

/******************************************************
 *Library Includes                                    *
 ******************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "capis.h"
#include "iso_codes.h"

#ifdef _MSC_VER
#include "win_getopt.h"
#include "WinSock2.h"
#endif

#ifdef LINUX
#include <unistd.h>
#endif
/******************************************************
 * Constant Definitions
 ******************************************************/

/******************************************************
 * Utility function prototypes
 ******************************************************/
/* gets host and port from command-line arguments */
int get_host_and_port(int argc, char *argv[], char **host, int * port);


/* prints information about  a poi */
void dump_poi(POI_EDIT_STRUCT *poi );



/******************************************************
 * Poi insert example function prototypes
 ******************************************************/

/* Demonstrates the use of insert API */
int poi_insert( NWC_CLIENT *handle, POI_MANAGE_REQ *req );

int poi_create( POI_EDIT_STRUCT *poi );

/******************************************************
 * Main program
 ******************************************************/
int main(int argc, char *argv[]) 
{

    /******************************************************
     * Declarations
     ******************************************************/
    int status = NW_OK;                   /* function return status */

    char *host                   = NULL;  /* host on which server is running */
    int   port                   = 0;     /* port on which server running */
    NWC_CLIENT *handle           = NULL;  /* server connection handle */

	POI_MANAGE_REQ poiManageReq;          /* the manage request */

    /**********************************************************************
     * Initialize structures
     **********************************************************************/
    memset(&poiManageReq, 0, sizeof(POI_MANAGE_REQ));

    /**********************************************************************
     * Get host and port command line arguments
     **********************************************************************/
    if (get_host_and_port(argc, argv, &host, &port) == FALSE)
        exit(0);

    /**********************************************************************
     * Initialize client options
     **********************************************************************/
    handle = nwc_init_client_option(UNPROJECTED);

    if ( NULL == handle )
    {
        printf("Error initializing client options\n");
        exit( 1 );
    }

    /**********************************************************************
     * Connect to location server
     **********************************************************************/
    status = nwc_connect(handle, host, (u_short)port);

    if (status < 0)
    {
        printf("Error connecting to server, status = %d\n", status);
        exit( 1 );
    }

    
    /**********************************************************************
     * poi insert example
     **********************************************************************/
    printf("\n\n"
           "==============================================================\n"
           "Poi insert example\n"
           "==============================================================\n");
    status = poi_insert( handle, &poiManageReq);

    
    /* --- Exit Program --- */
    status = nwc_disconnect(handle);

    if (NW_OK != status)
    {
        printf("Error disconnecting from server, status = %d\n", status);
        exit(1);
    }
    
    status = nwc_delete_client_option(handle);

    if (NW_OK != status)
    {
        printf("Error cleaning up client handler, status = %d\n", status);
        exit(1);
    }

    exit ( 0 );
  
}

/******************************************************
 * Print information on how to use this program
 ******************************************************/
void print_usage(char *prog_name)
{
    printf("Usage: %s [-?] -h <host> -p <port>\n"
           "       -? print this message\n"
           "       -h host machine name\n"
           "       -p port number\n\n",
           prog_name);
}

/******************************************************
 * Get host and port command line arguments
 ******************************************************/
int get_host_and_port(int argc, char *argv[], char **host, int * port){

    int helpFlag = FALSE, c;

    while ((c = getopt(argc, argv, "h:p:")) != EOF) {
        switch (c) {
        case 'p':
            /* get the port */
            *port = atoi(optarg);
            break;
        case 'h':
            /* get the host */
            *host = optarg;
            break;
        case '?':
        default:
            /* if unknown argument or "help" flag was specified, turn
             * on the help flag */
            helpFlag = TRUE;
            break;
        }
    }

    /* if host or port was not specified, turn on the help flag */
    if ((*host == NULL) || (*port == 0))
    {
        helpFlag = TRUE;
    }

    if(helpFlag)
    {
        print_usage(argv[0]);
        return FALSE;
    }
    return TRUE;
}


/************************************************************************
 * Create a poi to insert.
 ************************************************************************/
 int poi_create(POI_EDIT_STRUCT *poi)
 {

    if ( NULL == poi )
    {
        printf("Error in parameters to poi_create\n");
        return -1;
    }

	poi->vendorId       = 3;
	poi->poiId          = 0;
    strcpy(poi->providerPoiId, "Test Provider POI ID");
	poi->numOfNames     = 1;

	/* We will have only one name for the poi. */
	poi->names = (POI_NAME_STRUCT *)malloc(sizeof(POI_NAME_STRUCT));

	strcpy(poi->names[0].name , "Zacheries");
	strcpy(poi->names[0].language , "en");
	poi->names[0].kindOfName = 1;

	strcpy(poi->addr.houseNumber , "300");
	strcpy(poi->addr.streetName , "lakeside drive");
	strcpy(poi->addr.city , "oakland");
	strcpy(poi->addr.admin1 , "california");
	strcpy(poi->addr.admin2 , "");
	strcpy(poi->addr.country , "us");
	strcpy(poi->addr.zip , "94612");

	poi->areaCode       = 510;
	poi->phoneNumber    = 7633300;
	poi->faxAreaCode    = 510;
	poi->faxNumber      = 7633401;
    strcpy(poi->email, "example@kivera.com");
    strcpy(poi->url1, "http://www.kivera.com/example_url1");
    strcpy(poi->url2, "http://www.kivera.com/example_url2");
    strcpy(poi->url3, "http://www.kivera.com/example_url3");
//	poi->latitude       = 24248320;
//	poi->longitude      = -79953920;
	poi->noOfCategories = 1;

	/* the poi belongs to one category. */
	poi->categories     = (int *)malloc(sizeof(int));

	poi->categories[0]  = 300;

	poi->info.vendorId  = 911;      /* should be equal to poi->vendorId */
	poi->info.poiId     = 0;        /* should be equal to poi->poiId */
	poi->info.int1      = 101;
	poi->info.int2      = 102;
	poi->info.int3      = 103;
	poi->info.int4      = 104;
	poi->info.int5      = 105;
	poi->info.int6      = 106;
	poi->info.int7      = 107;
	poi->info.int8      = 108;
	poi->info.int9      = 109;
	poi->info.int10     = 110;
	poi->info.int11     = 111;
	poi->info.int12     = 112;
	poi->info.int13     = 113;
	poi->info.int14     = 114;
	poi->info.int15     = 115;

	strcpy( poi->info.string1 , "text1");
	strcpy( poi->info.string2 , "text2");
	strcpy( poi->info.string3 , "text3");
	strcpy( poi->info.string4 , "text4");
	strcpy( poi->info.string5 , "text5");
	strcpy( poi->info.string6 , "text6");
	strcpy( poi->info.string7 , "text7");
	strcpy( poi->info.string8 , "text8");
	strcpy( poi->info.string9 , "text9");
	strcpy( poi->info.string10 , "text10");
	strcpy( poi->info.string11 , "text11");
	strcpy( poi->info.string12 , "text12");
	strcpy( poi->info.string13 , "text13");
	strcpy( poi->info.string14 , "text14");
	strcpy( poi->info.string15 , "text15");

	strcpy( poi->info.date1 , "08012002");
	strcpy( poi->info.date2 , "08022002");
	strcpy( poi->info.date3 , "08032002");
	strcpy( poi->info.date4 , "08042002");
	strcpy( poi->info.date5 , "08052002");
	strcpy( poi->info.date6 , "08062002");
	strcpy( poi->info.date7 , "08072002");
	strcpy( poi->info.date8 , "08082002");
	strcpy( poi->info.date9 , "08092002");
	strcpy( poi->info.date10 , "08102002");
	strcpy( poi->info.date11 , "08112002");
	strcpy( poi->info.date12 , "08122002");
	strcpy( poi->info.date13 , "08132002");
	strcpy( poi->info.date14 , "08142002");
	strcpy( poi->info.date15 , "08152002");

	strcpy( poi->info.text1 , "Long text column 1.");
	strcpy( poi->info.text2 , "Long text column 2.");
	strcpy( poi->info.text3 , "Long text column 3.");
	strcpy( poi->info.text4 , "Long text column 4.");
	strcpy( poi->info.text5 , "Long text column 5. The beginning. ");
	strcat( poi->info.text5 , "Long text column 5. Long text column 5. ");
	strcat( poi->info.text5 , "Long text column 5. Long text column 5. ");
	strcat( poi->info.text5 , "Long text column 5. Long text column 5. ");
	strcat( poi->info.text5 , "Long text column 5. Long text column 5. ");
	strcat( poi->info.text5 , "Long text column 5. Long text column 5. ");
	strcat( poi->info.text5 , "Long text column 5. Long text column 5. ");
	strcat( poi->info.text5 , "Long text column 5. Long text column 5. ");
	strcat( poi->info.text5 , "Long text column 5. Long text column 5. ");
	strcat( poi->info.text5 , "Long text column 5. Long text column 5. ");
	strcat( poi->info.text5 , "Long text column 5. Long text column 5. ");
	strcat( poi->info.text5 , "Long text column 5. Long text column 5. ");
	strcat( poi->info.text5 , "Long text column 5. Long text column 5. ");
	strcat( poi->info.text5 , "Long text column 5. Long text column 5. ");
	strcat( poi->info.text5 , "Long text column 5. Long text column 5. ");
	strcat( poi->info.text5 , "Long text column 5. Long text column 5. ");
	strcat( poi->info.text5 , "Long text column 5. Long text column 5. ");
	strcat( poi->info.text5 , "Long text column 5. Long text column 5. ");
	strcat( poi->info.text5 , "Long text column 5. Long text column 5. ");
	strcat( poi->info.text5 , "Long text column 5. Long text column 5. ");
	strcat( poi->info.text5 , "Long text column 5. Long text column 5. ");
	strcat( poi->info.text5 , "Long text column 5. The end.");

	poi->info.noOfImage1Bytes   = 0;
	poi->info.image1Store       = NULL;
	poi->info.noOfImage2Bytes   = 0;
	poi->info.image2Store       = NULL;

    return NW_OK;

 }

/******************************************************************
 * Clean up memory allocated on heap by insert poi API
 *****************************************************************/
int cleanup_insert_poi( POI_MANAGE_REQ *insert_poi_req)
{
    int status = NW_OK;

    if ( NULL == insert_poi_req ) 
    {
        printf( "Bad arguments to cleanup_insert_poi\n" );
        return -1;
    }

    status = kiv_freePoiManageReq(insert_poi_req);

    if ( NW_OK != status )
    {
        printf("Error freeing poi insert request\n");
    }

    return status;
}




/************************************************************************
 * A poi insert example.
 ************************************************************************/
int poi_insert(
    NWC_CLIENT *handle,                /* location server handle */
    POI_MANAGE_REQ   *poi_ins_req      /* poi manage request */
    )
{
    char dateTimeStamp[16];
    int    status = 0;                    /* for checking error returns */
	POI_EDIT_STRUCT poi;                  /* the poi to be inserted */

    if ( (NULL == poi_ins_req) )
    {
        printf("Error in parameters to poi_insert\n");
        return -1;
    }


    /*****************************************************************
     * Initialize input structures
     *****************************************************************/
    memset(&poi, 0, sizeof(POI_EDIT_STRUCT));


	/**********************************************************************
	 * Create the poi to insert.
	 **********************************************************************/
	 status = poi_create(&poi);

    if (status < 0)
    {
        printf("Error creating the poi, status = %d\n", status);
        return status;
    }

	/**********************************************************************
	 * Populate the poi manage request
	 **********************************************************************/
	 poi_ins_req->actionFlg = INSERT_POI;
	 poi_ins_req->clientId  = 911;        /* Unique id identifying the client*/
         sprintf(dateTimeStamp, "%ld", time(0));
	 strcpy(poi_ins_req->dateTimeStamp , dateTimeStamp);
	 poi_ins_req->poi       = &poi;

    
    /*********************************************************************
     * Call insert(manage) API
     *********************************************************************/
    status = kiv_managePoiData( handle, poi_ins_req);

    if (status < 0)
    {
        printf("poi_insert failed, status = %d\n", status);
    }
    else
    {
        printf("poi_insert successful, Id of poi inserted = %d\n", status);
    }

    cleanup_insert_poi(poi_ins_req );

    return NW_OK;
}


/**************************************************************************
 * Dump information about the poi which needs to be inserted
 **************************************************************************/
void dump_poi(POI_EDIT_STRUCT *poi)
{
    printf( "POI: vendorId = %d, poiId = %d, numOfNames = %d\n",
            poi->vendorId, poi->poiId, poi->numOfNames );
}
