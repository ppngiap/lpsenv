/* 
* (C) Copyright 2000-2004 by Kivera, Inc.  All rights reserved. >>./client/examples/source/nw_getpoicategorylist_ex.c.new
echo * 
* This material is protected by U.S. and international 
* copyright laws and may not be reproduced, modified, 
* distributed, publicly displayed or used to create derivative 
* works without the express written consent of Kivera, Inc.  
* The information contained herein is considered a trade 
* secret as defined in section 499C of the penal code of the 
* State of California. This copyright notice may not be 
* altered or removed. 
* 
*/ 
/******************************************************
 * File: nw_poi_search_ex.c                           *
 * -------------------------------------------------- *
 * Description:  An example program for exhibiting    *
 *               proper usage of the                  *
 *               nwc_get_poi_category_list function.             *
 ******************************************************/

/* --- Library Includes --- */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "capis.h"
#include "navworks.h"

#define LINE_MAX    2048

#ifdef _MSC_VER
#include "win_getopt.h"
#include <WinSock2.h>
#endif 

#ifdef LINUX
#include <unistd.h>
#endif
 
/******************************************************
 * Print information on how to use this program
 ******************************************************/
void print_usage(char *prog_name)
{
    printf("Usage: %s [-?] -h <host> -p <port>\n"
           "       -? print this message\n"
           "       -h host machine name\n"
           "       -p port number\n\n",
           prog_name);
}

/******************************
* argument handler
******************************/
int get_host_and_port(int argc, char *argv[], char **host, int *port)
{
    int helpFlag = FALSE, c;

    *port = 0;
    *host = NULL;
    if (argc < 3) helpFlag = TRUE;

    /* read input arguments */
    while ((c = getopt(argc, argv, "h:p:?")) != EOF)
    {
        switch (c)
        {
            case 'p':
		    *port = atoi(optarg);
		    break;
            case 'h':
                *host = optarg;
                break;
            case '?':
                helpFlag = TRUE;
                break;
        }
    }

    if ((helpFlag == TRUE) || (*host == NULL) || (*port == 0))
    {
        //printf("syntax: testpoi -h <host> -p <port>\n");
        print_usage(argv[0]);
        return FALSE;
    }

     return TRUE;
}


/*******************************************************************
 * Iinitialization
 */
void initStructures(int argc, char *argv[],     /* input arguments */
                    NWC_CLIENT **c_hndl,        /* client struct */
                    CSF_DB   *csf_db)           /* db struct */
{
    int  port;
    char *host;
    int  status;

    /* read input arguments */
    if (get_host_and_port(argc, argv, &host, &port) == FALSE)
    {
        exit(0);
    }
  
    /* create client handler structure */
    *c_hndl = nwc_init_client_option(UNPROJECTED);
    if (!(*c_hndl))
    {
        printf("Error initializing the client\n");
        exit(1);
    }

    /* --- Connect to the server --- */
    status = nwc_connect(*c_hndl, host, (u_short)port);
    
    /* Check return status of nwc_connect */
    if (status != NW_OK)
    {
        printf("Error connecting to server. Return status: %d\n", status);
        exit(1);
    }

    /* Get the list of databases */
    status = nwc_get_mdb_list(*c_hndl, csf_db);
    
    /* Check return status of nwc_get_mdb_list */
    if (status != NW_OK)
    {
        printf("Error getting the database list. Return status: %d", status);
        exit(1);
    }
}

int callAPIs( POI_CATEGORIES *reply, NWC_CLIENT *handle)
{
    int status;
    POI_SEARCH_REQUEST         request;
    memset(&request, 0, sizeof(POI_CATEGORIES));
    //memset(reply, 0, sizeof(CATEGORIES));
   printf("going to call  nwc_get_poi_category_list\n");
 status = nwc_get_poi_category_list(handle, reply , "en");
  printf("Returned from the call nwc_get_poi_category_list\n");
  
    

    return(status);
}



void displayResults(int status, POI_CATEGORIES *reply, NWC_CLIENT *handle)
{
    int i;
    for(i =0; i < reply->count; i++)
    {
       printf("Name = %s ...", reply->list[i].name);
       printf("Major ID = %d...", reply->list[i].majorId);
       printf("Minor ID = %d...\n", reply->list[i].minorId);
    }
    return;

}

/* Reads input from fin line by line; interpreting each line as a search
 * request command and serving the search command
 */
void poiSearchRequests(NWC_CLIENT *handle, CSF_DB dbList)
{
    POI_CATEGORIES         reply;
    int  dbId = dbList.db[0].id;
    int  status;
    
    dbId = dbList.db[0].id; /* Will use the first database in the db list */

    /************************************************************
     * Getting the list of categories supported by the POI module.
     *************************************************************/
    status = callAPIs( &reply,       /* search response */
                      handle);

    /*************************************************************
     *  Display search results
     *************************************************************/
    displayResults(status, &reply, handle);

    /*************************************************************
     * Free the POI category list reply structure
     *************************************************************/
    nwc_free_poi_category_list(&reply);

    /*************************************************************
     * Free the database list
     *************************************************************/
    nwc_free_mdb_list(&dbList);
}




int main(int argc, char *argv[])
{
    NWC_CLIENT *handle;
    CSF_DB     csf_db;

    initStructures(argc, argv,     /* Input arguments  */
                   &handle,        /* Client handle    */
                   &csf_db);       /* db struct        */
     printf("sucess -- init structure\n");

    poiSearchRequests(handle,      /* Client handle    */
                      csf_db);     /* db struct        */

    /* Disconnect the client */
    nwc_disconnect(handle);
    nwc_delete_client_option(handle);
    
    /* Exit */
    exit(0);
}
