//  Noelle Murata May 2001
//  Kivera, Inc

import gjt.*;
import com.kivera.kls.*;
import com.kivera.map.*;
import java.lang.*;
import java.io.*;


public class HelloKiveraUS
{

  /**********************************************
   * HelloKiveraUS is designed to help you     *
   * connect to the evaluation cell server      *
   * and demonstrate some of it's functionality *
   * If you have any questions about this,      *
   * please e-mail support@kivera.com           *
   **********************************************/
    
  public static void main(String args[])
  {
    /*******************************************
     * Initialize variables                    *
     *******************************************/

    String hostName = "eval30-na.kivera.com";
    int portNumber = 30200;
    int status;
    NWCClient client = null;
    NWCGeoReq geoReq = null;
    NWCGeocode geo = null;
    NWCImageUrl imageURL = null;
    int zoom = 4;
    int height = 400;
    int width = 500;
    int manv_index = 0;
    int offsetx = 0;
    int offsety = 0;
    int cid = 0;
    int format = NWCClient.FORMAT_GIF;
    int gray = 0;
    String base_url = "http://eval30-na.kivera.com";
    double[] poi_world_long = null;
    double[] poi_world_lat = null;
    int[] poi_kind = null;
    NWCRTOut route = null;
    String pointURL = null;

    /*******************************************
     * Try creating a client object and set    *
     * the projection type                     *
     * if fails, throw an exception            *
     *******************************************/
	if(args.length > 0)
	{
		for(int i = 0; i < args.length; i++)
		{
			if(args[i].equals("-h"))
			{
				hostName = args[++i];
			}
			if(args[i].equals("-p"))
			{
				portNumber = Integer.parseInt(args[++i]);
			}
		}
	}

    try
    {
        client = new NWCClient(Projection.UNPROJECTED);
    }
    catch(Exception e) 
    {
        System.out.println("Error in construction NWCClient" +e);
        System.exit(1);
    }

    /*******************************************
     * Connect to the cell server              *
     * if fails, throw an exception            *
     *******************************************/

    status = client.connect(hostName, portNumber);
    if (NWCReturnCode.NW_OK != status)
    {
      System.out.println("Error connecting to " + hostName + " " + status);
      System.exit(1);
    }
    else
    {
      System.out.println("Connecting to host: "+(hostName));
      System.out.println("    On port number: "+(portNumber));
      System.out.println();
      System.out.println("Please use this hostname and port number for your evaluation process.");
      System.out.println();
    }

    /*******************************************
     * Get Map databases and output list       *
     *******************************************/
  
    NWCDatabase[] dbList = client.getMdbList();
    int[] pref = new int[dbList.length];
    for(int i = 0; i < dbList.length; i++)
    { // iterate throught he list and set the database preferences
       pref[i] = dbList[i].id;
    }
    if (null == dbList)
    {  // if the list is empty, print error message and exit
      System.out.println("Error getting databases.  Please contact support@kivera.com");
	  client.disconnect();
      System.exit(1);
    }
    else
    {  // if it isn't, output list to screen
      System.out.println("Getting Map Databases...");
      for (int x=0; x < 2; x++)
      {
        System.out.println("     "+(x+1)+": "+(dbList[x].description));
      }
    }
    int mapDbID = dbList[0].id;
    System.out.println();

    /*******************************************
     * Get POI and output category list        *
     *******************************************/
  
    NWCPoiCategory[] poicat = client.getPoiCategoryList();
    if (poicat == null)
    {
      System.out.println("Error getting POI list.  Please contact support@kivera.com");
    }
    else
    {
      System.out.println("Getting POI Categories...");
      for(int z=0;z<poicat.length;z++)
      {
        System.out.println("     "+(z+1)+": "+ (poicat[z].name));
      }
    }

    /************************************************
     * Set up hard coded lines for geocoding Kivera *
     ************************************************/

    String line1 = "300 Lakeside Drive";
    String line2 = "Oakland, CA 94612";
    int cfield = 0;
    String cline = "";

    /*************************************************
     * Try constructing a geocode object,            *
     * if fails, throw an exception                  *
     *************************************************/

    try
    {
      geoReq = new NWCGeoReq(pref,
                             line1,  // address line 1
                             line2,  // address line 2
                             null,   // address line 3 (n/a)
                             "USA",  // country
                             cline,  // correction line
                             30,     // offset
                             NWCClient.NW_UNIT_FT,   // offset units
                             0,      // flags (n/a)
                             cfield, // correction type
                             10);    // options limit
    }
    catch(Exception e)
    {
      System.out.println("Error constructing NWCGeoReq: " + e);
	  client.disconnect();
      System.exit(1);
    }

    /*************************************************
     * Try to geocode Kivera.                        *
     * if fails, throw an exception                  *
     *************************************************/

    try
    {
      geo = client.geocode(geoReq);
    }
    catch(Exception e)
    {
      System.out.println("Error geocoding: " + e);
	  client.disconnect();
      System.exit(1);
    }
    NWCRTPoint point = geo.rtpoint;

    System.out.println();
    if (NWCReturnCode.NW_OK == geo.status)
    {
      // display found values from database
      /***************************************************
       * note: you can write your own toString method    *
       * in your own NWCGeocode extension                *
       ***************************************************/
      System.out.println("Geocoding Kivera...");
      System.out.println(geo.toString());
    }
    else
    {
      System.out.println("There has been an error in geocoding.  Please send e-mail to support@kivera.com");
	  client.disconnect();
	  return;
    }

    /*************************************************
     * Try create an image URL constructor.          *
     * if fails, throw an exception                  *
     *************************************************/

    try
    {
      imageURL = new NWCImageUrl(zoom, height, width, manv_index,
                 mapDbID, offsetx, offsety, cid, format, gray, base_url, 
                 point, route, poi_world_long, poi_world_lat, poi_kind,
                 NWCISOCodes.KVR_ISO_639_ENGLISH);
    }
    catch(Exception e)
    {
      System.out.println("Error constructing NWCImageUrl: " + e);
    }

    /*************************************************
     * Output URL.                                   *
     *************************************************/

    if (imageURL != null)
    {
      System.out.println("Please copy and paste the following URL into a web browser to test image server:");
      pointURL = client.genPointUrl(imageURL);
      System.out.println(pointURL.toString());
    }

    client.disconnect();
  }
}
