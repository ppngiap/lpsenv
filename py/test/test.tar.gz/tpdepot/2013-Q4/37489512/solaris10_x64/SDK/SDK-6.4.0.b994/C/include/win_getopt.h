/* 
* (C) Copyright 2000-2004 by Kivera, Inc.  All rights reserved. >>./client/API/c/libclient/include/win_getopt.h.new
echo * 
* This material is protected by U.S. and international 
* copyright laws and may not be reproduced, modified, 
* distributed, publicly displayed or used to create derivative 
* works without the express written consent of Kivera, Inc.  
* The information contained herein is considered a trade 
* secret as defined in section 499C of the penal code of the 
* State of California. This copyright notice may not be 
* altered or removed. 
* 
*/ 
/*
 *  getopt - parse command line arguments
 *
 * Synopsis
 *
 *      int getopt(int argc, char **argv, char const *optstring)
 *
*/
#ifndef H_GETOPT
#define H_GETOPT

  /********************/
  /* Global Variables */
  /********************/

  extern char  *optarg; /* Returns the option argument, if it exists */

  extern int   optind;  /* Specify the index of the argument being
                         * processed. The caller is responsible for
                         * setting this to 1 before the first call */

  extern int   opterr;  /* The caller sets this to 0 to inhibit error
                         * messages for unrecognized options and/or
                         * missing option arguments. */

  extern int   optopt;  /* The value returned when an invalid option
                         * is encountered ('?' unless set otherwise) */

  /*************/
  /* functions */
  /*************/

  extern int getopt(int argc, char **argv, char const *optstring);
    /*
     * Parse an array of argc strings contained in argv for options
     * specified in optstring. Options may have arguments associated
     * with them, in which case the argument is assumed to follow
     * the token containing the option. Mandatory options are
     * denoted by a ':' and optional arguments by a '?'. (Optional
     * arguments are an extension to getopt functionality.)
     *
     * getopt returns EPF after the last argument has been processed,
     * and optopt if an invalid option is specified or a mandatory
     * one is missing. In either case, optarg will point to the
     * character generating the error. An error message is displayed
     * on stderr unless opterr is set to 0.
     *
     * Following a call to getopt, optind will contain the index
     * value of the first element of argv that has not been used
     * by the proceeding call(s) to getopt (either as an option or
     * as an option argument).
     */

  /*
   * An example optstring would be "abc:d?e".  This would define the
   * following options:
   *      -a
   *      -b
   *      -c  with a mandatory argument
   *      -d  with an optional argument
   *
   * If the parameters to getopt were as follows
   *      argc = 6
   *      argv[1] = "-adc"
   *      argc[2] = "arg1"
   *      argc[3] = "arg2"
   *      argc[4] = "-b"
   *      argc[5] = "arg3"
   *
   * Subsequent calls of getopt(argc, argv, "abc:d?") would return
   *
   *  getopt(...) = 'a'     optind = 2      optarg = NULL
   *  getopt(...) = 'd'     optind = 3      optarg = "arg1"
   *  getopt(...) = 'c'     optind = 4      optarg = "arg2"
   *  getopt(...) = 'b'     optind = 5      optarg = NULL
   *  getopt(...) = EOF     optind = 5      optarg = NULL
   */
#endif

  

/*
 *  getopt - parse command line arguments
 *
 * Synopsis
 *
 *      int getopt(int argc, char **argv, char const *optstring)
 *
*/



#include <stdio.h>

/********************/
/* Global Variables */
/********************/

char  *optarg  = NULL; /* Returns the option argument, if it exists */

int   optind   = 1;    /* Specify the index of the argument being
                        * processed. The caller is responsible for
                        * setting this to 1 before the first call */

int   opterr   = 1;    /* The caller sets this to 0 to inhibit error
                        * messages for unrecognized options and/or
                        * missing option arguments */

int   optopt   = '?';  /* The value returned when an invalid option
                        * is encountered */

/********************/
/* Static Variables */
/********************/

static char  *nxtchr;  /* Used to resume parsing arguments where
                        * the last call left off; if NULL, advance
                        * to the next argument */

/***********/
/* indxstr */
/***********/

static char * indxstr(const char *str, char chr)
{
  /* Return the position of the char chr in the string str, or
   * zero if the character is not found */
  while ( *str )
  {
    if ( *str == chr )
    {
      return (char *) str;
    }
    str++;
  }
  return 0;
}

/**********/
/* getopt */
/**********/

int getopt(int argc, char **argv, char const *optstring)
{
  char    *matchedopt;

  /* Initialise the option argument */

  optarg = NULL;

  /* If we are not already parsing an argument, get the next argument
   * to be processed */

  if ( !nxtchr || *nxtchr == '\0' )
  {
    /* Check the next available argument -
     * it is not an option flag if... */

    if ( argc <= optind ||          // ... it does not exist!
       argv[optind][0] != '-' ||    // ... it does not begin with '-'
       argv[optind][1] == '\0')     // ... or is exactly '-'
    {
      return EOF;
    }

    /* Get the character to process and consume the argument */

    nxtchr = &(argv[optind][1]);
    optind++;

    /* Check for the special argument '--', which denotes the
     * premature end of the argument list */

    if ( nxtchr[0] == '-' &&
       nxtchr[1] == '\0' )
    {
      return EOF;
    }
  }

  /* Check to determine if the flag is in the option list */

  matchedopt = indxstr(optstring, *nxtchr);
  if ( !matchedopt )
  {
    /* It wasn't found.  Display an error message if required */

    if ( opterr )
    {
      fputs("Invalid option: ", stderr);
      fputc(*nxtchr, stderr);
      fputc('\n', stderr);
    }

    /* Point optarg to the erroneous flag */

    optarg = nxtchr;

    /* Gobble the invalid argument and return the error value */

    nxtchr++;
    return optopt;
  }

  /* Check if the specified option requires an argument */

  if ( matchedopt[1] == ':' )
  {
    /* An argument is mandatory */

    if ( argc <= optind ||
       argv[optind][0] == '-' )
    {
      /* A mandatory argument is missing */

      if ( opterr )
      {
        fputs("Option ", stderr);
        fputc(*nxtchr, stderr);
        fputs(" requires an argument.\n", stderr);
      }

      /* Point optarg to the erroneous flag */

      optarg = nxtchr;

      /* Gobble the invalid argument and return the error value */

      nxtchr++;

      return optopt;
    }

    /* Set the argument and consume it from the list */

    optarg = argv[optind++];

  }
  else if ( matchedopt[1] == '?' )
  {
    /* An argument is optional */

    if ( argc > optind &&
       argv[optind][0] != '-' )
    {
      /* An optional argument is supplied - consume it from the list */

      optarg = argv[optind++];
    }
  }

  /* return the matched option and consume it from the list */

  return *nxtchr++;
}
