/******************************************************* 
 *  Copyright (C) 2000, Kivera Inc.   All rights reserved 
 * 
 *                    nw_errors.h
 * 
 *  Purpose:          Error return codes for core libarary and API functions
 *  Author:           M. Hartfield
 *  Date:             9/14/00
    Updates:          
 *******************************************************/
#ifndef NW_ERRORS_H
#define NW_ERRORS_H

/*
  Error ranges:

  General    :  -1000  to -1999
  I/O        :  -2000  to -2999
  RevGeocode :  -4000  to -4999
  Geocoding  :  -5000  to -5999
  Routing    :  -6000  to -6999
  Explication:  -7000  to -7999
  Data       :  -8000  to -8999
  POI        :  -9000  to -9999

  Client side: -20000 to -20100
*/

/* General errors */
#define NW_OK            	   0
#define NW_ERROR_MAPDBID 	   -1101    /* bad map database id */
#define NW_ERROR_INIT    	   -1102
#define NW_ERROR_LOGIC   	   -1103    /* Unexpected error - program logic flawed */
#define NW_ERROR_MALLOC  	   -1104    /* malloc/alloc/calloc failed */
#define NW_ERROR_CORRUPT 	   -1105    /* corrupt data */
#define NW_ERROR_EXCLUSIVE_FLAGS   -1106 // mutually exclusive flags

/* I/O errors */
#define NW_ERROR_OPEN    -2011
#define NW_ERROR_WRITE   -2021

#define NW_ERROR_LL      -3011	/* invalid lat/long */
#define NW_ERROR_PARSE   -3021	/* invalid zip entered */
#define NW_ERROR_NOLINK  -4011	/* no link found in rev geocode */

/**
 * Geocoding errors may be "or"d together with the exception of 
 * NW_ERROR_GEOCODE. An error means that the "exact" match cannot be found.
 * There may be no matches or multiple "close" matches. Each close match
 * will have its own error. 
 * NOTE: NW_ERROR_STREET_BASE - NW_ERROR_STREET_SUF and NW_ERROR_CROSS_BASE -
 * NW_ERROR_CROSS_SU are given instead of NW_ERROR_STREET and NW_ERROR_CROSS,
 * respectively, if the detailed flag is on, e.g. for QA or batch.
 *
 * Geocoding errors in order of severity. IMPORTANT!
 */
#define NW_ERROR_GEOCODE_MASK  0xff000000 
#define NW_ERROR_GEOCODE       0x81000000 // could not geocode
#define NW_ERROR_COUNTRY       0x82000000 // country differs
#define NW_ERROR_STATE         0x83000000 // state differs
#define NW_ERROR_CITY          0x84000000 // city differs
#define NW_ERROR_LANG          0x85000000 // language differs
#define NW_ERROR_STREET        0x90000000 // street differs
#define NW_ERROR_STREET_BASE   0x91000000 // base name differs
#define NW_ERROR_STREET_TYPE   0x92000000 // type differs
#define NW_ERROR_STREET_PRE    0x94000000 // prefix differs
#define NW_ERROR_STREET_SUF    0x98000000 // suffix differs
#define NW_ERROR_CROSS         0xa0000000 // X-street differs;
#define NW_ERROR_CROSS_BASE    0xa1000000 // base name differs
#define NW_ERROR_CROSS_TYPE    0xa2000000 // type differs
#define NW_ERROR_CROSS_PRE     0xa4000000 // prefix differs
#define NW_ERROR_CROSS_SUF     0xa8000000 // suffix differs
#define NW_ERROR_ZIP           0x86000000 // zip wrong
#define NW_ERROR_NO_ZIP        0x87000000 // zip not found;
#define NW_ERROR_ADDRESS       0x88000000 // house number not 
#define NW_ERROR_ADDRESS_DUP   0x89000000 // house number duplicate 
#define NW_ERROR_CITY_DUP      0x8c000000 // duplicate city 
#define NW_ERROR_ADDRESS_PARITY 0x8a000000 // address parity
#define NW_ERROR_NOT_EXACT     0xcf000000 // no exact match found
#define NW_ERROR_STATE_GEO_CITY 0x8d000000 // city failed for state geocoding lookup

/**
 * Geocoding warnings (positive values of equivalent errors)
 * If the user input has been changed a warning is issued.
 * Geocoding warnings may be "or"d together.
 * Geocoding warnings (positive values) 
 */
#define NW_WARNING_GEOCODE_MASK 0x00ffffff 
#define NW_WARNING_COUNTRY      0x00800000 // country changed
#define NW_WARNING_STATE        0x00400000 // state changed
#define NW_WARNING_CITY         0x00200000 // street changed
#define NW_WARNING_LANG         0x00100000 // language changed
#define NW_WARNING_PARTIAL      0x00080000 // partial match 
//#define NW_WARNING_STREET_BASE  0x00040000 // base changed
#define NW_WARNING_CITYCENTER   0x00040000  //warning if city center was enforced
#define NW_WARNING_STREET_TYPE  0x00020000 // type changed
#define NW_WARNING_STREET_DIR   0x00010000 // direction placement
#define NW_WARNING_STREET_PRE   0x00008000 // prefix changed
#define NW_WARNING_STREET_SUF   0x00004000 // suffix changed
#define NW_WARNING_CROSS        0x00002000 // cross street changed
#define NW_WARNING_CROSS_BASE   0x00001000 // cross base changed
#define NW_WARNING_CROSS_TYPE   0x00000800 // cross type changed
#define NW_WARNING_CROSS_DIR    0x00000400 // cross direction
#define NW_WARNING_CROSS_PRE    0x00000200 // cross prefix changed
#define NW_WARNING_CROSS_SUF    0x00000100 // cross suffix changed
#define NW_WARNING_HOUSE_NUM    0x00000080 // house number changed
#define NW_WARNING_ZIP          0x00000040 // zip changed
#define NW_WARNING_NEIGHBOR     0x00000020 // neighboring indices used
#define NW_WARNING_PHONETIC     0x00000010 // phonetic indices used

#define NW_WARNING_EXTENDED_CROSS_MASK 0x00000007

#define NW_WARNING_LOCAL_CROSS        0x0
#define NW_WARNING_EXIT_NUMBER        0x4   /* Exit number geocoding */
#define NW_WARNING_RAMP_NO_OUPASS     0x5   /* Ramp, no overpass/underpass */
#define NW_WARNING_VIRTUAL_OU_NO_RAMP 0x6   /* Overpass/underpass */
#define NW_WARNING_OU_RAMP            0x7   /* Overpass/underpass */


/* Routing errors */
#define NW_ERROR_RT_FAILED       -6000 /* unable to find route */
#define NW_ERROR_RT_POINTS       -6001 /* problem with source,
                                          destination, or stopovers */
#define NW_ERROR_RT_XDB_STOPS    -6002 /* stopovers/vias not supported with
                                          cross-database routing */
#define NW_ERROR_RT_TWO_VIAS     -6003 /* consecutive via points aren't supported */
#define NW_ERROR_RT_XDB_NOREV    -6004 /* unable to find crossover point to
                                          primary DB for cross-database routing */
#define NW_ERROR_NO_SHAPE        -6005 /* No shape points */
#define NW_ERROR_RT_MEMORY       -6006 /* Memory errors while routing */
#define NW_ERROR_RT_MAX_STOPS    -6007 /* Too many stopovers (current limit is 1) */
#define NW_ERROR_RT_DB_NOT_FOUND -6008 /* source, dest, or stopover is not in
                                          any of the DBS in mapDbPref */
#define NW_ERROR_RT_NOT_IN_CLUSTER -6009 /* Even if one of detination or stop over points
                                            do not fall in the same cluster as the source
                                            we return this error code */

//Incorrect input bearing value
#define NW_ERROR_RT_INCORRECT_BEARING -6014

//Bearing value exceeded the bearing threshold value
#define NW_ERROR_RT_BEARING_THRESHOLD_EXCEEDED -6015

/// Some enhanced routing error codes. Reservr as subset of
 /// routing from 6100
 #define NW_ERROR_ERT_GENERIC_RT_FAILURE -6100
 
 // failure in setting up result structure
 #define NW_ERROR_ERT_PROCESS_SOLN_FAIL  -6101
 
 // XDB routes not supported
 #define NW_ERROR_ERT_XDB_RT             -6102
 
 // Multiple routes not supported
 #define NW_ERROR_ERT_MULTIPLE_RT        -6103
 
 //Invalid ERT REQ
 #define NW_ERROR_ERT_INVALID_ERT_REQ    -6104

/* Explication errors */

#define NW_ERROR_UNIT_NOT_DEF    -7000 /* unit not defined    */
#define NW_ERROR_FEET_NOT_SUPP   -7001 /* feet not supported  */
#define NW_ERROR_METER_NOT_SUPP  -7002 /* meter not supported */

/* Data errors */
#define NW_ERROR_DATA_SHAPE      -8000 /* Corrupt routing data */
#define NW_ERROR_DATA_ROUTING    -8001 /* Corrupt shape   data   */
#define NW_ERROR_DATA_NAME       -8002 /* Corrupt name    data    */
#define NW_ERROR_DATA_SIGN       -8003 /* Corrupt sign    data    */
#define NW_ERROR_DATA_SOURCE     -8004 /* Corrupt source  data    */

/* POI errors */
#define NW_ERROR_MAXPOIS_OUT_OF_RANGE     -9000
#define NW_ERROR_POI_BAD_ZIPCODE          -9001
#define NW_ERROR_POI_BAD_CITY             -9002
#define NW_ERROR_POI_BAD_STATE            -9003
#define NW_ERROR_POI_BAD_COUNTRY          -9004
#define NW_ERROR_POI_LICENSE              -9005


/* Client-side errors */
#define NWC_ERROR_COMM             -20000 /* generic client-side communication error */
#define NWC_ERROR_NO_HOST          -20001 /* hostname not set */
#define NWC_ERROR_GETHOSTBYNAME    -20002 /* gethostbyname() fails */
#define NWC_ERROR_SOCKET           -20003 /* socket() fails */
#define NWC_ERROR_CONNECT          -20004 /* connect() fails */
#define NWC_ERROR_VERSION          -20005 /* Client-Server Version mismatch */
#define NWC_ERROR_PROJTYPE         -20006 /* Projection Type mismatch */
#define NWC_ERROR_INIT             -20007
#define NWC_ERROR_PARAM            -20008 /* invalid parameter */
#define NWC_ERROR_DISCONNECT       -20009
#define NWC_ERROR_INVALID_NUM_POIS -20010 /* supplemental db request number of POIs invalid */
#define NWC_ERROR_INVALID_MAX_POIS -20011
#define	NWC_ERROR_OUT_OF_MEMORY	   -20012
#define	NWC_ERROR_LONG_URL	       -20013
#define NWC_ERROR_EVENT_SIZE_EXCEEDED -20014
#define NWC_ERROR_CONNECTION_DENIED   -20015


#endif

