/* 
* (C) Copyright 2000-2004 by Kivera, Inc.  All rights reserved. >>./client/API/c/libclient/include/poisearch.h.new
echo * 
* This material is protected by U.S. and international 
* copyright laws and may not be reproduced, modified, 
* distributed, publicly displayed or used to create derivative 
* works without the express written consent of Kivera, Inc.  
* The information contained herein is considered a trade 
* secret as defined in section 499C of the penal code of the 
* State of California. This copyright notice may not be 
* altered or removed. 
* 
*/ 
#ifndef _POISEARCH_H
#define _POISEARCH_H

#include "kivera.h"
#include "geostd_def.h"
#include "client_windows.h"

#ifdef  __cplusplus
extern "C" {
#endif
DLLEXPORT int GetPoiName(UCHAR FileId, UINT FilePtr, void *namebuf, int bufSz);
DLLEXPORT CHAR *GetName(UCHAR nameFileId, UINT nameFilePtr);
DLLEXPORT void line_parse(char *line, int delim, int count, char **list);
DLLEXPORT void FreeName(CHAR *name);
#ifdef  __cplusplus
}
#endif

#endif
