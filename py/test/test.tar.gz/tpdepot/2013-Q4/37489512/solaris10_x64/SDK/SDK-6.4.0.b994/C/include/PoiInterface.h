/* 
* (C) Copyright 2000-2004 by Kivera, Inc.  All rights reserved. >>./client/API/c/libclient/include/PoiInterface.h.new
echo * 
* This material is protected by U.S. and international 
* copyright laws and may not be reproduced, modified, 
* distributed, publicly displayed or used to create derivative 
* works without the express written consent of Kivera, Inc.  
* The information contained herein is considered a trade 
* secret as defined in section 499C of the penal code of the 
* State of California. This copyright notice may not be 
* altered or removed. 
* 
*/ 
#ifndef _POI_INTERFACE_H
#define _POI_INTERFACE_H

#include "kivera.h"
#include "geostd_def.h"
#include "nw_errors.h"


#define MAXPOI_LIMIT    500
#define   NW_NAME_SIZE  256
#define   NW_MAX_VID      5

#define   INSERT_POI    1001
#define   UPDATE_POI    2001
#define   DATE_LENGTH   16

#define GLOBAL_PHONE_IDX_FLAG          0x80000000
#define GLOBAL_WORD_IDX_FLAG           0x40000000
#define PROX_PHONE_IDX_FLAG            0x20000000
#define PROX_WORD_IDX_FLAG             0x10000000
#define PROX_CATEGORY_IDX_FLAG         0x08000000
#define STATE_PHONE_IDX_FLAG           0x04000000
#define STATE_WORD_IDX_FLAG            0x02000000
#define CITY_PHONE_IDX_FLAG            0x01000000
#define CITY_WORD_IDX_FLAG             0x00800000
#define ZIP_PHONE_IDX_FLAG             0x00400000
#define ZIP_WORD_IDX_FLAG              0x00200000
#define CTRY_WORD_IDX_FLAG             0x00100000

#define NAME_WORD_DATA_FLAG            0x00000001
#define POI_DATA_FLAG                  0x00000002

#define NW_SUPPINFO_FMT_DEFAULT        0
#define NW_SUPPINFO_FMT_DETAIL         1001

#define INTFIELD1 1
#define INTFIELD2 2
#define INTFIELD3 3
#define INTFIELD4 4
#define INTFIELD5 5
#define INTFIELD6 6
#define INTFIELD7 7
#define INTFIELD8 8
#define INTFIELD9 9
#define INTFIELD10 10
#define TEXTFIELD1 11
#define TEXTFIELD2 12
#define TEXTFIELD3 13
#define TEXTFIELD4 14
#define TEXTFIELD5 15
#define TEXTFIELD6 16
#define TEXTFIELD7 17
#define TEXTFIELD8 18
#define TEXTFIELD9 19
#define TEXTFIELD10 20
#define DATEFIELD1   21
#define DATEFIELD2  22
#define DATEFIELD3  23
#define DATEFIELD4  24
#define DATEFIELD5  25
#define DATEFIELD6  26
#define DATEFIELD7  27
#define DATEFIELD8  28
#define DATEFIELD9  29
#define DATEFIELD10  30
#define INTFIELD11 31
#define INTFIELD12 32
#define INTFIELD13 33
#define INTFIELD14 34
#define INTFIELD15 35
#define TEXTFIELD11 36
#define TEXTFIELD12 37
#define TEXTFIELD13 38
#define TEXTFIELD14 39
#define TEXTFIELD15 40
#define DATEFIELD11 41
#define DATEFIELD12 42
#define DATEFIELD13 43
#define DATEFIELD14 44
#define DATEFIELD15 45
#define LONGTEXTFIELD1 46
#define LONGTEXTFIELD2 47
#define LONGTEXTFIELD3 48
#define LONGTEXTFIELD4 49
#define LONGTEXTFIELD5 50

#define SEARCH_EQUAL_TO 1
#define SEARCH_LESS_THAN 2
#define SEARCH_GREATER_THAN 3
#define SEARCH_GREATER_THAN_EQUAL_TO 4
#define SEARCH_LESS_THAN_EQUAL_TO 5
#define SEARCH_NOT_EQUAL_TO 6
#define SEARCH_LIKE_BOTH 7
#define SEARCH_LIKE_STARTSWITH 8
#define SEARCH_LIKE_ENDSWITH 9
#define SEARCH_BETWEEN 10

typedef enum Search_Types {
    GLOBAL_PHONE_SEARCH,
    GLOBAL_WORD_SEARCH,
    PROXIMITY_PHONE_SEARCH,
    PROXIMITY_WORD_SEARCH,
    PROXIMITY_CATEGORY_SEARCH,
    STATE_PHONE_SEARCH,
    STATE_WORD_SEARCH,
    CITY_PHONE_SEARCH,
    CITY_WORD_SEARCH,
    ZIP_PHONE_SEARCH,
    ZIP_WORD_SEARCH,
    PROXIMITY_BY_ROUTE_PHONE_SEARCH,
    PROXIMITY_BY_ROUTE_WORD_SEARCH,
    PROXIMITY_BY_ROUTE_CATEGORY_SEARCH,
    CTRY_WORD_SEARCH
} SearchTypes;

typedef struct file_bucket_info {
    UINT numPois;
    
    INT nPhoneFiles;
    INT nWordFiles;
    INT nPoiFiles;
    INT nNameTextFiles;
    
    INT nCityPhoneFiles;
    INT nStatePhoneFiles;
    INT nZipPhoneFiles;

    INT nCityWordFiles;
    INT nStateWordFiles;
    INT nZipWordFiles;
    INT nCtryWordFiles;
    
    INT nPhoneCellFiles;
    INT nWordCellFiles;
    INT nCategoryCellFiles;

    INT nPhoneBuckets;
    INT nWordBuckets;
    
    INT nCityPhoneBuckets;
    INT nStatePhoneBuckets;
    INT nZipPhoneBuckets;

    INT nCityWordBuckets;
    INT nStateWordBuckets;
    INT nZipWordBuckets;
    INT nCtryWordBuckets;

    INT nPhoneCellBuckets;
    INT nWordCellBuckets;
    INT nCategoryCellBuckets; 
} POI_INDEX_INFO;

typedef struct adr_inf {
    INT nAddrBuckets;
    INT nAddrFiles;
    INT nAddrDataFiles;
} ADDR_INFO;

typedef struct g_env {
    POI_INDEX_INFO  poi;
    ADDR_INFO       addrInfo;

    int  dbId;                  /* Database id    */
    void *entry;                /* Database entry */
    char *poipath;
} global_env;

typedef struct POI_Key {
    int           vid;              /* Vendor ID */
    unsigned int  pid;              /* POI ID */
} POI_KEY;

typedef struct POI_Info {
    unsigned short majorCategoryId;   /* Major category id */
    unsigned short minorCategoryId;   /* Minor category id */

    short areaCode;          /* area code */
    int phoneNumber;         /* phone number */

    int worldLong;                    /* longitude... world coordinates */
    int worldLat;                     /* latitude... world coordinates */
    double distance;                  /* Used in proximity searches to return
                                         distance from the reference point */
    char zipcode[NW_ZIP_SIZE];        /* zipcode */
    unsigned char name[NW_NAME_SIZE]; /* POI name */
} POI_INFO;

typedef struct
{
    int             type;

    int             vid[NW_MAX_VID];
    unsigned char   name[NW_NAME_SIZE];
    
    unsigned short  majorCategoryId;
    unsigned short  minorCategoryId;
    
    short           areaCode;
    int             phoneNumber;

    /* Proximity search section */
    double          distance;  /* Distance from reference point */
    int             worldLong; /* Longitude of the reference point */
    int             worldLat;  /* Latitude of the reference point */

    /* Region of search */
    char            country[NW_COUNTRY_SIZE];
    char            city[NW_CITY_SIZE];
    char            state[NW_STATE_SIZE];
    char            zipCode[NW_ZIP_SIZE];

    /* Maximum number of matching POIs to return */
    int             maxPois;

    char            unit;
    int             mapDbPref[NW_DB_MAX];
} POI_SEARCH_REQUEST;

typedef struct
{
    int         status;
    int         nPois;
    POI_KEY     *pois;
    POI_INFO    *infos;
} POI_SEARCH_REPLY;


#define  NWC_POI_SUPP_DB_ADDRESS  0x00000001

typedef struct supp_db_req
{
    int flag;
    int nPois;
    POI_KEY *pois;
    int outputformat;
} SUPPLEMENTAL_DB_REQUEST;


typedef struct supp_info
{
    int flag;
    int size;
    char *info;
} SUPP_DB_INFO;


typedef struct supp_reply
{
    int status;
    int nPois;
    int nInfos;
    SUPP_DB_INFO *suppInfo;
} SUPPLEMENTAL_DB_REPLY;

typedef struct POI_ADDRESS
{
	char houseNumber[20];
	char streetName[255];
	char city[255];
	char admin1[255];
	char admin2[255];
	char country[255];
	char zip[30];
} POI_ADDRESS;

typedef struct POI_NAME_STRUCT
{
	char name[255];
	char language[50];
	int kindOfName;
} POI_NAME_STRUCT;

typedef struct POI_SUPPLEMENTAL_INFO
{
	int vendorId;
	int poiId;
	int int1;
	int int2;
	int int3;
	int int4;
	int int5;
	int int6;
	int int7;
	int int8;
	int int9;
	int int10;
	int int11;
	int int12;
	int int13;
	int int14;
	int int15;
	char string1[255];
	char string2[255];
	char string3[255];
	char string4[255];
	char string5[255];
	char string6[255];
	char string7[255];
	char string8[255];
	char string9[255];
	char string10[255];
	char string11[255];
	char string12[255];
	char string13[255];
	char string14[255];
	char string15[255];
	char date1[30];
	char date2[30];
	char date3[30];
	char date4[30];
	char date5[30];
	char date6[30];
	char date7[30];
	char date8[30];
	char date9[30];
	char date10[30];
	char date11[30];
	char date12[30];
	char date13[30];
	char date14[30];
	char date15[30];
	char text1[10000];
	char text2[10000];
	char text3[10000];
	char text4[10000];
	char text5[10000];
	int noOfImage1Bytes;
	char * image1Store;
	int noOfImage2Bytes;
	char * image2Store;
} POI_SUPPLEMENTAL_INFO;

typedef struct POI_EDIT_STRUCT
{
	int vendorId;
	int poiId;
    char providerPoiId[64];
	short numOfNames;
	POI_NAME_STRUCT *names;
	POI_ADDRESS addr;
	int areaCode;
	int phoneNumber;
	int faxAreaCode;
	int faxNumber;
	char email[64];
	char url1[255];
	char url2[255];
	char url3[255];
	int latitude;
	int longitude;
	short noOfCategories;
	int *categories;
	POI_SUPPLEMENTAL_INFO info;
	double distance;
} POI_EDIT_STRUCT;

typedef struct
{
    int               status;
    int               nPois;
    POI_EDIT_STRUCT   *pois;
} KIV_POI_SEARCH_REPLY;

typedef struct
{
	short fieldNo;
	short searchType;
	char searchValue[255];
} POI_SEARCH_FIELD_STRUCT;

typedef struct POI_SEARCH_STRUCT
{
	int noOfFields;
	int vendorId;
	POI_SEARCH_FIELD_STRUCT *search;
	int maxPois;
} POI_SEARCH_STRUCT;

typedef struct
{
	int status;
	int noOfPois;
	POI_EDIT_STRUCT *pois;
} POI_DB_SEARCH_REPLY;

typedef struct
{
	int actionFlg;
	int clientId;
	unsigned char dateTimeStamp[DATE_LENGTH];
	POI_EDIT_STRUCT *poi;
} POI_MANAGE_REQ;

typedef struct
{
	int clientId;
	unsigned char dateTimeStamp[DATE_LENGTH];
	int vendorId;
	int poiId;
} POI_REMOVE_REQ;

typedef struct
{
	int clientId;
	unsigned char dateTimeStamp[DATE_LENGTH];
	int vendorId;
	int categoryId;
} POI_CLEARALL_REQ;

typedef struct
{
	int poiId;
	int vendorId;
} POI_SELECT_REQ;

typedef struct
{
	int status;
	POI_EDIT_STRUCT *poi;
} POI_SELECT_RES;

typedef struct 
{
	int noOfFields;
	int vendorId;
	POI_SEARCH_FIELD_STRUCT *search;
	int maxPois;
} POI_SRCHSUPPINFO_REQ;

typedef struct
{
	int status;
	int noOfPois;
	POI_EDIT_STRUCT *pois;
} POI_SRCHSUPPINFO_RES;

typedef struct 
{
	int vendorId;
	short noOfCategories;
	int *categories;
	char name[255];
	double radius;
	char radiusUnit;
	int noOfPoints;
	int *shapePoints;      /* array of shape points x1, y1, x2, y2, ... */
} POI_ON_ALONG_ROUTE_REQ;

typedef struct
{
	int status;
	int noOfPois;
	POI_EDIT_STRUCT *pois;
} POI_ON_ALONG_ROUTE_RES;

typedef struct 
{
	int index;
	int poiKey;
} POISORTKEY;

#endif
