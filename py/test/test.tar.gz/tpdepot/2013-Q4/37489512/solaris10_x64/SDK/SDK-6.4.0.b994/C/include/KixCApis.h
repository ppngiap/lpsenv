/* 
* (C) Copyright 2000-2004 by Kivera, Inc.  All rights reserved. >>./client/API/c/libclient/include/KixCApis.h.new
echo * 
* This material is protected by U.S. and international 
* copyright laws and may not be reproduced, modified, 
* distributed, publicly displayed or used to create derivative 
* works without the express written consent of Kivera, Inc.  
* The information contained herein is considered a trade 
* secret as defined in section 499C of the penal code of the 
* State of California. This copyright notice may not be 
* altered or removed. 
* 
*/ 
/* Header file for search_apis.c */
#ifndef _KIXCAPIS_H
#define _KIXCAPIS_H
#include "kivera.h"
#include "geostd_def.h"
#include "poisearch.h"
#include "nw_errors.h"
#include "PoiInterface.h"
#include "client_windows.h"


#ifdef  __cplusplus
extern "C" {
#endif
// Database and environment initialization
DLLEXPORT int nw_poi_init_env_db(const CHAR *dbpath, int cache, const char *poipath);

// Database and environment initialization
DLLEXPORT int nw_poi_init_env(int DBId, int cache, const char *path);

// Consolidated search
DLLEXPORT int nw_poi_search(POI_SEARCH_REQUEST *request, POI_SEARCH_REPLY *reply);

// Free memory for pois
DLLEXPORT void nw_poi_free_memory(POI_SEARCH_REPLY *rep);

// POI to get address
DLLEXPORT int nw_poi_get_address(int vid, int pid, char *address);

// Done with searching. Release resources
DLLEXPORT void nw_poi_cleanup();

// Get supplemental fields    
DLLEXPORT int nw_get_supplemental_fields(SUPPLEMENTAL_DB_REQUEST *request,
                               SUPPLEMENTAL_DB_REPLY *reply);

// Free SUPPLEMENTAL_DB_REPLY structure
DLLEXPORT void nw_free_supplemental_fields(SUPPLEMENTAL_DB_REPLY *reply);

#ifdef  __cplusplus
}
#endif
#endif
