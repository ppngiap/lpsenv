/* 
* (C) Copyright 2000-2004 by Kivera, Inc.  All rights reserved. >>./client/API/c/libclient/include/iso_codes.h.new
echo * 
* This material is protected by U.S. and international 
* copyright laws and may not be reproduced, modified, 
* distributed, publicly displayed or used to create derivative 
* works without the express written consent of Kivera, Inc.  
* The information contained herein is considered a trade 
* secret as defined in section 499C of the penal code of the 
* State of California. This copyright notice may not be 
* altered or removed. 
* 
*/ 
// iso_codes.h
#ifndef _ISO_CODES_H
#define _ISO_CODES_H

#include "kvr_ISO_639.h"
#include "kvr_ISO_3166.h"

#endif // _ISO_CODES_H
