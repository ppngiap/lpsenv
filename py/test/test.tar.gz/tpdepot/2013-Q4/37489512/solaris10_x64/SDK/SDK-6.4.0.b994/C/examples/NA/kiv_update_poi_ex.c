/* 
* (C) Copyright 2000-2004 by Kivera, Inc.  All rights reserved. >>./client/examples/source/kiv_update_poi_ex.c.new
echo * 
* This material is protected by U.S. and international 
* copyright laws and may not be reproduced, modified, 
* distributed, publicly displayed or used to create derivative 
* works without the express written consent of Kivera, Inc.  
* The information contained herein is considered a trade 
* secret as defined in section 499C of the penal code of the 
* State of California. This copyright notice may not be 
* altered or removed. 
* 
*/ 
/******************************************************
 * File: kiv_update_poi_ex.c                          *
 * -------------------------------------------------- *
 * Description:  An example program for exhibiting    *
 *               proper usage of the                  *
 *               kiv_managePoiData function for       *
 *               updating pois in the                 *
 *               dynamic pois database      .         *
 ******************************************************/

/******************************************************
 *Library Includes                                    *
 ******************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "capis.h"
#include "iso_codes.h"

#ifdef _MSC_VER
#include "win_getopt.h"
#include "WinSock2.h"
#endif

#ifdef LINUX
#include <unistd.h>
#endif

/********************************************************************
 * ID OF THE POI TO BE UPDATED. THIS POI SHOULD EXIST IN THE DATABASE
 * Run the poi insert, which will give you an id for that inserted POI.
 * Replace the follwoing POI_ID value by the one you got from inserting a POI.
 ********************************************************************/
#define POI_ID 44481          

/******************************************************
 * Constant Definitions
 ******************************************************/

/******************************************************
 * Utility function prototypes
 ******************************************************/
/* gets host and port from command-line arguments */
int get_host_and_port(int argc, char *argv[], char **host, int * port);


/* prints information about  a poi */
void dump_poi(POI_EDIT_STRUCT *poi );



/******************************************************
 * Poi update example function prototypes
 ******************************************************/

/* Demonstrates the use of update API */
int poi_update( NWC_CLIENT *handle, POI_MANAGE_REQ *req );

/* Manually create the POI structure */
int poi_create( POI_EDIT_STRUCT *poi );

/******************************************************
 * Main program
 ******************************************************/
int main(int argc, char *argv[]) 
{

    /******************************************************
     * Declarations
     ******************************************************/
    int status = NW_OK;                   /* function return status */

    char *host                   = NULL;  /* host on which server is running */
    int   port                   = 0;     /* port on which server running */
    NWC_CLIENT *handle           = NULL;  /* server connection handle */

	POI_MANAGE_REQ poiManageReq;          /* the manage request */

    /**********************************************************************
     * Initialize structures
     **********************************************************************/
    memset(&poiManageReq, 0, sizeof(POI_MANAGE_REQ));

    /**********************************************************************
     * Get host and port command line arguments
     **********************************************************************/
    if (get_host_and_port(argc, argv, &host, &port) == FALSE)
        exit(0);

    /**********************************************************************
     * Initialize client options
     **********************************************************************/
    handle = nwc_init_client_option(UNPROJECTED);

    if ( NULL == handle )
    {
        printf("Error initializing client options\n");
        exit( 1 );
    }

    /**********************************************************************
     * Connect to location server
     **********************************************************************/
    status = nwc_connect(handle, host, (u_short)port);

    if (status < 0)
    {
        printf("Error connecting to server, status = %d\n", status);
        exit( 1 );
    }

    
    /**********************************************************************
     * poi update example
     **********************************************************************/
    printf("\n\n"
           "==============================================================\n"
           "Poi update example\n"
           "==============================================================\n");

    status = poi_update( handle, &poiManageReq);

    
    /* --- Exit Program --- */
    status = nwc_disconnect(handle);

    if (NW_OK != status)
    {
        printf("Error disconnecting from server, status = %d\n", status);
        exit(1);
    }
    
    status = nwc_delete_client_option(handle);

    if (NW_OK != status)
    {
        printf("Error cleaning up client handler, status = %d\n", status);
        exit(1);
    }

    exit ( 0 );
  
}

/******************************************************
 * Print information on how to use this program
 ******************************************************/
void print_usage(char *prog_name)
{
    printf("Usage: %s [-?] -h <host> -p <port>\n"
           "       -? print this message\n"
           "       -h host machine name\n"
           "       -p port number\n\n",
           prog_name);
}

/******************************************************
 * Get host and port command line arguments
 ******************************************************/
int get_host_and_port(int argc, char *argv[], char **host, int * port){

    int helpFlag = FALSE, c;

    while ((c = getopt(argc, argv, "h:p:")) != EOF) {
        switch (c) {
        case 'p':
            /* get the port */
            *port = atoi(optarg);
            break;
        case 'h':
            /* get the host */
            *host = optarg;
            break;
        case '?':
        default:
            /* if unknown argument or "help" flag was specified, turn
             * on the help flag */
            helpFlag = TRUE;
            break;
        }
    }

    /* if host or port was not specified, turn on the help flag */
    if ((*host == NULL) || (*port == 0))
    {
        helpFlag = TRUE;
    }

    if(helpFlag)
    {
        print_usage(argv[0]);
        return FALSE;
    }
    return TRUE;
}


/************************************************************************
 * Create a poi to update.
 ************************************************************************/
 int poi_create(POI_EDIT_STRUCT *poi)
 {

    if ( NULL == poi )
    {
        printf("Error in parameters to poi_create\n");
        return -1;
    }

	poi->vendorId       = 3;
	poi->poiId          = POI_ID;  /* Since we are updating this id should */
								   /* exist in the database                */
    strcpy(poi->providerPoiId, "New Test Provider POI ID");
	poi->numOfNames     = 1;

	/* We will have only one name for the poi. */
	poi->names = (POI_NAME_STRUCT *)malloc(sizeof(POI_NAME_STRUCT));

	strcpy(poi->names[0].name , "Kivera Location Services");
	strcpy(poi->names[0].language , "en");
	poi->names[0].kindOfName = 1;

	strcpy(poi->addr.houseNumber , "300");
	strcpy(poi->addr.streetName , "LAKESIDE DRIVE");
	strcpy(poi->addr.city , "OAKLAND");
	strcpy(poi->addr.admin1 , "CALIFORNIA");
	strcpy(poi->addr.admin2 , "");
	strcpy(poi->addr.country , "UNITED STATES");
	strcpy(poi->addr.zip , "94612");

	poi->areaCode       = 94612;
	poi->phoneNumber    = 7933300;
	poi->faxAreaCode    = 510;
	poi->faxNumber      = 7633401;
    strcpy(poi->email, "new_example@kivera.com");
    strcpy(poi->url1, "http://www.kivera.com/new_example_url1");
    strcpy(poi->url2, "http://www.kivera.com/new_example_url2");
    strcpy(poi->url3, "http://www.kivera.com/new_example_url3");
	poi->latitude       = 24248330;
	poi->longitude      = -79953930;
	poi->noOfCategories = 1;

	/* the poi belongs to one category. */
	poi->categories     = (int *)malloc(sizeof(int));

	poi->categories[0]  = 100;

	poi->info.vendorId  = 3;      /* should be equal to poi->vendorId */
	poi->info.poiId     = POI_ID;   /* should be equal to poi->poiId */
	poi->info.int1      = 1001;
	poi->info.int2      = 1002;
	poi->info.int3      = 1003;
	poi->info.int4      = 1004;
	poi->info.int5      = 1005;
	poi->info.int6      = 1006;
	poi->info.int7      = 1007;
	poi->info.int8      = 1008;
	poi->info.int9      = 1009;
	poi->info.int10     = 1010;
	poi->info.int11     = 1011;
	poi->info.int12     = 1012;
	poi->info.int13     = 1013;
	poi->info.int14     = 1014;
	poi->info.int15     = 1015;

	strcpy( poi->info.string1 , "text100");
	strcpy( poi->info.string2 , "text200");
	strcpy( poi->info.string3 , "text300");
	strcpy( poi->info.string4 , "text400");
	strcpy( poi->info.string5 , "text500");
	strcpy( poi->info.string6 , "text600");
	strcpy( poi->info.string7 , "text700");
	strcpy( poi->info.string8 , "text800");
	strcpy( poi->info.string9 , "text900");
	strcpy( poi->info.string10 , "text1000");
	strcpy( poi->info.string11 , "text1100");
	strcpy( poi->info.string12 , "text1200");
	strcpy( poi->info.string13 , "text1300");
	strcpy( poi->info.string14 , "text1400");
	strcpy( poi->info.string15 , "text1500");

	strcpy( poi->info.date1 , "09012002");
	strcpy( poi->info.date2 , "09022002");
	strcpy( poi->info.date3 , "09032002");
	strcpy( poi->info.date4 , "09042002");
	strcpy( poi->info.date5 , "09052002");
	strcpy( poi->info.date6 , "09062002");
	strcpy( poi->info.date7 , "09072002");
	strcpy( poi->info.date8 , "09082002");
	strcpy( poi->info.date9 , "09092002");
	strcpy( poi->info.date10 , "09102002");
	strcpy( poi->info.date11 , "09112002");
	strcpy( poi->info.date12 , "09122002");
	strcpy( poi->info.date13 , "09132002");
	strcpy( poi->info.date14 , "09142002");
	strcpy( poi->info.date15 , "09152002");

	strcpy( poi->info.text1 , "New text column 1.");
	strcpy( poi->info.text2 , "New text column 2.");
	strcpy( poi->info.text3 , "New text column 3.");
	strcpy( poi->info.text4 , "New text column 4.");
	strcpy( poi->info.text5 , "New text column 5. The beginning. ");
	strcat( poi->info.text5 , "New text column 5. New text column 5. ");
	strcat( poi->info.text5 , "New text column 5. New text column 5. ");
	strcat( poi->info.text5 , "New text column 5. New text column 5. ");
	strcat( poi->info.text5 , "New text column 5. New text column 5. ");
	strcat( poi->info.text5 , "New text column 5. New text column 5. ");
	strcat( poi->info.text5 , "New text column 5. New text column 5. ");
	strcat( poi->info.text5 , "New text column 5. New text column 5. ");
	strcat( poi->info.text5 , "New text column 5. New text column 5. ");
	strcat( poi->info.text5 , "New text column 5. New text column 5. ");
	strcat( poi->info.text5 , "New text column 5. New text column 5. ");
	strcat( poi->info.text5 , "New text column 5. New text column 5. ");
	strcat( poi->info.text5 , "New text column 5. New text column 5. ");
	strcat( poi->info.text5 , "New text column 5. New text column 5. ");
	strcat( poi->info.text5 , "New text column 5. New text column 5. ");
	strcat( poi->info.text5 , "New text column 5. New text column 5. ");
	strcat( poi->info.text5 , "New text column 5. New text column 5. ");
	strcat( poi->info.text5 , "New text column 5. New text column 5. ");
	strcat( poi->info.text5 , "New text column 5. New text column 5. ");
	strcat( poi->info.text5 , "New text column 5. New text column 5. ");
	strcat( poi->info.text5 , "New text column 5. New text column 5. ");
	strcat( poi->info.text5 , "New text column 5. The end.");

	poi->info.noOfImage1Bytes   = 0;
	poi->info.image1Store       = NULL;
	poi->info.noOfImage2Bytes   = 0;
	poi->info.image2Store       = NULL;

    return NW_OK;

 }

/******************************************************************
 * Clean up memory allocated on heap by update poi API
 *****************************************************************/
int cleanup_update_poi( POI_MANAGE_REQ *update_poi_req)
{
    int status = NW_OK;

    if ( NULL == update_poi_req ) 
    {
        printf( "Bad arguments to cleanup_update_poi\n" );
        return -1;
    }

    status = kiv_freePoiManageReq(update_poi_req);

    if ( NW_OK != status )
    {
        printf("Error freeing poi update request\n");
    }

    return status;
}




/************************************************************************
 * A poi update example.
 ************************************************************************/
int poi_update(
    NWC_CLIENT *handle,                /* location server handle */
    POI_MANAGE_REQ   *poi_upd_req      /* poi manage request */
    )
{
    int    status = 0;                    /* for checking error returns */
    char dateTimeStamp[16];
	POI_EDIT_STRUCT poi;                  /* the poi to be updated */

    if ( (NULL == poi_upd_req) )
    {
        printf("Error in parameters to poi_update\n");
        return -1;
    }


    /*****************************************************************
     * Initialize input structures
     *****************************************************************/
    memset(&poi, 0, sizeof(POI_EDIT_STRUCT));


	/**********************************************************************
	 * Create the poi to update.
	 **********************************************************************/
	 status = poi_create(&poi);

    if (status < 0)
    {
        printf("Error creating the poi, status = %d\n", status);
        return status;
    }

	/**********************************************************************
	 * Populate the poi manage request
	 **********************************************************************/
	 poi_upd_req->actionFlg = UPDATE_POI;
	 poi_upd_req->clientId  = 911;        /* Unique id identifying the client*/
	 //strcpy(poi_upd_req->dateTimeStamp , "08/15/2002");
         sprintf(dateTimeStamp, "%ld", time(0));
         strcpy(poi_upd_req->dateTimeStamp , dateTimeStamp);

	 poi_upd_req->poi       = &poi;

    
    /*********************************************************************
     * Call update(manage) API
     *********************************************************************/
    status = kiv_managePoiData( handle, poi_upd_req);

    if (status < 0)
    {
        printf("poi_update failed, status = %d\n", status);
    }
    else
    {
        printf("poi_update successful, status = %d\n", status);
    }

    cleanup_update_poi(poi_upd_req );

    return NW_OK;
}


/**************************************************************************
 * Dump information about the poi which needs to be updated
 **************************************************************************/
void dump_poi(POI_EDIT_STRUCT *poi)
{
    printf( "POI: vendorId = %d, poiId = %d, numOfNames = %d\n",
            poi->vendorId, poi->poiId, poi->numOfNames );
}
