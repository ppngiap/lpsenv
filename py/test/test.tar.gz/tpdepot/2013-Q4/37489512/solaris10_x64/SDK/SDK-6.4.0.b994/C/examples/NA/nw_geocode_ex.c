/******************************************************
 * File: nw_geocode_ex.c                              *
 * -------------------------------------------------- *
 * Description:  An example program for exhibiting    *
 *               proper usage of the                  *
 *               nw_geocode function.                 *
 ******************************************************/

/* --- Library Includes --- */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "capis.h"

#ifdef _MSC_VER
#include <WinSock.h>
#include "win_getopt.h"
#endif

#ifdef LINUX
#include <unistd.h>
#endif


/******************************************************
 * Print information on how to use this program
 ******************************************************/
void print_usage(char *prog_name)
{
    printf("Usage: %s [-?] -h <host> -p <port>\n"
           "       -? print this message\n"
           "       -h host machine name\n"
           "       -p port number\n\n",
           prog_name);
}

/******************************
* argument handler
******************************/
int get_host_and_port(int argc, char *argv[], char **host, int *port)
{
    int helpFlag = FALSE, c;

    *port = 0;
    *host = NULL;
    if (argc < 3) helpFlag = TRUE;

    /* read input arguments */
    while ((c = getopt(argc, argv, "h:p:?")) != EOF)
    {
        switch (c)
        {
            case 'p':
                *port = atoi(optarg);
                break;
            case 'h':
                *host = optarg;
                break;
            case '?':
                helpFlag = TRUE;
                break;
        }
    }

    if ((*host == NULL) || (*port == 0)) helpFlag = TRUE;
    if (helpFlag)
    {
        //printf("syntax: testgeo -h <host> -p <port>\n");
        print_usage(argv[0]);
        return FALSE;
    }

     return TRUE;
}


/******************************
* data structure initialization
******************************/
void initStructures(int argc, char *argv[],     /* input arguments */
                    GEO_REQ *geo_req,           /* request struct */
                    RT_POINT   *rt_point,       /* location result struct */
                    GEO_OPTIONS *opt,           /* options result struct */
                    GEO_INFO *info,             /* description result struct */
                    NWC_CLIENT **c_hndl,        /* client struct */
                    CSF_DB   *csf_db,           /* db struct */
                    GEO_OPTIONS *display_opt)     /* options result struct */
{
    int port;
    char *host;
    int status, i;

    /* read input arguments */
    if (get_host_and_port(argc, argv, &host, &port) == FALSE)
    {
        exit(0);
    }
  
    /* create client handler structure */
    *c_hndl = nwc_init_client_option(UNPROJECTED);
    if(!*c_hndl)
    {
        printf("error initializing the client\n");
        exit( 1 );
    }

    /* --- Connect to the server --- */
    status = nwc_connect(*c_hndl, host, (u_short)port);
    if (NW_OK != status)
    {
        printf("error connecting to server. %d\n", status);
        exit( 1 );
    }
  
    /* --- Initialize Structures and Databases -- */
    memset( geo_req, 0, sizeof( GEO_REQ ) );
    memset( opt, 0, sizeof( GEO_OPTIONS ) );
    memset( display_opt, 0, sizeof( GEO_OPTIONS ) );
    memset( info, 0, sizeof( GEO_INFO ) );
    memset( rt_point, 0, sizeof( RT_POINT ) );

    /*************************************************
    * "USA and Canada" are only valid countries at this time
    **************************************************/
    strcpy( (char *)geo_req->country, "USA" );

    /*************************************************
    * All examples use 30 foot offsets (location of
    * building is 30 feet from center line of street) 
    **************************************************/
    geo_req->offset = 30;
    geo_req->unit =  NW_UNIT_FT;

    /******************************************
    * Limit returned proposed values to 10
    * Malloc for proposed values list strings
    ******************************************/
    display_opt->limit = opt->limit = 10;
    opt->list =  (uchar**)malloc( opt->limit * sizeof( uchar * ) );
    display_opt->list =  (uchar**)malloc( display_opt->limit * sizeof( uchar * ) );

    if (NULL == opt->list)
    {
        printf("Error allocating the option list.\n");
        exit ( 1 );
    }

    for (i = 0; i < opt->limit; i++ )
    {
        opt->list[i] = (uchar *)malloc( NW_LINE_MAX * sizeof( uchar ) );
        if (NULL == opt->list[i])
        {
            printf("Error allocating an option buffer.\n");
            exit ( 1 );
        }
    }

    if (NULL == display_opt->list)
    {
        printf("Error allocating the display option list.\n");
        exit ( 1 );
    }

    for (i = 0; i < display_opt->limit; i++ )
    {
        display_opt->list[i] = (uchar *)malloc( NW_LINE_MAX * sizeof( uchar ) );
        if (NULL == display_opt->list[i])
        {
            printf("Error allocating an display option buffer.\n");
            exit ( 1 );
        }
    }

    status = nwc_get_mdb_list(*c_hndl, csf_db);
    if (NW_OK != status)
    {
        printf("Error getting the database list. %d\n", status);
        exit ( 1 );
    }
}

/******************************
* API execution
******************************/
int callAPIs(   GEO_REQ *geo_req,           /* request struct */
                RT_POINT   *rt_point,       /* location result struct */
                GEO_OPTIONS *opt,           /* error result struct */
                GEO_INFO *info,             /* description result struct */
                NWC_CLIENT *c_hndl,         /* client struct */
                GEO_OPTIONS *display_opt)   /* error result struct */
{
    int status;
    int opt_status;

    /* display geocoding example address */
    printf("\ngeocoding  line1: %s\n", geo_req->line1);
    printf("           line2: %s\n", geo_req->line2);
    if (0 != geo_req->cfield)
    {
        printf("using 1st option: %s\n", geo_req->cline);
    }

    /* --- Perform Request --- */
    status = nwc_geocode( c_hndl,   /* client handle */
                    geo_req,        /* request struct */
                    opt,            /* option list result struct */
                    info,           /* description result struct */
                    rt_point);      /* location result struct */


    opt_status = nwc_geo_display_options(opt, display_opt);
    if (opt_status != NW_OK) printf("Error getting displayable options\n");
    return status;

}


/******************************
* result display
******************************/
int displayResults( int status,             /* result status */
                RT_POINT *rt_point,         /* location result struct */
                GEO_OPTIONS *display_opt,   /* option list result struct */
                GEO_INFO *geo_info)         /* description result struct */
{
    const char *sides[] = {"", "Left", "Right", "Both"};
    int errsToDo = 0, i;

    /* display improved address found  */
    printf("Address geocoded:\n");
    printf("%s %s %c %s\n", geo_info->address, geo_info->street,
        *geo_info->xstreet ? '@' : ' ', geo_info->xstreet);
    printf("%s, %s %s\n\n", geo_info->city, geo_info->state, geo_info->zip);

    if (NW_OK == status)
    {
      /*************************************************
      * display resulting geocoded data
      **************************************************/
        printf( "Geocoding successful.\n\n" );
        printf( "\tcell: %x link: %d node: %d\n",
            rt_point->vmapID.mapID, rt_point->link, rt_point->node );
        printf("\tlongitude: %f latitude: %f\n",
            rt_point->world_long / NW_DEG2WORLD,
            rt_point->world_lat / NW_DEG2WORLD);
        printf("\tdisplaced longitude: %f latitude: %f\n",
            rt_point->d_world_long / NW_DEG2WORLD,
            rt_point->d_world_lat / NW_DEG2WORLD);
        printf("\tside: %s spot: %d%% street: %s\n",
            sides[rt_point->side], rt_point->spot, rt_point->street);
    }
    else
    {
      /*************************************************
      * display error type
      **************************************************/
        char *eptr;

        errsToDo = 1;   /* error */

        switch (status)
        {
            case NW_ERROR_ZIP:
                eptr = "ZIP CODE";
                break;
            case NW_ERROR_STATE:
                eptr = "STATE";
                break;
            case NW_ERROR_CITY:
                eptr = "CITY";
                break;
            case NW_ERROR_STREET:
                eptr = "STREET";
                break;
            case NW_ERROR_CROSS:
                eptr = "CROSS";
                break;
            case NW_ERROR_ADDRESS:
                eptr = "ADDRESS";
                break;
            case NW_ERROR_MAPDBID:
                eptr = "DATABASE";
                break;
            default:
                eptr = "GEOCODE";
                errsToDo = 0;
                break;
        };
        printf("Geocoding error = %s\n", eptr);

        /* display proposed values found in database */
        printf("proposed options:\n");
        for (i = 0; i < display_opt->count; i++ )
        {
            printf( "%d:  %s\n", i, display_opt->list[i] );
        }
        if (display_opt->count < 1) printf("none\n");
    }

    return errsToDo;
}

/*****************************************
* select from proposed options for re-try
******************************************/
int correctionLine(int status, GEO_INFO *info, GEO_OPTIONS *geo_opt,
            GEO_REQ *req)
{
    int i;
    
    i = 0;      /* retry using first proposed argument */
                /* note: user may select any option in list */
    if (i < geo_opt->count)
    {
        /* create improved address for request retry */
        strcpy(req->line1, info->outputLine1);
        strcpy(req->line2, info->outputLine2);

        /* select proposed option for correction line */
        strcpy(req->cline, geo_opt->list[i]);

        req->cfield = status;
        return 1;   /* do option */
    }

    return 0;   /* don't do option */
}

/******************************
*   MAIN program
******************************/
int main(int argc, char *argv[])
{
    /* --- Variable and Structure Declarations --- */
    GEO_REQ geo_req;
    RT_POINT   rt_point;
    GEO_OPTIONS opt;
    GEO_OPTIONS display_opt;
    GEO_INFO info;
    NWC_CLIENT *c_hndl;
    CSF_DB   csf_db;
    int status, example;
    int do_option, do_examples, errsToDo;
    int i;
    

    /******************************
    * data structure initialization
    ******************************/
    initStructures(argc, argv,      /* input arguments  */
                    &geo_req,       /* request struct */
                    &rt_point,      /* location result struct */
                    &opt,           /* option list result struct */
                    &info,          /* description result struct */
                    &c_hndl,        /* client struct */
                    &csf_db,        /* db struct */
                    &display_opt);  /* option list result struct */

    /***************************************
    *   select from available databases.
    *   first database selected here
    **************************************/
    geo_req.mapDbPref[0] = csf_db.db[0].id;
    geo_req.mapDbPref[1] = csf_db.db[1].id;

    for (example = 1, do_examples = 1; do_examples; example++)
    {
        char *desc;

        /******************************************
        * clear proposed value field
        ******************************************/
        geo_req.cfield = 0;
        *geo_req.cline = '\0';

        do_option = 0;  /* default is not to retry options in examples */

        /* example definitions */
        switch (example)
        {
            case 1:
                /***********************************************
                * Scenario 1:   Geocoding with valid address
                *
                * All address components are valid.
                * NW_OK will be returned.
                ***************************************************/
                strcpy( (char *)geo_req.line1, "299 Lakeside Dr" );
                strcpy( (char *)geo_req.line2, "Oakland, CA" );
                desc = "Valid street address and city -exact match";
                break;
            case 2:
                /***********************************************
                * Scenario 2:   Geocoding with invalid address
                *               number for street in city.
                * Other address components are valid.
                * NW_ERROR_ADDRESS will be returned.
                ***************************************************/
                strcpy( (char *)geo_req.line1, "1010101 Lakeside Dr" );
                strcpy( (char *)geo_req.line2, "Oakland, CA" );
                desc = "Invalid street number";
                break;
            case 3:
                /***********************************************
                * Scenario 3:   Geocoding with invalid street
                *               in city.
                * Other address components are valid.
                * NW_ERROR_STREET will be returned.
                ***************************************************/
                strcpy( (char *)geo_req.line1, "Jakeside Dr" );
                strcpy( (char *)geo_req.line2, "Oakland, CA" );
                desc = "Invalid street name";
                break;
            case 4:
                /***********************************************
                * Scenario 4:   Geocoding with valid cross street
                *               for street in city.
                * All address components are valid.
                * NW_OK will be returned.
                ***************************************************/
                strcpy( (char *)geo_req.line1, "Lakeside Dr @ 21st St" );
                strcpy( (char *)geo_req.line2, "Oakland, CA" );
                desc = "Valid cross street name";
                break;
            case 5:
                /***********************************************
                * Scenario 5:   Geocoding with invalid cross
                *               street for street in city.
                * Other address components are valid.
                * NW_ERROR_CROSS will be returned.
                ***************************************************/
                strcpy( (char *)geo_req.line1, "Lakeside Dr @ Broadway" );
                strcpy( (char *)geo_req.line2, "Oakland, CA" );
                desc = "invalid cross street";
                do_option = 1;  // retry geocoding using 1st option
                break;
            case 6:
                /***********************************************
                * Scenario 6:   Geocoding with invalid city in state
                *
                * No address componenets for line1.
                * NW_ERROR_CITY will be returned.
                ***************************************************/
                strcpy( (char *)geo_req.line1, "" );
                strcpy( (char *)geo_req.line2, "Jokeland, CA" );
                desc = "Invalid City";
                break;
            case 7:
                /***********************************************
                * Scenario 7:   Geocoding with valid postal code 
                *
                * No address componenets for line1.
                * NW_OK will be returned.
                ***************************************************/
                strcpy( (char *)geo_req.line1, "" );
                strcpy( (char *)geo_req.line2, "23456" );
                desc = "Valid postal code";
                break;
            case 8:
                /***********************************************
                * Scenario 8:   Geocoding with invalid postal code 
                *
                * No address componenets for line1.
                * NW_ERROR_ZIP will be returned.
                ***************************************************/
                strcpy( (char *)geo_req.line1, "" );
                strcpy( (char *)geo_req.line2, "99999" );
                desc = "Invalid postal code";
                break;
            case 9:
                /***********************************************
                * Scenario 9:   Geocoding with invalid state
                *
                * No address componenets for line1.
                * NW_ERROR_STATE will be returned.
                ***************************************************/
                strcpy( (char *)geo_req.line1, "" );
                strcpy( (char *)geo_req.line2, "Oakland, ZZ" );
                desc = "Invalid state";
                break;
            case 10:
                /***********************************************
                * Scenario 10:   Geocoding with valid bridge/tunnel name
                *
                * All address components are valid.
                * NW_OK will be returned.
                ***************************************************/
                strcpy( (char *)geo_req.line1, "Holland Tunnel" );
                strcpy( (char *)geo_req.line2, "New York NY" );
                desc = "Valid bridge/tunnel name";
                break;
            case 11:
                /***********************************************
                * Scenario 11:  Geocoding Highway Example 
                *
                * All address components are valid.
                * NW_OK will be returned.
                ***************************************************/
                strcpy( (char *)geo_req.line1, "US-101 N" );
                strcpy( (char *)geo_req.line2, "San Francisco CA" );
                desc = "Valid Highway name";
                break;
            case 12:
                /***********************************************
                * Scenario 12:  Geocoding Alternate Token
                *
                * All address components are valid.
                * NW_OK will be returned.
                ***************************************************/
                strcpy( (char *)geo_req.line1, "500 W 3rd Ave" );
                strcpy( (char *)geo_req.line2, "Anchorage AK" );
                desc = "Valid Alternate token";
                break;
            case 13:
                /***********************************************
                * Scenario 13:  Cardinal and Ordinal Geocoding
                *
                * All address components are valid.
                * NW_OK will be returned.
                ***************************************************/
                strcpy( (char *)geo_req.line1, "19 seventh ave" );
                strcpy( (char *)geo_req.line2, "Brooklyn NY" );
                desc = "Valid cardinal/ordinal street name";
                break;
            case 14:
                /***********************************************
                * Scenario 14:  Geocoding using neighboring city
                *
                * This example requires KLE enterprise edition.
                * All address components are valid.
                * NW_OK will be returned.
                ***************************************************/
                strcpy( (char *)geo_req.line1, "6199 Mission St" );
                strcpy( (char *)geo_req.line2, "San Francisco CA" );
                desc = "Valid street address using Neighboring city";
		geo_req.flag = NW_G_OPT_NEIGHBORING;
                break;
            case 15:
                /***********************************************
                * Scenario 15:  Geocoding Soundex/Phonetic
                *
                * This example requires KLE enterprise edition.
                * All address components are valid.
                * NW_OK will be returned.
                ***************************************************/
                strcpy( (char *)geo_req.line1, "2339 Chopitulas" );
                strcpy( (char *)geo_req.line2, "New Orleans, LA" );
                desc = "Valid street address using Phonetic spelling";
		geo_req.flag = NW_G_OPT_SOUNDEX;
                break;
            case 16:
                /***********************************************
                * Scenario 16:   Geocoding with valid address in canada. 
                *               
                * All address components are valid.
                * NW_OK will be returned.
                ***************************************************/
                strcpy( (char *)geo_req.line1, "752 Burrard St" );
                strcpy( (char *)geo_req.line2, "Vancouver BC" );
                geo_req.flag = 0;
                strcpy( (char *)geo_req.country, "Canada" );
                desc = "Valid Canadian address";
                break;
            default:
                do_examples = 0;
                continue;
        } /* switch */

        printf("\n\nExample %d - %s", example, desc);

        memset (&rt_point, 0, sizeof(RT_POINT));

        opt.limit = 10;
        opt.count = 0;
        memset (&info, 0, sizeof(info));

        display_opt.limit = 10;
        display_opt.count = 0;
                
        do
        {
            /******************************
            * API execution
            ******************************/
            status = callAPIs(
                &geo_req,       /* request struct */
                &rt_point,      /* location result struct */
                &opt,           /* option list result struct */
                &info,          /* description result struct */
                c_hndl,         /* client struct */
                &display_opt);  /* option list result struct */

            /******************************
            * result display
            ******************************/
            errsToDo = displayResults( status,     /* result status */
                &rt_point,                 /* location result struct */
                &display_opt,              /* option list result struct */
                &info);                    /* description result struct */

            do_option = (do_option && errsToDo);

            if (do_option)
            {
                /*****************************************
                * select from proposed options for re-try
                ******************************************/
                do_option = correctionLine(status,  /* result status */
                                        &info,      /* returned address */
                                        &opt,       /* coded option list */
                                        &geo_req);  /* corrected request */
            }

            /* clean up option list */

            for (i = 0; i < opt.limit; i++)
            {
                memset (opt.list[i], 0,  NW_LINE_MAX);
                memset (display_opt.list[i], 0,  NW_LINE_MAX);
            }

            opt.count = 0;
            display_opt.count = 0;

        }
        while (do_option);
    } /* for example */

    /* --- Close the client ---*/
    nwc_disconnect(c_hndl);
    nwc_delete_client_option(c_hndl);

    /* --- Exit Program --- */
    exit ( 0 );

}
