/* 
* (C) Copyright 2000-2004 by Kivera, Inc.  All rights reserved. >>./client/examples/source/kiv_search_supp_info_ex.c.new
echo * 
* This material is protected by U.S. and international 
* copyright laws and may not be reproduced, modified, 
* distributed, publicly displayed or used to create derivative 
* works without the express written consent of Kivera, Inc.  
* The information contained herein is considered a trade 
* secret as defined in section 499C of the penal code of the 
* State of California. This copyright notice may not be 
* altered or removed. 
* 
*/ 
/******************************************************
 * File: kiv_search_supp_info_ex.c                    *
 * -------------------------------------------------- *
 * Description:  An example program for exhibiting    *
 *               proper usage of the                  *
 *               kiv_srchSuppInfo function for        *
 *               searching the supplementary info of  *
 *               all pois belonging to a certain      *
 *               vendor. The search criteria is       *
 *               indicated by populating the          *
 *               POI_SEARCH_FIELD_STRUCT structure    *
 *               which has 3 fields :                 *
 *               fieldNo - Indicates the column name  *
 *                         in the suppInfo table      *
 *               searchType - indicates the condition *
 *                            for matching.           *
 *               searchValue - The search pattern     *
 ******************************************************/

/******************************************************
 *Library Includes                                    *
 ******************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "capis.h"
#include "iso_codes.h"

#ifdef _MSC_VER
#include "win_getopt.h"
#include "WinSock2.h"
#endif

#ifdef LINUX
#include <unistd.h>
#endif
/******************************************************
 * Constant Definitions
 ******************************************************/

/******************************************************
 * Utility function prototypes
 ******************************************************/
/* gets host and port from command-line arguments */
int get_host_and_port(int argc, char *argv[], char **host, int * port);

int callSrchSuppInfo(
    int i, int status, NWC_CLIENT *handle,POI_SRCHSUPPINFO_REQ
    *srchSuppInfo_req, POI_SRCHSUPPINFO_RES *srchSuppInfo_res);
    
/* prints information about  a poi */
void dump_poi(POI_EDIT_STRUCT *poi );



/******************************************************
 * Poi search supplementary info example function prototypes
 ******************************************************/

/* Demonstrates the use of searc supp info API */
int poi_srchSuppInfo( NWC_CLIENT *handle, POI_SRCHSUPPINFO_REQ *req, POI_SRCHSUPPINFO_RES *res );


/******************************************************
 * Main program
 ******************************************************/
int main(int argc, char *argv[]) 
{

    /******************************************************
     * Declarations
     ******************************************************/
    int status = NW_OK;                   /* function return status */

    char *host                   = NULL;  /* host on which server is running */
    int   port                   = 0;     /* port on which server running */
    NWC_CLIENT *handle           = NULL;  /* server connection handle */

	POI_SRCHSUPPINFO_REQ srchSuppInfoReq; /* the srchSuppInfo request */
	POI_SRCHSUPPINFO_RES srchSuppInfoRes; /* the srchSuppInfo response */

    /**********************************************************************
     * Initialize structures
     **********************************************************************/
    memset(&srchSuppInfoReq, 0, sizeof(POI_SRCHSUPPINFO_REQ));
    memset(&srchSuppInfoRes, 0, sizeof(POI_SRCHSUPPINFO_RES));

    /**********************************************************************
     * Get host and port command line arguments
     **********************************************************************/
    if (get_host_and_port(argc, argv, &host, &port) == FALSE)
        exit(0);

    /**********************************************************************
     * Initialize client options
     **********************************************************************/
    handle = nwc_init_client_option(UNPROJECTED);

    if ( NULL == handle )
    {
        printf("Error initializing client options\n");
        exit( 1 );
    }

    /**********************************************************************
     * Connect to location server
     **********************************************************************/
    status = nwc_connect(handle, host, (u_short)port);

    if (status < 0)
    {
        printf("Error connecting to server, status = %d\n", status);
        exit( 1 );
    }

    
    /**********************************************************************
     * poi srchSuppInfo example
     **********************************************************************/
    printf("\n\n"
           "==============================================================\n"
           "Poi search supplementary info example\n"
           "==============================================================\n");
    status = poi_srchSuppInfo( handle, &srchSuppInfoReq, &srchSuppInfoRes);

    
    /* --- Exit Program --- */
    status = nwc_disconnect(handle);

    if (NW_OK != status)
    {
        printf("Error disconnecting from server, status = %d\n", status);
        exit(1);
    }
    
    status = nwc_delete_client_option(handle);

    if (NW_OK != status)
    {
        printf("Error cleaning up client handler, status = %d\n", status);
        exit(1);
    }

    exit ( 0 );
  
}

/******************************************************
 * Print information on how to use this program
 ******************************************************/
void print_usage(char *prog_name)
{
    printf("Usage: %s [-?] -h <host> -p <port>\n"
           "       -? print this message\n"
           "       -h host machine name\n"
           "       -p port number\n\n",
           prog_name);
}

/******************************************************
 * Get host and port command line arguments
 ******************************************************/
int get_host_and_port(int argc, char *argv[], char **host, int * port){

    int helpFlag = FALSE, c;

    while ((c = getopt(argc, argv, "h:p:")) != EOF) {
        switch (c) {
        case 'p':
            /* get the port */
            *port = atoi(optarg);
            break;
        case 'h':
            /* get the host */
            *host = optarg;
            break;
        case '?':
        default:
            /* if unknown argument or "help" flag was specified, turn
             * on the help flag */
            helpFlag = TRUE;
            break;
        }
    }

    /* if host or port was not specified, turn on the help flag */
    if ((*host == NULL) || (*port == 0))
    {
        helpFlag = TRUE;
    }

    if(helpFlag)
    {
        print_usage(argv[0]);
        return FALSE;
    }
    return TRUE;
}


/******************************************************************
 * Clean up memory allocated on heap by srchSuppInfo API
 *****************************************************************/
int cleanup_srchSuppInfo(POI_SRCHSUPPINFO_REQ *srchSuppInfo_req, POI_SRCHSUPPINFO_RES *srchSuppInfo_res)
{
    int status = NW_OK;

    if ( (NULL == srchSuppInfo_res) || (NULL == srchSuppInfo_req) ) 
    {
        printf( "Bad arguments to cleanup_srchSuppInfo\n" );
        return -1;
    }

    status = kiv_freeSrchSuppInfoReq(srchSuppInfo_req);

    if ( NW_OK != status )
    {
        printf("Error freeing search supp info request\n");
    }

    status = kiv_freeSrchSuppInfoRes(srchSuppInfo_res);

    if ( NW_OK != status )
    {
        printf("Error freeing search supp info response\n");
    }

    return status;
}




/************************************************************************
 * A poi search supp info example.
 ************************************************************************/
int poi_srchSuppInfo(
    NWC_CLIENT *handle,                     /* location server handle   */
    POI_SRCHSUPPINFO_REQ   *srchSuppInfo_req,     /* poi srchSuppInfo request */
    POI_SRCHSUPPINFO_RES   *srchSuppInfo_res      /* poi srchSuppInfo response*/
    )
{
    int    status = 0;                    /* for checking error returns */
	int i;

    if ( (NULL == srchSuppInfo_req) || (NULL == srchSuppInfo_res) )
    {
        printf("Error in parameters to poi_srchSuppInfo\n");
        return -1;
    }


    printf("Searching for all pois with vendorId = 911, and\n");
    printf("with the suppInfo.int1 = 101 and suppInfo.int2 > 100.\n\n");
    
	/**********************************************************************
	 * Populate the poi srchSuppInfo request
	 **********************************************************************/
	 srchSuppInfo_req->vendorId   = 911;      


	 /* Populate the search criteria structure. */

	 /******************************************************************/
	 /* Assume we are searching for all pois with vendorId = 911, and  */
	 /* with the suppInfo.int1 = 101 and suppInfo.int2 > 100           */
	 /* i.e. select * from POI_SUPP_INFO where int1=101 AND int2>100   */
	 /*      AND vendorId = 911;                                       */
	 /******************************************************************/

	 srchSuppInfo_req->noOfFields = 2;    /* No. of search conditions  */      
										  /* is 2 since we are checking*/
										  /* values of 2 colums        */

	/* allocate memory for the POI_SEARCH_FIELD_STRUCT */
	srchSuppInfo_req->search = (POI_SEARCH_FIELD_STRUCT*)malloc(sizeof(POI_SEARCH_FIELD_STRUCT) * 2);


	/* Set the search criteria */
	srchSuppInfo_req->search[0].fieldNo    = INTFIELD1;
	srchSuppInfo_req->search[0].searchType = SEARCH_EQUAL_TO;
	strcpy(srchSuppInfo_req->search[0].searchValue,"101");

	srchSuppInfo_req->search[1].fieldNo    = INTFIELD2;
	srchSuppInfo_req->search[1].searchType = SEARCH_GREATER_THAN;
	strcpy(srchSuppInfo_req->search[1].searchValue,"100");

	 srchSuppInfo_req->maxPois    = 5;    /* The no. of pois in result */      

     
    /*********************************************************************
     * Call srchSuppInfo API
     *********************************************************************/

     int callReply = callSrchSuppInfo(i, status, handle, srchSuppInfo_req, srchSuppInfo_res);
     if ( callReply != 0)
         return callReply;


     
     printf("\nSearching for all pois with vendorId = 911, and\n");
     printf("with the suppInfo.int13 < 113 and suppInfo.int15 >= 1015.\n\n");

     /**********************************************************************
      * Populate the poi srchSuppInfo request
      **********************************************************************/
     srchSuppInfo_req->vendorId   = 911;


     /* Populate the search criteria structure. */

     /******************************************************************/
     /* Assume we are searching for all pois with vendorId = 911, and  */
     /* with the suppInfo.int13 < 113 and suppInfo.int15 >= 1015       */
     /* i.e. select * from POI_SUPP_INFO where int13<113 AND int15>1015*/
     /*      AND vendorId = 911;                                       */
     /******************************************************************/

     srchSuppInfo_req->noOfFields = 2;    /* No. of search conditions  */
     /* is 2 since we are checking*/
     /* values of 2 colums        */

     /* allocate memory for the POI_SEARCH_FIELD_STRUCT */
     srchSuppInfo_req->search = (POI_SEARCH_FIELD_STRUCT*)malloc(sizeof(POI_SEARCH_FIELD_STRUCT) * 2);


     /* Set the search criteria */
     srchSuppInfo_req->search[0].fieldNo    = INTFIELD13;
     srchSuppInfo_req->search[0].searchType = SEARCH_EQUAL_TO;
     strcpy(srchSuppInfo_req->search[0].searchValue,"113");

     srchSuppInfo_req->search[1].fieldNo    = INTFIELD15;
     srchSuppInfo_req->search[1].searchType = SEARCH_GREATER_THAN;
     strcpy(srchSuppInfo_req->search[1].searchValue,"1015");

     srchSuppInfo_req->maxPois    = 5;    /* The no. of pois in result */


     /*********************************************************************
      * Call srchSuppInfo API
      *********************************************************************/

     callReply = callSrchSuppInfo(i, status, handle, srchSuppInfo_req, srchSuppInfo_res);
     if ( callReply != 0)
         return callReply;
     



     printf("\nSearching for all pois with vendorId = 911, and\n");
     printf("with the suppInfo.int14 != 1014 and suppInfo.int12 ends with 12.\n\n");

     /**********************************************************************
      * Populate the poi srchSuppInfo request
      **********************************************************************/
     srchSuppInfo_req->vendorId   = 911;


     /* Populate the search criteria structure. */

     /******************************************************************/
     /* Assume we are searching for all pois with vendorId = 911, and  */
     /* with the suppInfo.int1 = 101 and suppInfo.int2 > 100           */
     /* i.e. select * from POI_SUPP_INFO where int14!=1014             */
     /*      AND int12 LIKE %12 AND vendorId = 911;                    */
     /******************************************************************/

     srchSuppInfo_req->noOfFields = 2;    /* No. of search conditions  */
     /* is 2 since we are checking*/
     /* values of 2 colums        */

     /* allocate memory for the POI_SEARCH_FIELD_STRUCT */
     srchSuppInfo_req->search = (POI_SEARCH_FIELD_STRUCT*)malloc(sizeof(POI_SEARCH_FIELD_STRUCT) * 2);


     /* Set the search criteria */
     srchSuppInfo_req->search[0].fieldNo    = INTFIELD14;
     srchSuppInfo_req->search[0].searchType = SEARCH_NOT_EQUAL_TO;
     strcpy(srchSuppInfo_req->search[0].searchValue,"1014");

     srchSuppInfo_req->search[1].fieldNo    = INTFIELD12;
     srchSuppInfo_req->search[1].searchType = SEARCH_LIKE_ENDSWITH;
     strcpy(srchSuppInfo_req->search[1].searchValue,"12");

     srchSuppInfo_req->maxPois    = 5;    /* The no. of pois in result */


     /*********************************************************************
      * Call srchSuppInfo API
      *********************************************************************/

     callReply = callSrchSuppInfo(i, status, handle, srchSuppInfo_req, srchSuppInfo_res);
     if ( callReply != 0)
         return callReply;


     printf("\nSearching for all pois with vendorId = 3, and with the\n");
     printf("suppInfo.datefield15 that matches with \"\".\n\n");



     /**********************************************************************
      * Populate the poi srchSuppInfo request
      **********************************************************************/
     srchSuppInfo_req->vendorId   = 3;


     /* Populate the search criteria structure. */

     /******************************************************************/
     /* Assume we are searching for all pois with vendorId = 3, and    */
     /* with the suppInfo.longtext matches with ""                     */
     /* i.e. select * from POI_SUPP_INFO where date15 matches()        */
     /*      against('') AND vendorId = 3;                             */
     /******************************************************************/

     srchSuppInfo_req->noOfFields = 1;    /* No. of search conditions  */
     /* is 2 since we are checking*/
     /* values of 2 colums        */

     /* allocate memory for the POI_SEARCH_FIELD_STRUCT */
     srchSuppInfo_req->search = (POI_SEARCH_FIELD_STRUCT*)malloc(sizeof(POI_SEARCH_FIELD_STRUCT) * 2);


     /* Set the search criteria */
     srchSuppInfo_req->search[0].fieldNo    = DATEFIELD15;
     srchSuppInfo_req->search[0].searchType = SEARCH_EQUAL_TO;
     strcpy(srchSuppInfo_req->search[0].searchValue,"");

     srchSuppInfo_req->maxPois    = 5;    /* The no. of pois in result */

     callReply = callSrchSuppInfo(i, status, handle, srchSuppInfo_req, srchSuppInfo_res);
     if ( callReply != 0)
         return callReply;


     
     

     printf("\nSearching for all pois with vendorId = 3, and with the\n");
     printf("suppInfo.longtext5 that begin with \"Psychological\".\n\n");
     


    /**********************************************************************
     * Populate the poi srchSuppInfo request
     **********************************************************************/
    srchSuppInfo_req->vendorId   = 3;

       
    /* Populate the search criteria structure. */

    /******************************************************************/
    /* Assume we are searching for all pois with vendorId = 3, and    */
    /* with the suppInfo.longtext begins with "Psychological"         */
    /* i.e. select * from POI_SUPP_INFO where longtext LIKE           */
    /*      'Psychological%' AND vendorId = 3;                        */
    /******************************************************************/

    srchSuppInfo_req->noOfFields = 1;    /* No. of search conditions  */
    /* is 2 since we are checking*/
    /* values of 2 colums        */

    /* allocate memory for the POI_SEARCH_FIELD_STRUCT */
    srchSuppInfo_req->search = (POI_SEARCH_FIELD_STRUCT*)malloc(sizeof(POI_SEARCH_FIELD_STRUCT) * 2);


    /* Set the search criteria */
    srchSuppInfo_req->search[0].fieldNo    = LONGTEXTFIELD5;
    srchSuppInfo_req->search[0].searchType = SEARCH_LIKE_STARTSWITH;
    strcpy(srchSuppInfo_req->search[0].searchValue,"Psychological");

    srchSuppInfo_req->maxPois    = 5;    /* The no. of pois in result */
    
    callReply = callSrchSuppInfo(i, status, handle, srchSuppInfo_req, srchSuppInfo_res);
        return callReply;
}

/*********************************************************************
 * Call srchSuppInfo API
 *********************************************************************/
int callSrchSuppInfo(
    int i,
    int status,
    NWC_CLIENT *handle,
    POI_SRCHSUPPINFO_REQ *srchSuppInfo_req,
    POI_SRCHSUPPINFO_RES *srchSuppInfo_res
    )
{
    status = kiv_srchSuppInfo( handle, srchSuppInfo_req, srchSuppInfo_res);

    if (status < 0)
    {
        printf("poi_srchSuppInfo failed, status = %d\n", status);
    }
    else
    {
        printf("poi_srchSuppInfo successful, status = %d\n", status);
        printf("\nThe number of POIS returned = %d\n\n", srchSuppInfo_res->noOfPois);
        printf("The POIS returned are:\n\n");
        for(i=0; i<srchSuppInfo_res->noOfPois;i++)
        {
            dump_poi(&srchSuppInfo_res->pois[i]);
            printf("\n");
        }
    }

    /* Since both the request and response allocate dynamic memory we */
    /* need to clean up after both.                                   */
    cleanup_srchSuppInfo(srchSuppInfo_req, srchSuppInfo_res );

    return NW_OK;
}




/**************************************************************************
 * Dump information about the poi which matched the search criteria.
 **************************************************************************/
void dump_poi(POI_EDIT_STRUCT *poi)
{
    printf( "POI: vendorId = %d, poiId = %d, numOfNames = %d\n",
            poi->vendorId, poi->poiId, poi->numOfNames );
}
