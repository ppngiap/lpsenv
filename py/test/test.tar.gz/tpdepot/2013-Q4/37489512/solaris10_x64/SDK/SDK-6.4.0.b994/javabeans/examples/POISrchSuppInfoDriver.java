/*
 * � 2001, Kivera, Inc.  This material is protected by U.S. and international
 * copyright laws and may not be reproduced, modified, distributed, publicly
 * displayed or used to create derivative works without the express written
 * consent of Kivera, Inc.  This copyright notice may not be altered or
 * selected.
 *
 */

//package com.kivera.kle;

import java.lang.*;
import java.io.*;
import java.util.*;
import java.beans.*;
import com.kivera.klc.*;
import com.kivera.klc.poi.*;
import java.awt.event.*;

/**
 * This driver class demonstrates how to search various fields in the 
 * supplementary info table in the dynamic poi database.
 * This driver makes use of Kivera's client beans package to access the Kivera
 * Location Engine.
 * It reads the KivPOISuppInfoField object data from the suppInfoField.properties 
 * file and returns all pois having the matching pattern in their supplementary
 * info.
 *
 * @version 1.0
 */
public class POISrchSuppInfoDriver
{

	public static void main(String [] args) 
	{

		// Get the host and port from command line
		int intCounter = 0;
		int intPort    = 0;
		char parm      = '?';
		String strHost = "";

		for(intCounter=0;intCounter<args.length;intCounter++)
		{
			if (args[intCounter].charAt(0)=='-')
			{
				parm = Character.toLowerCase(args[intCounter].charAt(1));
			}
			switch(parm)
			{
				case 'h':
				    strHost = args[++intCounter];
				    break;
				case 'p':
				    intPort = Integer.parseInt(args[++intCounter]);
				    break;
				default:
				    showUsage();
				    break;
			}
		}
		if(strHost==null||strHost.equals("")||intPort<=0)
			showUsage();


		try
		{
			// Obtain the RequestProcessor object which is connected to the
			// KLE at the port and host input.

			RequestProcessor processor     = getProcessor(strHost, intPort);


			// Create the KivPOISrchSuppInfoBean for handling POI selects
			KivPOISearchBean poiSrchSuppInfoBean = 
											new KivPOISearchBean();

			// Connect the bean to the RequestProcessor
			poiSrchSuppInfoBean.addRequestListener(processor);


			// Pick up the values of the poi suppinfo fields from the data file
			KivPOISuppInfoField[] fieldArray = readSuppInfoFields();

			KivPOI [] poiArray;
			// Set the necessary input fields in the bean
			if(fieldArray != null)
			{
				poiArray = poiSrchSuppInfoBean.doSearchSuppInfo(fieldArray, POISrchSuppInfoDriver.vendorId, 25);
			}
			else
			{
				throw new Exception("Could not obtain supp info field search criteria from data file.");
			}

			int status = 0;
			if(status != 0)
			{
				System.out.println("\n");
				System.out.println("The search operation failed with status:" + status);
				System.out.println("\n");
			}
			else
			{
				System.out.println("\n");
				System.out.println("The search operation was successful\n");
				System.out.println("The number of POIs returned = " + poiArray.length + "\n");

				for(int i=0 ; i< poiArray.length; i++)
				{
					System.out.println("POI " + (i+1) + ":: \n");
					System.out.println(poiArray[i].toString());
					System.out.println(poiArray[i].getLongitude());
					System.out.println("\n");
				}
			}

		}
		catch(Exception e)
		{
			System.out.println("\n");
			System.out.println("Exception resolving bean\n");
			e.printStackTrace();
			System.out.println("\n");
		}

	}


	/**
	 * Display executable usage.
	 */
	public static void showUsage()
	{
		System.out.println("usage: " + POISrchSuppInfoDriver.class.getName() + " -h <host> -p <port>");
		System.exit(0);
	}

	private static RequestProcessor getProcessor(String strHost, int intPort)
	{
		RequestProcessor processor = new RequestProcessor();
		processor.setHost(strHost);
		processor.setPort(intPort);
		processor.setProjection(new NoProjection());

		// Connect to the KLE
		processor.setStatus(Constants.CLIENT_STATUS_CONNECTED);

		return processor;
	}


	/**
	 * This method picks up the supp info search field values
	 * from the "suppInfoField.properties" file
	 *
	 */
	private static KivPOISuppInfoField[] readSuppInfoFields()
	{
		// Reading the poi data from the suppInfoField.properties file
		java.util.Locale theLocale = new java.util.Locale("en", "");
		PropertyResourceBundle suppInfoBundle = 
			(PropertyResourceBundle)ResourceBundle.getBundle("suppInfoField", theLocale);

		KivPOISuppInfoField[] fieldArray = null;
		KivPOISuppInfoField suppInfoField= null;

		String strTemp           = null;
		String tmpSuppInfo       = "suppInfo";

		 // The vendor id of the pois being searched.

		 strTemp                 = suppInfoBundle.getString("vendorId");
		 POISrchSuppInfoDriver.vendorId = getIntValue(strTemp);

		//The number of supp info fields to be searched

		 strTemp                 = suppInfoBundle.getString("numOfFields");
		 int numOfFields         = getIntValue(strTemp);


		 fieldArray              = new KivPOISuppInfoField[numOfFields];

		 for( int i=0; i<numOfFields; i++)
		 {

			suppInfoField = new KivPOISuppInfoField();

		 	strTemp = suppInfoBundle.getString(tmpSuppInfo + (i+1) + "-fieldId");

			suppInfoField.setFieldId((short)getIntValue(strTemp));

		 	strTemp = suppInfoBundle.getString(tmpSuppInfo + (i+1) + "-searchType");

			suppInfoField.setSearchType((short)getIntValue(strTemp));

		 	strTemp = suppInfoBundle.getString(tmpSuppInfo + (i+1) + "-searchValue");

			suppInfoField.setSearchValue(strTemp);

			fieldArray[i] = suppInfoField;
			
		 }

		return fieldArray;

	}


	private static int getIntValue(String strValue)
	{
		int intValue = 0;

		try
		{
			intValue = Integer.parseInt(strValue);
		}
		catch(NumberFormatException e)
		{
			intValue = 0;
		}
		return intValue;
	}
	
	private static int vendorId = -2147483648; 
}
