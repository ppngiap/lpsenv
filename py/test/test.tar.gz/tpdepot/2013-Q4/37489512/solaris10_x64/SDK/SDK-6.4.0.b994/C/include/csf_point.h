/* 
* (C) Copyright 2000-2004 by Kivera, Inc.  All rights reserved. >>./client/API/c/libclient/include/csf_point.h.new
echo * 
* This material is protected by U.S. and international 
* copyright laws and may not be reproduced, modified, 
* distributed, publicly displayed or used to create derivative 
* works without the express written consent of Kivera, Inc.  
* The information contained herein is considered a trade 
* secret as defined in section 499C of the penal code of the 
* State of California. This copyright notice may not be 
* altered or removed. 
* 
*/ 
#ifndef _CSF_POINT_H
#define _CSF_POINT_H

#include "kivera.h"

typedef struct csf_point
{
    INT     x;
    INT     y;
    SHORT   z;
} CSF_POINT;

#endif // _CSF_DEF_H

