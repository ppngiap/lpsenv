/* 
* (C) Copyright 2000-2004 by Kivera, Inc.  All rights reserved. >>./client/API/c/libclient/include/navworks.h.new
echo * 
* This material is protected by U.S. and international 
* copyright laws and may not be reproduced, modified, 
* distributed, publicly displayed or used to create derivative 
* works without the express written consent of Kivera, Inc.  
* The information contained herein is considered a trade 
* secret as defined in section 499C of the penal code of the 
* State of California. This copyright notice may not be 
* altered or removed. 
* 
*/ 
#ifndef _NAVWORKS_H
#define _NAVWORKS_H
#include <time.h>
#include "nw_errors.h"
#include "client_windows.h"
#include "kivera.h"
#include "addr_def.h"
#include "PoiInterface.h"

/// Define lengths and sizes used in geocoding.
#define MAX_LEN 1024

/// Maximum num of tokens ("|") in the cLine.
#define MAX_CLINE_TOKS 8

/// Define country codes
#define CTRY_CODE_US          'Z'
#define CTRY_CODE_CANADA      'Y'
#define CTRY_CODE_ITALY       '1'
#define CTRY_CODE_FRANCE      '2'
#define CTRY_CODE_GERMANY     '3'
#define CTRY_CODE_BELGIUM     '5'
#define CTRY_CODE_HOLLAND     '6'
#define CTRY_CODE_LUXEMBURG   '7'
#define CTRY_CODE_SWITZERLAND '8'
#define CTRY_CODE_AUSTRIA     '9'
#define CTRY_CODE_VATICAN     'A'
#define CTRY_CODE_MONACO      'B'
#define CTRY_CODE_LIECHTENSTEIN 'C'
#define CTRY_CODE_SAN_MARINO  'D'
#define CTRY_CODE_ANDORRA     'E'
#define CTRY_CODE_NORTHERN_IRELAND 'F'
#define CTRY_CODE_DENMARK     'G'
#define CTRY_CODE_NORWAY      'H'
#define CTRY_CODE_IRELAND     'I'
#define CTRY_CODE_SPAIN       'M'
#define CTRY_CODE_SWEDEN      'N'
#define CTRY_CODE_FINLAND     'O'
#define CTRY_CODE_ENGLAND     'S'
#define CTRY_CODE_SCOTLAND    'T'
#define CTRY_CODE_WALES       'V'
#define CTRY_CODE_PORTUGAL    'W'
#define CTRY_CODE_UK          'X'

// Define geocoding options; these may be OR'd together
#define NW_G_OPT_STANDARD             0x0001      // warning if changed
#define NW_G_OPT_EXACT                0x0002      // error if different
#define NW_G_OPT_PHONETIC             0x0010      // use phonetic algorithm
#define NW_G_OPT_PHONETIC_ONLY        0x0020      // use phonetic algorithm
#define NW_G_OPT_NO_TOWNOF          0x0040      // remove town of from options list
#define NW_G_OPT_NEIGHBORING          0x0100      // search city & area
#define NW_G_OPT_NEIGH_AREA_ONLY      0x0200      // neighboring area only
#define NW_G_OPT_GEOCODE_ALL_OPTIONS  0x0800      // geocode all options simultaneously on failure

#define NW_G_OPT_SOUNDEX              0x0010      // use soundex(phonetic)
#define NW_G_OPT_STATE                0x8         // search states 
#define NW_G_OPT_POSTAL_ABBREV        0x1000// return the abbreviated strreet type in geocoding results
#define NW_G_OPT_MIXED_CASE           0x2000      // returns the mixed case output in geocoding results
#define NW_G_OPT_PARTIAL              0x4000 // Search input street in the middle of street names
#define NW_G_OPT_DO_NOT_RESOLVE       0x8000; //Always return options
#define NW_G_OPT_CITYCENTER           0x20000; //force city center if error in resolving address
#define NW_G_OPT_PERFECT_SCORE        0x40000; //Suppress options lower than perfect score of 999999

// Tag fields for composite style geocode structure 
// line="| tag= value | tag= value |" where there are actually no blanks
#define TAG_SEPARATOR     "|"
#define TAG_HOUSE_NUMBER  "HN="
#define TAG_STREET_NAME   "SN="
#define TAG_CITY          "CI="
#define TAG_ADMIN1        "A1="
#define TAG_ADMIN2        "A2="
#define TAG_POSTAL_CODE   "PC="

// geocoding option flag bit masks
#define G_OPT_COMP      0x80000000
#define G_OPT_S_LINE    0x40000000

// reverse geocoding option flag bit masks
#define RG_OPT_ROUTABLE 0x80000000
#define RG_OPT_BASENAME 0x40000000

#define MAX_STREET_NAMES      15     // Maximum num of street names returned
#define STREET_TYPE_ATTACHED  0x1    // The Base name and typ are attached
#define STREET_TYPE_BEFORE    0x2    // The Street type ( N, SW) is before 
                                     // the base name

/**
  End defines from geo_std.h
  */

#define NW_SIDE_LEFT     1
#define NW_SIDE_RIGHT    2
#define NW_SIDE_BOTH     3

#define NW_LL_INVALID    0x7fffffff
#define NW_DEG2WORLD     655360.

#define NW_OFFSET_MAX        500
#define NW_MAP_MAX           15000

#define NW_VENDOR_NAME_MAX   60

#define NW_DT_STRT      3
#define NW_DT_POLY      4
#define NW_DT_ADMIN     5
#define NW_DT_TEXT      7
#define NW_DT_ITEXT     11
#define NW_DT_ZIP       9
#define NW_DT_DISPLAY   10

/// output_flags values for route
#define NW_RT_SHAPE                 0x01
#define NW_RT_EXPL                  0x02
#define NW_RT_PERSISTENT			0x80

/// Find the shortest route.
#define NW_RT_SHORTEST_ROUTE        0x20

/// Find the fastest route.
#define NW_RT_FASTEST_ROUTE         0x40

/// Find the best route.(default)
#define NW_RT_BEST                  0x00

/// Explicate city border crossings.
#define NW_EXP_CITY                 0x04

/// Adjust explicated time for traffic intensity.
#define NW_RT_EXPL_TRAFFIC_ADJUST   0x08

/// Calculate traffic incidents along the route
#define NW_RT_TRAFFIC_INCIDENT_POIS 0x100

///Return ETA taking HTD into account
#define NW_ETA_HISTORIC_TRAFFIC 0x200
///Return ETA taking RTT into account
#define NW_ETA_REALTIME_TRAFFIC 0x400


/// Explicate accidents along a route.
#define NW_RT_EXPL_INCIDENT_REPORT  0x10

/// Return the street name types in abbreviated form
#define NW_RT_EXPL_POSTAL_ABBREV 0x1000

/// Return the street names in mixed case
#define NW_RT_EXPL_MIXED_CASE 0x2000

///Return street names in postal abbr in RT_MANV
#define NW_RT_STREET_NAME_POSTAL_ABBREV 0x8000

///Return street names in mixed case in RT_MANV
#define NW_RT_STREET_NAME_MIXED_CASE 0x10000


#define NW_POI_CROWFLIGHT 0
#define NW_POI_DRIVING    1
#define NW_POI_NOADDRESS  5041

///------------------------------------------
/// to be used with nw_init_cache
///------------------------------------------
#define NW_CACHE_NONE    0
#define NW_CACHE_LEVEL_3 0x04
#define NW_CACHE_LEVEL_4 0x08
#define NW_CACHE_LEVEL_5 0x10
#define NW_CACHE_LEVEL_6 0x20

///-------------------------------------------
/// Server types.  Used to optimize data
/// caching based on what types of requests
/// will be served by this server
///-------------------------------------------
#define NWS_ROUTING_SERVER    0x01
#define NWS_GEOCODING_SERVER  0x02
#define NWS_MAP_SERVER        0x04
#define NWS_POI_SERVER        0x08
#define NWS_ALL_SERVER        0x10

#define NWS_SMALL_CACHE           1
#define NWS_MEDIUM_CACHE          2
#define NWS_DEFAULT_CACHE         2
#define NWS_LARGE_CACHE           4

typedef unsigned char uchar;

///--------------------------------------------
/// to be used with the RT_STOPS.stop_flags 
///---------------------------------------------

#define POINT_IS_STOPOVER      0x000001
#define POINT_IS_VIAPOINT      0x000002
#define POINT_IS_ORDERED       0x80000000
#define POINT_STOP_IS_SILENT   0x0101 // POINT_IS_STOPOVER | 0x000100

///--------------------------------------------
/// to be used with RT_REQ.avoid_flags
/// NOTE: if you add new flags, make sure to
///       change NW_AVOID_MASK
///---------------------------------------------
// incur an extra cost for traveling on a toll road.
#define NW_AVOID_TOLL_ROADS    0x00000001
// incur an extra cost for traveling on a toll bridge.
// NW_AVOID_TOLL_BRIDGES is not yet implemented.
// Use NW_AVOID_TOLL_ROADS instead.
#define NW_AVOID_TOLL_BRIDGES  0x00000002 
// incur an extra cost for traveling on a ferry
#define NW_AVOID_FERRIES       0x00000004 
// incur an extra cost for traveling on a bridge
#define NW_AVOID_BRIDGES       0x00000008 
// incur an extra cost for traveling on a freeway
#define NW_AVOID_FREEWAYS      0x00000010
// Avoid not exploring private roads from non-private roads
#define NW_AVOID_NOT_EXPLORING_PRIVATE 0x00000020

// valid avoid bits - bitwise OR of the bits above.
#define NW_AVOID_MASK          0x0000003F 

/// ENhanced Routing Flags
///--------------------------------------------
/// to be used with RT_REQ.ert_setup_flags
///---------------------------------------------
/// Setu Off route points around maneuver points only
#define NW_ERT_GUIDANCE_ONLY_MANEUVER   0x01
/// Off route poitns around maneuver points and other
/// intersections upto a configurable distance
#define NW_ERT_GUIDANCE_MINI_CORRIDOR   0x02
/// Consider all intersections apart from naneuver points
#define NW_ERT_GUIDANCE_FULL_CORRIDOR   0x04

///--------------------------------------------
/// to be used with RT_REQ.ert_out_flags
///---------------------------------------------
/// Return enhanced routing result for initial maneuver only
/// and return the others as persistent off route objects
#define NW_ERT_GUIDANCE_OUT_IMONLY      0x01
/// Return the off route guidance result for all identified
/// off route points
#define NW_ERT_GUIDANCE_OUT_FULL        0x02
/// Return the result in Nav2.0 compatible format
#define NW_ERT_GUIDANCE_OUT_NAV2_FMT    0x04

///-------------------------------------------
/// output flags defining ERT_OUT for enhanced
/// routiong
///-------------------------------------------
/// Dsed to determine whether this ERT_OUT is in 
/// NAV2.0 format
#define NW_ERT_GUIDANCE_OUT_FLAG_NAV2_FMT       0x01
/// Used to determine whether the persistent section
/// of this ERT_OUT is refactored or not
#define NW_ERT_GUIDANCE_OUT_FLAG_RF_PERSISTENT  0x02

///--------------------------------------------
/// to be used with RT_REQ.edit_flags
/// NOTE: if you add new flags, make sure to change 
/// NW_ED_CONSIDER_MASK
///---------------------------------------------
// adjust impedance if CLIENT_FLAG_1  is set
#define NW_ED_CONSIDER_CLIENT_FLAG_1  0x00000001 
// adjust impedance if CLIENT_FLAG_2  is set
#define NW_ED_CONSIDER_CLIENT_FLAG_2  0x00000002 
// adjust impedance if CLIENT_FLAG_3  is set
#define NW_ED_CONSIDER_CLIENT_FLAG_3  0x00000004 
// adjust impedance if CLIENT_FLAG_4  is set
#define NW_ED_CONSIDER_CLIENT_FLAG_4  0x00000008 
// adjust impedance if CLIENT_FLAG_5  is set
#define NW_ED_CONSIDER_CLIENT_FLAG_5  0x00000010 
// adjust impedance if CLIENT_FLAG_6  is set
#define NW_ED_CONSIDER_CLIENT_FLAG_6  0x00000020 
// adjust impedance if CLIENT_FLAG_7  is set
#define NW_ED_CONSIDER_CLIENT_FLAG_7  0x00000040 
// adjust impedance if CLIENT_FLAG_8  is set
#define NW_ED_CONSIDER_CLIENT_FLAG_8  0x00000080 
// adjust impedance if CLIENT_FLAG_9  is set
#define NW_ED_CONSIDER_CLIENT_FLAG_9  0x00000100 
// adjust impedance if CLIENT_FLAG_10 is set
#define NW_ED_CONSIDER_CLIENT_FLAG_10 0x00000200 
// adjust impedance if CLIENT_FLAG_11 is set
#define NW_ED_CONSIDER_CLIENT_FLAG_11 0x00000400 
// adjust impedance if CLIENT_VALUE_1 is set
#define NW_ED_CONSIDER_CLIENT_VALUE_1 0x00001000 
// adjust impedance if CLIENT_VALUE_2 is set
#define NW_ED_CONSIDER_CLIENT_VALUE_2 0x00002000 
// adjust impedance if CLIENT_VALUE_3 is set
#define NW_ED_CONSIDER_CLIENT_VALUE_3 0x00004000 
// adjust impedance if CLIENT_VALUE_4 is set
#define NW_ED_CONSIDER_CLIENT_VALUE_4 0x00008000 
// ignore all edits (including disabled links)
#define NW_ED_CONSIDER_NONE           0x80000000 
// valid bits - bitwise OR of the bits above
#define NW_ED_CONSIDER_MASK           0x8000FFFF 

#define DEFAULT_HEAP 0x000000
#define SMALL_HEAP   0x000001
#define MEDIUM_HEAP  0x000002
#define LARGE_HEAP   0x000004

#define USE_DEFAULT  0x80000000


/* --- Definitions for L_C_LINK->r_inf --- */
#define NW_ROAD_RAMP               0x0000001   //ramp
#define NW_ROAD_BRIDGE             0x0000002   //bridge
#define NW_ROAD_TUNNEL             0x0000004   //tunnel
#define NW_ROAD_COMPLEX            0x0000008   //road complex
//undefined traffic area
#define NW_ROAD_UNDEFINED_TA       0x0000010   
#define NW_ROAD_INDESCRIBABLE      0x0000020   //indescribable
#define NW_ROAD_MANOEUVER          0x0000040   //maneuver type
#define NW_ROAD_ROUNDABOUT         0x0000080   //roundabout
#define NW_ROAD_SPECIAL_TF         0x0000100   //special
#define NW_ROAD_TOLLBOTH           0x0000200   //tollbooth
#define NW_ROAD_HOV                0x0000400   //HOV lane 
#define NW_ROAD_TRUCK_BUS          0x0000800   //truck/bus lane
//single digitized divided road
#define NW_ROAD_SD_DIVIDED         0x0001000   
//double digitized divided road
#define NW_ROAD_DD_DIVIDED         0x0002000   
#define NW_ROAD_REVERSIBLE         0x0004000   //reversible road
#define NW_ROAD_PRIVATE_ROAD       0x0008000   //private road
#define NW_ROAD_PUBLIC_VEH         0x0010000   //public vehicle road
#define NW_ROAD_AUTOMOBILE         0x0020000   //automobile road
#define NW_ROAD_FARM_ROAD          0x0040000   //farm road
#define NW_ROAD_CLOSED             0x0080000   //closed road
#define NW_ROAD_GEOMETRY_ONLY      0x0100000   //geometry only road
#define NW_ROAD_OPEN_CONSTRUCT     0x0200000   //open construction
#define NW_ROAD_UNOFFICIAL_GEO     0x0400000   //unofficial link
#define NW_ROAD_DIVIDED_LINK       0x0800000   //divided road
//controlled access road
#define NW_ROAD_CONTROLLED_ACCESS  0x1000000   



//values for Maneuver type
#define     MANV_TYPE_GO                   1
#define     MANV_TYPE_FORK                 2
#define     MANV_TYPE_FREEWAY_EXIT         3
#define     MANV_TYPE_STAY                 4
#define     MANV_TYPE_BECOME               5
#define     MANV_TYPE_START_OUT            6
#define     MANV_TYPE_U_TURN               7
#define     MANV_TYPE_FREEWAY_ENTER        8
#define     MANV_TYPE_FREEWAY_INTERCHANGE  9
#define     MANV_TYPE_STAY_ON_FREEWAY      10
#define     MANV_TYPE_BORDER_X             11
#define     MANV_TYPE_STOP                 12
#define     MANV_TYPE_NOP_RTE              13
#define     MANV_TYPE_TRAVEL               14
#define     MANV_TYPE_ROUND_ABOUT          15
#define     MANV_TYPE_FERRY                16
#define     MANV_TYPE_INCIDENT             17
#define     MANV_TYPE_EXIT_ROUND_ABOUT     18
#define     MANV_TYPE_UNDEFINED            0

//values for Maneuver direction
#define    MANV_DIRECTION_TYPE_STRAIGHT        1
#define    MANV_DIRECTION_TYPE_SLIGHT_RIGHT    2
#define    MANV_DIRECTION_TYPE_RIGHT           3
#define    MANV_DIRECTION_TYPE_SHARP_RIGHT     4
#define    MANV_DIRECTION_TYPE_BACK_RIGHT      5
#define    MANV_DIRECTION_TYPE_BACK_LEFT       6
#define    MANV_DIRECTION_TYPE_SHARP_LEFT      7
#define    MANV_DIRECTION_TYPE_LEFT            8
#define    MANV_DIRECTION_TYPE_SLIGHT_LEFT     9
#define    MANV_DIRECTION_TYPE_U_TURN          10
#define    MANV_DIRECTION_TYPE_EXIT            11
#define    MANV_DIRECTION_TYPE_EASY_RIGHT      12
#define    MANV_DIRECTION_TYPE_SEVERE_RIGHT    13
#define    MANV_DIRECTION_TYPE_SEVERE_LEFT     14
#define    MANV_DIRECTION_TYPE_EASY_LEFT       15
#define    MANV_DIRECTION_TYPE_UNDEFINED       0

//values for heading direction
#define    MANV_HEADING_TYPE_NORTH             1
#define    MANV_HEADING_TYPE_NORTHEAST         2
#define    MANV_HEADING_TYPE_EAST              3
#define    MANV_HEADING_TYPE_SOUTHEAST        4
#define    MANV_HEADING_TYPE_SOUTH             5
#define    MANV_HEADING_TYPE_SOUTHWEST         6
#define    MANV_HEADING_TYPE_WEST              7
#define    MANV_HEADING_TYPE_NORTHWEST         8
#define    MANV_HEADING_TYPE_UNDEFINED         0

//values for destination type
#define    MANV_DESTINATION_TYPE_FIRST         1
#define    MANV_DESTINATION_TYPE_STOP          2
#define    MANV_DESTINATION_TYPE_DST           3
#define    MANV_DESTINATION_TYPE_INTERMEDIATE  4
#define    MANV_DESTINATION_TYPE_NONE          0

//values for ramp type
#define    MANV_RAMP_TYPE_ON    1
#define    MANV_RAMP_TYPE_OFF   2
#define    MANV_RAMP_TYPE_JOIN  3
#define    MANV_RAMP_TYPE_NONE  0

//vlaues for sign type
#define    MANV_SIGN_TYPE_BOUND   1
#define    MANV_SIGN_TYPE_TOWARD  2
#define    MANV_SIGN_TYPE_EXIT    3
#define    MANV_SIGN_TYPE_OTHER   4
#define    MANV_SIGN_TYPE_NONE    0

//values for streetname flag values
#define    PREFIX_ATTACHED          0x1
#define    TYPE_ATTACHED            0x2
#define    TYPE_AFTER_BASE          0x4

// RT_INFO flags
#define		RT_INFO_SHAPE_POINTS		NW_RT_SHAPE
#define		RT_INFO_EXPLICATION			NW_RT_EXPL
#define		RT_INFO_TRAFFIC_IMPACT		NW_RT_EXPL_TRAFFIC_ADJUST
#define		RT_INFO_TRAFFIC_REPORT		NW_RT_EXPL_INCIDENT_REPORT
#define 	RT_INFO_TRAFFIC_INCIDENT_POIS NW_RT_TRAFFIC_INCIDENT_POIS
#define 	RT_INFO_VALIDATE              0x200

//defines flag to enable CVR explication
#define CVR_EXPLICATION

//Values for freeway identification
#define MANV_FWY_ENCODING_TRUE     1
#define MANV_FWY_ENCODING_FALSE    0
#define MANV_FWY_ENCODING_UNKNOWN -1

typedef struct
{
	int mapID;
	int mapDbID;
	int type;
	int timestamp;
} VMAP_ID;

/*
**  Route Point struct
*/

typedef struct rt_point
{
	short    spot;          /* location of point on link (%) */
	short    side;          /* Side of link (NW_SIDE_*) */
	VMAP_ID  vmapID;        /* Map containing point */
	int      link;          /* CSF link id */
	int      node;          /* CSF start node id */
	int      world_long;    /* Longitude */
	int      world_lat;     /* Latitude */
	int      d_world_long;  /* Displaced Longitude (with offset) */
	int      d_world_lat;   /* Displaced Latitude (with offset) */
	unsigned char street[NW_STREET_SIZE]; /* base name of street
							                 where point located */
} RT_POINT;

//----------------------------------------------------------------
//
// Struct - RT_STOP
// Purpose - A list of these structs will be passed into the 
//           routing engine via RT_REQ.  This will maintain
//           a list of stopovers and via points to be calculated
//           in routing.
//
// Values for stopflags:
//
// POINT_IS_STOPOVER - indicate this point is a stopover point
// POINT_IS_VIAPOINT - indicate this point is a via point
// POINT_IS_ORDERED  - for future use, indicates this point is 
//                     ordered
//
//----------------------------------------------------------------

typedef struct rt_stop
{
	int      stop_flags;   //flags (see above)
	RT_POINT *stop_info;   // Geo-coded Via point or Stopover point 
} RT_STOP;


/*
** Explore request struct
*/
typedef struct rt_req
{
	int       output_flags;      /* type of output desired
							        (shape, explication, etc.) */
	int       avoid_flags;       /* cost adjustments for
							        compiled link data - NW_AVOID_*
							      */
	int       edit_flags;        /* cost adjustments for
							        edited link data - NW_ED_* */
	char      lang1[6];          /* first explication language (5 chars + zero) */
	char      lang2[6];          /* second explication language (5 chars + zero) */
	char      unit1;             /* first  explication unit of 
							        measure */
	char      unit2;             /* second explication unit of 
							        measure */
	int       max_num_sols;      /* maximum number of
							        solutions to search for */
	int       max_extra_links;   /* maximum number of extra
							        links expanded after
							        first soln is found */
	int       heap_size;         /* affects number of potential
							        solutions that can be
							        maintained during exploration */
	time_t    time_of_travel;    /* 0 will result in current time */
	RT_POINT *src;               /* Start point */
	RT_POINT *dst;               /* Destination points */
	short     stops_cnt;         /* count of stopovers and 
							        viapoints */
	short     ordered;           /* 1 if stopovers are ordered,
							        0 otherwise */
	RT_STOP  *rt_stops;          /* List of stopovers and via 
							        points  */
	int       mapDbPref[NW_DB_MAX]; /* databases to use in routing
							             (pref[0] == favorite) */
	int      start_soln_idx;     /* index of first route solution needed */
	int      end_soln_idx;       /* index of last route solution needed */
    char     profile_file_name[NW_LINE_MAX];  /*profile file name for complex vehicle restriction */
    int      rt_vehicle_flag;

    /// Enhanced Routing Flags
    unsigned short    ert_setup_flags;
    unsigned short    ert_out_flags;

    // The distance after which the first maneuver should come in the route
    short firstManvDistance;
    
    //Control variable for using bearing during route calculation
    char useBearing;
    
    //Bearing value
    double bearing;
    
    //Return failure if bearing is used unsuccessfully
    char bearingFailRet;

    //Percentage of length of first maneuver to shift the first offRoute point
    double shift_percent;
} RT_REQ;


/*
** Route link structure - single link in a route
*/
typedef struct rt_link
{
	int mapDbID;     /* database containing link */
	int cell;        /* CSF Cell id */
	int link;        /* CSF Link id */
	int node;        /* CSF start Node id */
	int idx;         /* index of link's first 
						shape point in rt_shp */
	int srcid_cnt;   /* number of source ids */
	int srcid_idx;   /* index of first source id */
} RT_LINK;

typedef struct manv_street_info
{
	char ramp_type;
	char *base_name;
	char *prefix;
	char *suffix;
	char *type;
	char *city;
	char *admin1;
	char *country;
	char flag;

} MANV_STREET_INFO;

typedef struct manv_sign_info
{
	char type;			/* sign type e.g. towards, branch, exit */
	char *text;			/* sign text */
    unsigned int srcid;
} MANV_SIGN_INFO;

typedef struct
{
	int type;				  /* Categorizes the maneuver */
	short direction;		  /* The direction */
	char heading;			  /* heading direction for START OUT maneuver */
	char dst_type;			  /* Destination categorization */

	int world_long;           /* longitude where maneuver occurs */
	int world_lat;            /* latitude where maneuver occurs */
	int shp_pt_idx;           /* index of first shape point of the maneuver */ 
	int travel_dist;          /* distance of maneuver in decameters */
	int travel_time;          /* travel time for maneuver in secs */

	char exit_cnt;			  /* Exits in roundabout with reference to entry */

	uchar text[NW_LINE_MAX];  /* explication (first lang) */
	uchar text2[NW_LINE_MAX]; /* explication (second lang) */
	char sign_cnt;			  /* Signs in the maneuver */
	MANV_SIGN_INFO *signs;		  /* Info list for all the signs in the maneuver */
	MANV_STREET_INFO src_street;   /* Source street information */
	MANV_STREET_INFO dst_street;   /* Destination street information */
	MANV_STREET_INFO misc_street;  /* Support street info for u-turn, roundabout, 
								 towards maneuvers */
    char arteryLevel;          /* Artery level of the first link of the maneuver*/
    char isFreeway;           /*  Indicates a freeway or non freeway maneuver*/

    int linkIX;     /* The index to the first link in links array of this maneuver */
} RT_MANV;



//-------------------------------------------------------------
//
// Struct - POLY_LN
// Purpose - used to maintain shape points associated with 
//           a link in a route.
//
//-------------------------------------------------------------

typedef struct poly_ln
{
	int mapDbID;    /* database containing link */
	int src_id;     /* vendor source id for this link */
	int rec_num;    /* record number in shape files */
	short num_pts;  /* number of shape points for this record */
	int pts;        /* an index into the rt_out->rt_shp
					   point array for the points */
} POLY_LN;


/* --------------------------------------------
 * used with RT_CROSSOVER.type
 * ------------------------------------------- */
enum crossoverType
	{
	CROSSOVER_IS_SOURCE       = 0x001000,
	CROSSOVER_IS_DESTINATION  = 0x002000,
	CROSSOVER_IS_XDB_SOURCE   = 0x004000,
	CROSSOVER_IS_XDB_DEST     = 0x008000,
	CROSSOVER_IS_STOPOVER     = 0x010000,
	CROSSOVER_ILLEGAL_TYPE    = 0x100000
	};
	

//------------------------------------------------------------------
//
// Struct - RT_CROSSOVER
// Purpose - A list of these structs will be passed out of the 
//           routing engine via RT_OUT.  These points mark the 
//           links where we only travelled on part of a link.  This 
//           occurs at the route source and destination, 
//           intermediate sources/destinations caused by database 
//           crossovers, and at stopovers.
//
//------------------------------------------------------------------

typedef struct rt_crossover
{
	enum crossoverType type;    // cross-database source, 
	int           index;        // index of crossover link in 
							    // RT_OUT.rt_link and RT_OUT.rt_poly
	RT_POINT      point;        // crossover point
} RT_CROSSOVER;


/*
** RT_OUT - Output result
*/

typedef struct rt_out
{
	int          status;       /* outcome of routing - 0 for
							    * success, < 0 for failure */
	int          output_flags; /* types of output produced */
	short        rt_src_spot;  /* position of source on first link
							    * (percentage) */
	short        rt_dst_spot;  /* position of destination on last 
							    * link (percentage) */
	int          rt_ttime;     /* travel time in seconds */
	int          rt_length;    /* length of route in meters */

        /* kiv00011959: Partial Route Enhancement. Two new variables added     */
        int          rt_plength_cnt;      /* no of partial routes              */
        int          *rt_plengths;        /* lengths of partial routes in mtr  */
 
        /* kiv00012161: Partial Route Enhancement for Time */
        //Variable to store partial times. The count of this array will be same
        //as the partial lengths
        int          *rt_ptimes;          /* time taken to travel partial routes in seconds */

	int          rt_scnt;      /* number of shape points in route */
	int          rt_lcnt;      /* number of links in route
							    * (size of rt_poly, rt_link) */
	int          rt_mcnt;      /* number of maneuvers in route */
	int          rt_ptcnt;     /* count of points in
							      point shape file (rt_pshp) */
	int          *rt_shp;      /* array of shape points x1,
							    * y1, x2, y2, ... */
	int          *rt_stop_idx; /* (indexes into rt_shp)/2 for
							    * stopover pts  */
	POLY_LN      *rt_poly;     /* one for each link in a route,
							    * see POLY_LN for description  */
	RT_LINK      *rt_link;     /* one for each link in a route,
							    * see RT_LINK for description */
	RT_POINT     *rt_pshp;     /* list of points for the
							    * point shape file  */
	int           rt_crossover_count;  /* size of rt_crossovers */
	RT_CROSSOVER *rt_crossovers;       /* database crossovers */
	RT_MANV      *rt_manv;     /* route maneuvers (directions) */
	int           route_dbs[NW_DB_MAX];      /* databases used in 
							                  * routing */
	int           explication_dbs[NW_DB_MAX]; /* databases used in 
							                   * explication */
	uchar         rt_emsg[NW_LINE_MAX];      /* error message, 
							                  * if error occurred */
} RT_OUT;


typedef struct rt_src_link
{
	int   srcid;           /* source id                      */
	int   shape_idx;       /* first shape point index for 
							  corresponding source id        */
	int   shape_cnt;       /* number of shape points for 
							  corresponding source id        */
} RT_SRC_LINK;

typedef struct rt_persistent
{
	int version;            /* Version number of the persistent route release */
	int			num_ids;	/* Number of persistent ids */
	int	*persistent_ids;	/* Array of persistent ids */
	int avoid_flags;	/* The avoid flags in the route query */
	RT_POINT	src;	/* Source point. */
	RT_POINT	dest;	/* Destination point */
} RT_PERSISTENT;

/*Enhanced maneuver changes*/
typedef struct
{
    int x;
    int y;
    int linkix;
}ERTLinkShapePt;

typedef struct ert_link
{
    int cell;
    int node;
    int link;
    int shapeptix;
    int shapeptcnt;
    int thisix;
    int nextix;
    char turn;
    char nodeflag;

    // MADHU: Not to be used as per Arch meeting
    int manvid;
    int rtoutshpix;
    int length;
    int ttime;
}ERT_LINK;

typedef struct orlinkix
{
    int num_links;
    int *link_ixs;
}OFF_ROUTE_LINKIX;

typedef struct ert_result
{
    int manvid;
    int ert_link_cnt;
    int ert_shp_pt_cnt;
    int ert_orlix_cnt;

    ERT_LINK *links;
    ERTLinkShapePt *shapePts;
    unsigned int *inrouteorl;
    OFF_ROUTE_LINKIX *orlinks;
}ERT_RESULT;

typedef struct persistent_orp
{
    char type;
    char isFwy;
    int manv_id;
    int lon;
    int lat;
    int shape_ix;
    int l6l_off_rt_pt_linkix;

    int num_links_in_route;
    int num_in_rt_off_rt_links;
    int *num_off_route_links;

    RT_LINK *links_in_route;

    // MADHU: Not to be used any more as per arch meeting
    //int     *links_in_route_manv_id;
    //int     *links_in_route_shp_ix;
    // END MADHU

    int *in_rt_off_rt_links;
    int *in_rt_off_rt_links_shape_pts;
    RT_LINK **off_route_links;
}PERSISTENT_ORP;

typedef struct persistent_GROUP
{
    int dbID;
    int numPersistent;
    PERSISTENT_ORP *persistent_orps;
    int persistent_buf_size;
    unsigned char *persistent_buf;
}PERSISTENT_GROUP;

typedef struct ert_req
{
    RT_REQ *rt_req;
    unsigned short out_flags;
    int    numPersistentGroups;
    PERSISTENT_GROUP *persistent_groups;
}ERT_REQ;

typedef struct ert_out
{
    int size;
    unsigned short flags;
    int dbID;
    int result_cnt;
    int *result_size;
    ERT_RESULT *result;
    int persistent_cnt;
    int persistent_size;
    PERSISTENT_ORP *persistent_orps;
    int persistent_buf_size;
    unsigned char *persistent_buf;
}ERT_OUT;

typedef struct ert_out_array
{
    int status;
    int count;
    ERT_OUT *ert_out;
}ERT_OUT_ARRAY;

typedef struct rt_soln
{
	int          rt_ttime;            /* travel time in seconds            */

    /// Travel Time with HTD/RTT into account
    int          rt_expected_ttime;

	int          rt_length;           /* length of route in meters         */

    /* kiv00011959: Partial Route Enhancement. Two new variables added     */
    int          rt_plength_cnt;      /* no of partial routes              */
    int          *rt_plengths;        /* lengths of partial routes in mtr  */

    /* kiv00012161: Partial Route Enhancement for Time */
    //Variable to store partial times. The count of this array will be same
    //as the partial lengths
    int          *rt_ptimes;          /* time taken to travel partial routes in seconds */

	int          rt_maneuver_cnt;     /* number of maneuvers in route      */
	int          rt_crossover_cnt;    /* size of crossovers                */
	int          rt_shp_pt_cnt;       /* number of shape points in route   */
	int          rt_link_cnt;         /* number of links in route          */
	int          rt_srcid_cnt;        /* count of source ids               */
	int          rt_stpover_cnt;      /* count of stopovers                */
	int          *rt_shp_pt_array;    /* shape points as x1, y1, x2, y2 .. */
	RT_LINK      *rt_link_array;      /* one for each link in a route,
							           * see RT_LINK for description       */
    char         *rt_nodeflags;       /* A char value of 0 or 1 specifyign whether
                                       * this links node is its end or start node */
	RT_SRC_LINK  *rt_src_link_array;  /* the source ids and associated shape
										 points                            */
	int          *rt_stpoveridx_array;/* (indexes into rt_shapept_array)/2 for
							           * stopover pts                      */
	RT_CROSSOVER *rt_crossover_array; /* database crossovers               */
	RT_MANV      *rt_maneuver_array;  /* route maneuvers (directions)      */
	int           rt_expldb_array[NW_DB_MAX]; /* dbs used in explication   */
	int           rt_db_array[NW_DB_MAX];    /* databases used in routing */
	uchar         rt_description[NW_LINE_MAX];/* route description str     */
	int           rt_orig_time;      /* Base travel time of route */
	int           rt_pois_cnt;       /* Number of incidents on the route */
	POI_EDIT_STRUCT* rt_pois_array;  /* Array of pois on route */
	RT_PERSISTENT rt_persistent;		/* the persistent route description */

#ifdef CVR_EXPLICATION
    int total_no_of_points;
    int *array_with_cvr_details;
    int cvr_info;
#endif

/*Enhanced maneuver changes*/
    int           ert_status;
    int           ert_out_cnt;
    ERT_OUT      *ert_out_array;
} RT_SOLUTION;


/*
 * The array of route solutions returned by KLE
 */
typedef struct rt_res
{
	int          status;         /* the overall status of route request */
	int          soln_cnt;       /* the number of solutions returned */
	RT_SOLUTION *rt_soln_array;  /* the route response structures */
} RT_RES;

typedef struct rt_info_req
{
	int flag; 	        /* RT_INFO flags */
	int time_of_travel; /* 0 will result in current time */
	int unit;
	char lang[6];
	RT_PERSISTENT rt_persistent;
} RT_INFO_REQ;

typedef struct rt_geo_out
{
	int    status;    /* error code, 0 == success.  If error occurs,
						 remaining fields should not be used */
	int    geo_dbs[NW_DB_MAX]; /* databases used in geocoding */
	RT_OUT route;
} RT_GEO_OUT;


typedef struct
{
	unsigned short majorId;
	unsigned short minorId;
	unsigned char name[NW_LINE_MAX];
} POI_CATEGORY;

typedef struct
{
	POI_CATEGORY* listDef;
	int countDef;

} POI_LANG_CATEGORY_LIST;
typedef struct
{
	int vid;
	unsigned char name[NW_VENDOR_NAME_MAX];
} POI_VID;

typedef struct
{
	int west;
	int east;
	int south;
	int north;
	int level;
} MAPID_REQ;

typedef struct
{
	int count;
	int mapID[NW_MAP_MAX];
} MAPID_OUT;


/* ---  SHORT Link --- */
typedef struct s_c_link
{
	unsigned short      kind;
	unsigned short      s_cnt;
	unsigned int        area;
} S_C_LINK;


typedef struct s_link
{
	S_C_LINK    sc_lnk;
	int         s_idx;
} S_LINK;


/* --- CSF_ADMIN --- */
typedef struct csf_admin
{
	int         l_cnt;
	int         s_cnt;
	S_LINK      *s_lnk;
	int         *s_buf;
} CSF_ADMIN;


/* --- CSF_POLY --- */
typedef struct csf_poly
{
	int         l_cnt;
	int         s_cnt;
	S_LINK      *s_lnk;
	int         *s_buf;
} CSF_POLY;


/* ---  LONG Link --- */
typedef struct l_c_link
{
	int         numb;
	int         snode;
	int         enode;
	int         r_inf;
	unsigned short      kind;
	unsigned short      s_cnt;
} L_C_LINK;


typedef struct l_link
{
	L_C_LINK    lc_lnk;
	int         s_idx;
} L_LINK;


/* --- CSF_STRT_DSP --- */
typedef struct csf_strt
{
	int         l_cnt;
	int         s_cnt;
	L_LINK      *l_lnk;
	int         *s_buf;
} CSF_STRT;


typedef struct kvimg_link
{
	unsigned short  s_idx;
	short       flag;
	unsigned short  kind;
	unsigned short  s_cnt;

} KVIMG_LINK;


typedef struct csf_display
{
	int             l_cnt;
	int             s_cnt;
	KVIMG_LINK      *k_lnk;
	int             *s_buf;

} CSF_DISPLAY;



/* ---  SHORT Node --- */
typedef struct s_c_node
{
	unsigned short      kind;
	unsigned short      angle;
	unsigned short      nm_cnt;
	short               artery;
	unsigned short      minLevel;
	unsigned short      maxLevel;
	int         pos_x;
	int         pos_y;
	char        country;
	char        state;
} S_C_NODE;


typedef struct s_node
{
	S_C_NODE    sc_nde;
	int         nm_idx;
} S_NODE;


/* --- CSF_LAND --- */
typedef struct csf_land
{
	int         n_cnt;
	int         nm_bsz;
	S_NODE      *s_nde;
	uchar        *nm_buf;
} CSF_LAND;


typedef struct
{
	short x;
	short y;
	int zip;
#if defined(_WINNT) || defined(_MSC_VER)
	short k_near;
#else
	short near;
#endif
} ZIPCODE;

typedef struct
{
	uchar z_cnt;
	ZIPCODE *zips;
} CSF_ZIP;


/**
  Formerly from geo_std.h
  */

/// Line1/Line2 format for input into a geocoding request
/// If this changes, also update COMPGEO_REQ.
typedef struct
{
    int offset;     // offset from link (distance of building
                    // from street)
    char unit;      // unit of offset
    int flag;       // option flag
    int cfield;     // cline id
    int mapDbPref[NW_DB_MAX];
    unsigned char line1[NW_LINE_MAX];    // address line 1
    unsigned char line2[NW_LINE_MAX];    // address line 2
    unsigned char line3[NW_LINE_MAX];    // reserved
    unsigned char country[NW_LINE_MAX];  // address country
    unsigned char cline[NW_LINE_MAX];    // correction address line
    unsigned char lang[NW_LINE_MAX];     //  lang
} GEO_REQ;

/// Component format for input into a geocoding request
/// If this changes, also update GEO_REQ.
typedef struct
{
    int offset;      // offset from link (distance of building from
                     // street)
    char unit;       // unit of offset
    int flag;        // option flag
    int cfield;      // cline id
    int mapDbPref[NW_DB_MAX];
    unsigned char house_number[NW_ADDRESS_SIZE];
    unsigned char street_name[NW_STREET_SIZE];
    unsigned char city[NW_CITY_SIZE];
    // state (USA) or province (CAN)
    unsigned char admin1[NW_STATE_SIZE];
    // region; e.g. county in USA; i.e. line3 in GEO_REQ
    unsigned char admin2[NW_LINE_MAX];
    unsigned char postal_code[NW_ZIP_SIZE];
    unsigned char country[NW_COUNTRY_SIZE];
    unsigned char cline[NW_LINE_MAX];    // correction address line
    unsigned char lang[NW_LINE_MAX];    //  lang

} COMPGEO_REQ;

/// Geocoding option list
typedef struct
{
    unsigned char **list;
    int limit;
    int count;
} GEO_OPTIONS;


enum ADMIN_LEVEL_TYPE
{
    LEVEL_UNKNOWN   = 0,
    LEVEL_COUNTRY   = 1,
    LEVEL_STATE     = 2,
    LEVEL_CITY      = 3
};

typedef struct
{
    enum ADMIN_LEVEL_TYPE   level_type;
    unsigned char           level_name[NW_LINE_MAX];
    
} ADMIN_LEVEL;


enum TYPE_OF_NAME
{
    UNKNOWN   = 0,
    PRIMARY   = 1,
    SECONDARY = 2
};

/// The component street name
typedef struct
{
    char prefix[MAX_PREFIX_LEN];
    char basename[NW_STREET_SIZE];
    char type[MAX_TYPE_LEN];
    char suffix[MAX_SUFFIX_LEN];
    char typeflag;
    enum TYPE_OF_NAME typeofname;

} STREET_NAME;

/// The component street name collection
typedef struct
{
    int count;  // The number of names populated in the following names array
    STREET_NAME names[MAX_STREET_NAMES];
} STREET;


/// Geocoding information returned to client.
typedef struct
{
    int status;
    int warningcode;
    int crossGeoTypeCode;
    int srcId;
    ADMIN_LEVEL   levels[5];
    unsigned char country[NW_COUNTRY_SIZE];
    unsigned char state[NW_STATE_SIZE];
    unsigned char city[NW_CITY_SIZE];
    unsigned char base_city[NW_CITY_SIZE];
    unsigned char original_city[NW_CITY_SIZE];
    unsigned char zip[NW_ZIP_SIZE];
    unsigned char street[NW_STREET_SIZE];
    unsigned char address[2*NW_ADDRESS_SIZE];
    unsigned char xstreet[NW_STREET_SIZE];
    STREET   streetnames;   // The list of alternate componentized street names
    STREET   xstreetnames;  // The list of alternate componentized street names
    unsigned char outputLine1[NW_LINE_MAX];
    unsigned char outputLine2[NW_LINE_MAX];
    unsigned char outputLine3[NW_LINE_MAX];
} GEO_INFO;


//***********************************************************************
// New geocode structures supported by KLE2.3 onwards. Used by kiv_geocode
// and kiv_comp_geocode functions.
//***********************************************************************

/// Geocoding information returned to client. status indicates if this is a
/// success, warning (close match to be geocoded) or error. If error, see 
/// KIV_GEO_OPTIONS.
typedef struct
{
    int status;     // NW_OK, a NW_WARNING_*, or NW_ERROR_GEOCODE (KIV_GEO_INFO)
                    // Error of option if item in match (see KIV_GEO_OPTION(S) )
    int warningcode; // warning sent by KLE
    int crossGeoTypeCode; // cross street geocode type
    int score;      // score of the close match
    int dbID;       // database ID where address was found
    ADMIN_LEVEL   levels[5]; 
    unsigned char country[NW_COUNTRY_SIZE];
    unsigned char state[NW_STATE_SIZE];
    unsigned char city[NW_CITY_SIZE];
    unsigned char zip[NW_ZIP_SIZE];
    unsigned char street[NW_STREET_SIZE];
    unsigned char address[2*NW_ADDRESS_SIZE];
    unsigned char startAddress[NW_ADDRESS_SIZE];
    unsigned char endAddress[NW_ADDRESS_SIZE];
    unsigned char xstreet[NW_STREET_SIZE];
    STREET   streetnames;    // The list of alternate componentized street names
    STREET   xstreetnames;   // The list of alternate componentized street names
    unsigned char outputLine1[NW_LINE_MAX]; // formatted line 1 & 2 by country
    unsigned char outputLine2[NW_LINE_MAX]; // country's conventions; 3 is for
    unsigned char outputLine3[NW_LINE_MAX]; // future use. not set in options
    unsigned char cLineStr[NW_LINE_MAX];    // The geo_option formatted so that
											// it can be sent back to KLE in
											// the GEO_REQ.clinr field.
    int sourceID;       // An internal identifier used by KLE. Please do not
						// change the value it contains.
    int cellID;         // An internal identifier used by KLE. Please do not
						// change the value it contains.
    int nodeID;         // An internal identifier used by KLE. Please do not
						// change the value it contains.

    RT_POINT point;   // If requested, each option will be populated with their respective rt_points
} KIV_GEO_OPTION;

// format localized complete address lines from address components
void format_address_output(char ctryCode, GEO_INFO *info);

typedef struct
{
    KIV_GEO_OPTION *match;         // list of close match(es)
    int limit;                   // max. close matches to be returned
    int count;                   // number of close matches being returned.
} KIV_GEO_OPTIONS;

/**
 * End of structures from geo_std.h
 */

#define DB_CHAR 'C'
#define DB_DATE 'D'
#define DB_NUMERIC 'N'
#define DB_LOGICAL 'L'
#define DB_MEMO 'M'

/*
** Function Prototypes
*/

#ifdef __cplusplus
	extern "C" {
#endif

DLLEXPORT int nw_rt_out_init(RT_OUT *out);
DLLEXPORT int nw_rt_out_free(RT_OUT *out);

#ifdef __cplusplus
	}
#endif
#endif
