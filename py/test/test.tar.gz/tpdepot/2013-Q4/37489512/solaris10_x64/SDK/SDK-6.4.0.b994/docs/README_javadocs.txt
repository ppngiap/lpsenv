JavaDoc is a utility that presents API documentation in HTML pages, describing the API's available classes, methods, and variables. Although JavaDocs do not provide an overview of an API's uses, they do provide detailed information about all of the API's inner workings and specifications. 

To view the JavaDocs (requires a web browser):
1. Uncompress the javadocs.tar.gz file
    a. gunzip javadocs.tar.gz
    b. tar xvf javadocs.tar

2. Open 'index.html' in a web browser

For more info on Javadoc, please go to the Sun web site at: http://java.sun.com/j2se/javadoc/.


If you have any further questions, contact customer support by calling 510-496-0785 or e-mailing support@kivera.com.


� 2002, Kivera, Inc.  This material is protected by U.S. and international
copyright laws and may not be reproduced, modified, distributed, publicly
displayed or used to create derivative works without the express written
consent of Kivera, Inc.  This copyright notice may not be altered or
removed.