/* 
* (C) Copyright 2000-2004 by Kivera, Inc.  All rights reserved. >>./client/examples/source/nw_reverse_geocode_ex.c.new
echo * 
* This material is protected by U.S. and international 
* copyright laws and may not be reproduced, modified, 
* distributed, publicly displayed or used to create derivative 
* works without the express written consent of Kivera, Inc.  
* The information contained herein is considered a trade 
* secret as defined in section 499C of the penal code of the 
* State of California. This copyright notice may not be 
* altered or removed. 
* 
*/ 
/******************************************************
 * File: nw_reverse_geocode_ex.c                      *
 * -------------------------------------------------- *
 * Description:  An example program for exhibiting    *
 *               proper usage of the                  *
 *               nw_reverse_geocode function.         *
 ******************************************************/

/* --- Library Includes --- */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "capis.h"

#ifdef _MSC_VER
#include "win_getopt.h"
#include <WinSock2.h>
#endif

#ifdef LINUX
#include <unistd.h>
#endif

/******************************************************
 * Print information on how to use this program
 ******************************************************/
void print_usage(char *prog_name)
{
    printf("Usage: %s [-?] -h <host> -p <port>\n"
           "       -? print this message\n"
           "       -h host machine name\n"
           "       -p port number\n\n",
           prog_name);
}

/******************************
* argument handler
******************************/
int get_host_and_port(int argc, char *argv[], char **host, int *port)
{
    int helpFlag = FALSE, c;

    *port = 0;
    *host = NULL;
    if (argc < 3) helpFlag = TRUE;

    /* read input arguments */
    while ((c = getopt(argc, argv, "h:p:?")) != EOF)
    {
        switch (c)
        {
            case 'p':
		 *port = atoi(optarg);
		 break;
            case 'h':
                *host = optarg;
                break;
            case '?':
                helpFlag = TRUE;
                break;
        }
    }

    if ((*host == NULL) || (*port == 0)) helpFlag = TRUE;
    if (helpFlag)
    {
        //printf("syntax: testrgeo -h <host> -p <port>\n");
        print_usage(argv[0]);
        return FALSE;
    }

     return TRUE;
}


/******************************
* data structure initialization
******************************/
void initStructures(int argc, char *argv[],     /* input arguments */
                    REVGEO_REQ *revgeo_req,     /* request struct */
                    RT_POINT   *rt_point,       /* location result struct */
                    REVGEO_VECTOR *rdst,        /* distance result struct */
                    REVGEO_INFO *info,          /* description result struct */
                    NWC_CLIENT **c_hndl,        /* client struct */
                    CSF_DB   *csf_db)           /* db struct */
{
    int port;
    char *host;
    int status;

    /* read input arguments */
    if (get_host_and_port(argc, argv, &host, &port) == FALSE)
    {
        exit(0);
    }
  
    /* create client handler structure */
    *c_hndl = nwc_init_client_option(UNPROJECTED);
    if(!*c_hndl)
    {
        printf("error initializing the client\n");
        exit( 1 );
    }

    /* --- Connect to the server --- */
    if (NW_OK != (status = nwc_connect(*c_hndl, host, (u_short)port)))
    {
        printf("error connecting to server. %d\n", status);
        exit( 1 );
    }
  
    /* --- Initialize Structures and Databases -- */
    memset( revgeo_req, 0, sizeof( REVGEO_REQ ) );
    memset( rdst, 0, sizeof( REVGEO_VECTOR ) );
    memset( info, 0, sizeof( REVGEO_INFO ) );
    memset( rt_point, 0, sizeof( RT_POINT ) );

  
    if (NW_OK != (status = nwc_get_mdb_list(*c_hndl, csf_db)))
    {
        printf("Error getting the database list. %d", status);
        exit( 1 );
    }
}

/**
 *
 */

void displayIntersections (INTERSECTIONS_REVGEO_INFO *iInfo)
{
    int i;
    
    for (i = 0; i < iInfo->num_intersections; i++)
    {
        printf ("%d: %s @ %s %d %d = %f\n",
                i,
                iInfo->inter_list[i].street,
                iInfo->inter_list[i].xstreet,
                iInfo->inter_list[i].type,
                iInfo->inter_list[i].relative_dir,
                iInfo->inter_list[i].distance);
    }

    printf ("\n");
}

void displayStreets (STREETS_REVGEO_INFO *sInfo)
{
    int i;

    for (i = 0; i < sInfo->num_streets; i++)
    {
        
        printf ("%s %s\n%s %s %s %s\n%s\n artery speed type %d %d %d\ndistance =  %f\n-------\n",
                sInfo->street_list[i].house_number,
                sInfo->street_list[i].street_name,
                sInfo->street_list[i].city,
                sInfo->street_list[i].admin1,
                sInfo->street_list[i].admin2,
                sInfo->street_list[i].postal_code,
                sInfo->street_list[i].country,
                sInfo->street_list[i].artery_level,
                sInfo->street_list[i].speed,
                sInfo->street_list[i].type,
                sInfo->street_list[i].distance);
                
    }
    printf ("\n");
}

void displayStatus (int status);

/*****************************************
* API execution for position improvement.
*****************************************/
int callAPIs(   double  latitude,           /* location to reverse geocode */
                double  longitude,
                REVGEO_REQ *revgeo_req,     /* request struct */
                RT_POINT   *rt_point,       /* location result struct */
                REVGEO_VECTOR *rdst,        /* distance result struct */
                REVGEO_INFO *info,          /* description result struct */
                INTERSECTIONS_REVGEO_REQ *iReq,
                INTERSECTIONS_REVGEO_INFO *iInfo,
                STREETS_REVGEO_REQ *sReq,
                STREETS_REVGEO_INFO *sInfo,
                NWC_CLIENT *c_hndl)         /* client struct */
{
    int status = NW_OK;

    double orig_latitude = latitude;
    double orig_longitude = longitude;

    /* --- Set Data Fields --- */
    latitude *= NW_DEG2WORLD;   /* convert location into world coordinates */
    longitude *= NW_DEG2WORLD;

    revgeo_req->world_lat = (int)latitude;  /* search location */
    revgeo_req->world_long = (int)longitude;
    revgeo_req->distance = 5280;        /* radius to search (1 mile in feet
                                        * to get results in feet instead
                                        * of miles) */
    revgeo_req->unit = NW_UNIT_FT;          /* search radius units */

    sReq->world_long = (int)longitude;
    sReq->world_lat = (int)latitude;
    sReq->distance = 1;
    sReq->unit = 'M';
    sReq->partial_street_name[0] = '\0';
    sReq->count = 20;

    printf ("\n\nSending streets request..\n");
    printf ("latitude = %f\n", orig_latitude);
    printf ("longitude = %f\n\n", orig_longitude);
    status = nwc_reverse_geocode_streets (c_hndl, sReq, sInfo);

    if (status != NW_OK)
    {
        displayStatus (status);
        printf ("street request failed\n");
    }
    
    else displayStreets(sInfo);
    
    memcpy (&iReq->street, &sInfo->street_list[0], sizeof(STREET_INFO));
    memcpy (&iReq->rt_point, &sInfo->rt_points[0], sizeof(RT_POINT));

    // Calling function to free the memory used for Street revergeo info. 
    //kiv_freeStreetRevgeoInfo(sInfo); 

    iReq->distance = 20;
    iReq->unit = 'M';
    iReq->count = 20;

    printf ("Sending intersections along street  request..\n\n");
    status = nwc_reverse_geocode_intersections_along_street (c_hndl, iReq, iInfo);

    if (status != NW_OK)
    {
        displayStatus (status);
        printf ("intersections along street request failed\n\n");
    }
    else displayIntersections(iInfo);
   
    printf ("Sending intersections around point request..\n\n");
    status = nwc_reverse_geocode_intersections_around_point (c_hndl, sReq, iInfo);
    
    if (status != NW_OK)
    {
        displayStatus (status);
        printf ("Intersections around point request failed\n\n");
    }
    
    else displayIntersections(iInfo);
 
    // Calling function to free the memory used to Intersection around point.
    kiv_freeIntersectionRevgeoInfo(iInfo); 

    return status;
}


/*****************************************
* API execution for Reverse Geocoding.
*****************************************/
int callRevGeoAPI(   double  latitude,           /* location to reverse geocode */
                double  longitude,
                REVGEO_REQ *revgeo_req,     /* request struct */
                RT_POINT   *rt_point,       /* location result struct */
                REVGEO_VECTOR *rdst,        /* distance result struct */
                REVGEO_INFO *info,          /* description result struct */
                NWC_CLIENT *c_hndl)         /* client struct */
{
    int status = NW_OK;

    double orig_latitude = latitude;
    double orig_longitude = longitude;

    /* --- Set Data Fields --- */
    latitude *= NW_DEG2WORLD;   /* convert location into world coordinates */
    longitude *= NW_DEG2WORLD;

    revgeo_req->world_lat = (int)latitude;  /* search location */
    revgeo_req->world_long = (int)longitude;
    revgeo_req->distance = 5280;        /* radius to search (1 mile in feet
                                        * to get results in feet instead
                                        * of miles) */
    revgeo_req->unit = NW_UNIT_FT;          /* search radius units */

    printf("\nReverse geocoding location: latitude= %f longitude= %f\n\n",
            orig_latitude, orig_longitude);

    /* --- Perform Request --- */
    status = nwc_reverse_geocode( c_hndl,   /* client handle */
                    revgeo_req,             /* request struct */
                    rt_point,               /* location result struct */
                    rdst,                   /* distance result struct */
                    info);                  /* description result struct */

    return status;
}


void displayStatus (int status)
{
    switch (status)
    {
    case NW_ERROR_NOLINK:
        printf("ERROR - NO LINK\n");
        break;
    case NW_ERROR_LL:
        printf("ERROR - BAD LOCATION INPUT\n");
        break;
    case NW_ERROR_MAPDBID:
        printf("ERROR - DATABASE\n");
        break;
    case NWC_ERROR_PARAM:
        printf("ERROR - INVALID PARAMS\n");
        break;
    default:
        printf("ERROR - COMMUNICATIONS\n");
        break;
    };
}
/******************************
* result display
******************************/
void displayResults( int status,            /* result status */
                RT_POINT   *rt_point,       /* location result struct */
                REVGEO_VECTOR *rdst,        /* distance result struct */
                REVGEO_INFO *info)          /* description result struct */
{
    const char *sides[] = {"", "Left", "Right", "Both"};

    if (status != NW_OK)
    {
      /* --- An error has occurred --- */
        switch (status)
        {
            case NW_ERROR_NOLINK:
                printf("ERROR - NO LINK\n");
                break;
            case NW_ERROR_LL:
                printf("ERROR - BAD LOCATION INPUT\n");
                break;
            case NW_ERROR_MAPDBID:
                printf("ERROR - DATABASE\n");
                break;
            default:
                printf("ERROR - COMMUNICATIONS\n");
                break;
        };
    }
    else
    {
        /* --- Print Output --- */
        printf( "Closest link has cell %x link %d\n",
            rt_point->vmapID.mapID, rt_point->link );
        printf("\tside: %s spot: %d%% street: %s\n",
                sides[rt_point->side], rt_point->spot, rt_point->street);
        printf("\tlatitude: %f  longitude %f\n",
                rt_point->world_lat / NW_DEG2WORLD,
                rt_point->world_long / NW_DEG2WORLD);
        printf("\tdistance: %f %c. to the %s direction (%d degrees)\n",
                rdst->distance, (char)rdst->unit, rdst->direction, rdst->angle);
        printf("\tStreet: %s %s\n", info->info.address, info->info.street);
        printf("\tCity  : %s\n", info->info.city);
        printf("\tState : %s %s\n", info->info.state, info->info.zip);
        printf("\tspeed, type, artery : %d %d %d\n", info->speed, info->type, info->artery);
    }
}


/******************************
*   MAIN program
******************************/
int main(int argc, char *argv[])
{
  /* --- Variable and Structure Declarations --- */
  REVGEO_REQ revgeo_req;
  RT_POINT   rt_point;
  REVGEO_VECTOR rdst;
  REVGEO_INFO info;
  NWC_CLIENT *c_hndl;
  CSF_DB   csf_db;
  int status;
  double  latitude;
  double  longitude;
  INTERSECTIONS_REVGEO_REQ iReq;
  INTERSECTIONS_REVGEO_INFO iInfo;
  STREETS_REVGEO_REQ sReq;
  STREETS_REVGEO_INFO sInfo;


    initStructures(argc, argv,      /* input arguments  */
                    &revgeo_req,    /* request struct */
                    &rt_point,      /* location result struct */
                    &rdst,          /* distance result struct */
                    &info,          /* description result struct */
                    &c_hndl,        /* client struct */
                    &csf_db);       /* db struct */

    memset (&iReq, 0, sizeof(INTERSECTIONS_REVGEO_REQ));
    memset (&sReq, 0, sizeof(STREETS_REVGEO_REQ));
    memset (&iInfo, 0, sizeof(STREETS_REVGEO_INFO));
    memset (&sInfo, 0, sizeof(STREETS_REVGEO_INFO));


    /***************************************
    *   select from available databases.
    *   first database selected here
    **************************************/
    revgeo_req.mapDbPref[0] = csf_db.db[0].id;
    //revgeo_req.mapDbPref[1] = csf_db.db[1].id;

    sReq.mapDbPref = csf_db.db[0].id;
  
    //longitude =  -122.26940;    /* location to reverse geocode */
    //latitude =   37.80700;
    latitude =   37.80896;
    longitude =  -122.26986;    /* location to reverse geocode */

    status = callRevGeoAPI(
                latitude,   /* location to search */
                longitude,
                &revgeo_req,    /* request struct */
                &rt_point,      /* location result struct */
                &rdst,          /* distance result struct */
                &info,          /* description result struct */
                c_hndl);        /* client struct */

    displayResults( status,     /* result status */
                &rt_point,      /* location result struct */
                &rdst,          /* distance result struct */
                &info);         /* description result struct */
    kiv_free_revgeo_info(&info);

    longitude =  -79.38333;    /* location to reverse geocode */
    latitude =   48.61555;

    status = callRevGeoAPI(
                latitude,   /* location to search */
                longitude,
                &revgeo_req,    /* request struct */
                &rt_point,      /* location result struct */
                &rdst,          /* distance result struct */
                &info,          /* description result struct */
                c_hndl);        /* client struct */

    displayResults( status,     /* result status */
                &rt_point,      /* location result struct */
                &rdst,          /* distance result struct */
                &info);         /* description result struct */

    longitude =  900.00001;    /* location to reverse geocode */
    latitude =   900.00001;

    status = callRevGeoAPI(
                latitude,   /* location to search */
                longitude,
                &revgeo_req,    /* request struct */
                &rt_point,      /* location result struct */
                &rdst,          /* distance result struct */
                &info,          /* description result struct */
                c_hndl);        /* client struct */

    displayResults( status,     /* result status */
                &rt_point,      /* location result struct */
                &rdst,          /* distance result struct */
                &info);         /* description result struct */

    longitude =  -122.26940;    /* location to reverse geocode */
    latitude =   37.80700;

    status = callAPIs(
                latitude,   /* location to search */
                longitude,
                &revgeo_req,    /* request struct */
                &rt_point,      /* location result struct */
                &rdst,          /* distance result struct */
                &info,          /* description result struct */
                &iReq,
                &iInfo,
                &sReq,
                &sInfo,
                c_hndl);        /* client struct */


  /* --- Close the client ---*/
  nwc_disconnect(c_hndl);
  nwc_delete_client_option(c_hndl);

  /* --- Exit Program --- */
  exit ( 0 );

}

