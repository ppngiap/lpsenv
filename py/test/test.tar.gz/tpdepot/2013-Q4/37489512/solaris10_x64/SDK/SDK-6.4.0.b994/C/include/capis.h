/* 
* (C) Copyright 2000-2004 by Kivera, Inc.  All rights reserved. >>./client/API/c/libclient/include/capis.h.new
echo * 
* This material is protected by U.S. and international 
* copyright laws and may not be reproduced, modified, 
* distributed, publicly displayed or used to create derivative 
* works without the express written consent of Kivera, Inc.  
* The information contained herein is considered a trade 
* secret as defined in section 499C of the penal code of the 
* State of California. This copyright notice may not be 
* altered or removed. 
* 
*/ 
#ifndef _CAPIS_H
#define _CAPIS_H

#ifdef _MSC_VER
#define MAXHOSTNAMELEN 500
#else
#include <sys/param.h>          /* MAXHOSTNAMELEN for HP-UX */
#include <netdb.h>
#endif
#include <sys/types.h>
#include "revgeo_def.h"
#include "PoiInterface.h"
#include "navworks.h"
#include "KixCApis.h"
#include "iso_codes.h"
#include "nw_imp_revgeo.h"
#include "client_windows.h"

#define    MIN_URL_LEN    4096
#define    MAX_LANG_LEN   8
#define    FORMAT_GIF     1
#define    FORMAT_PNG     2
#define    FORMAT_WBMP    3
#define    FORMAT_JPEG    4
#define    FORMAT_EPS     5
#define    MONOCHROME     1
#define    GRAY_SCALE     2
#define    COLOR          3

/* Road types */
#define NW_RAMP                    0x0000001
#define NW_BRIDGE                  0x0000002
#define NW_TUNNEL                  0x0000004
#define NW_FERRY                   0x0000008
#define NW_TOLLROAD                0x0000010
#define NW_WALKWAY                 0x0000020
#define NW_ROUNDABOUT              0x0000080
#define NW_TOLLBOOTH               0x0000200
#define NW_HOV_LANE                0x0000400
#define NW_SD_DIVIDED              0x0001000
#define NW_DD_DIVIDED              0x0002000
#define NW_PRIVATE_ROAD            0x0008000
#define NW_FARM_ROAD               0x0040000
#define NW_CLOSED                  0x0080000
#define NW_DIVIDED_LINK            0x0800000
#define NW_CONTROLLED_ACCESS       0x1000000

/* Artery Levels */
#define NW_ARTERY_MAJOR_FREEWAYS     1 /* Major freeways like I-80 */
#define NW_ARTERY_REGIONAL_FREEWAYS  2 /* Regional freeways (all of them other than the ones on top */
#define NW_ARTERY_EXPRESSWAY         3 /* Expressways and state highways which are not freeways */
#define NW_ARTERY_LOCAL_ROADS        4 /* Local roads but of some importance */
#define NW_ARTERY_ALL_OTHER_ROADS    5 /* All other roads */

/* Relative direction for INTERSECTION */
#define NW_INTERSECTION_TOWARDS_START_NODE 0 /* Intersection along a street towards start node of the lynk */
#define NW_INTERSECTION_TOWARDS_END_NODE   1 /* Intersection along a street towards end node of the lynk */
#define NW_INTERSECTION_INVALID_DIRECTION -1 /* Intersection around a point */

typedef struct
{
    char    host[MAXHOSTNAMELEN];
    unsigned short port;
    int     sockfd;
    int     proj_type;
    int     turbo;
    unsigned short local_port;
} NWC_CLIENT;

typedef struct
{
    int id;
    char name[256];
} CSF_DB_INFO;

typedef struct
{
    int num;
    CSF_DB_INFO* db;
}CSF_DB;

typedef struct
{
    int count;
    POI_CATEGORY* list;
} POI_CATEGORIES;

typedef struct
{
    int count;
    POI_VID* list;
} POI_VIDS;

typedef struct image_url
{
    int        zoom;
    int        height;
    int        width;
    int        manv_index;
    int        mapDbID;
    int        offsetx;
    int        offsety;
    int        cid;
    int        cnt_points;
    int        format;
    int        gray;
    char*      base_url;
    RT_OUT*    route;
    RT_POINT*  point;
    double*    poi_world_long;
    double*    poi_world_lat;
    int*       poi_kind;
    char       lang[MAX_LANG_LEN];
    int        drawCircle;
    int        circleLong;
    int        circleLat;
    int        circleRadius;
    int        circleColor;
    char       radiusUnit;
    char       circleWidth;
} IMAGE_URL;

typedef struct image_req
{
    int             zoom;
    int             height;
    int             width;
    int             mapDbID;
    int             offsetx;
    int             offsety;
    int             cid;
    int             format;
    int             cnt_shape;
    int             cnt_points;
    int             gray_scale;
    double          world_long;
    double          world_lat;
    int*            shape_world_long;
    int*            shape_world_lat;
    int*            poi_kind;
    double*         poi_world_long;
    double*         poi_world_lat;

    char            lang[MAX_LANG_LEN];
    int*            stop_x;
    int*            stop_y;
    int             cnt_stops;

    int*            manv_x;
    int*            manv_y;
    int*            manv_idx;
    int             manv_cnt;

} IMAGE_REQ;

typedef struct new_image_req
{
   int dataRequest;
   int databaseID;
   int mapScale;
   double centerLat;
   double centerLon;
   int height;
   int width;
   int offsetX;
   int offsetY;
   int colorScheme;
   char baseName[NW_LINE_MAX];
   char formatStr[NW_LINE_MAX];
   char lang[NW_LINE_MAX];
   int shapeCount;
   int* routeShapeLats;
   int* routeShapeLons;
   int poiCount;
   int *poiLats;
   int *poiLons;
   int *poiTypes;
   int stopoverCount;
   int *stopLats;
   int *stopLons;
   int manvPointCount;
   int *manvLats;
   int *manvLons;
   int *manvIdx;
   int speedMapType;
} NEW_IMAGE_REQ;



typedef struct image_point
{
    int lat;
    int lon;
    int poiID;
    char* iconName;
    char* iconText;
    int radius;
    int color;
    char unit;
    char width;
} IMAGE_POINT;


typedef struct image_line
{
    int prio;
    char* lineStyle;
    int ptCount;
    IMAGE_POINT* points; 
} IMAGE_LINE;


typedef struct adv_image_req
{
    int dataRequest;
    int databaseID;
    int mapScale;
    double centerLat;
    double centerLon;
    int height;
    int width;
    int offsetX;
    int offsetY;
    int colorScheme;
    char* baseName;
    char* format;
    char* lang;
    int lineCount;
    IMAGE_LINE* lines;
    int speedMapType;
} ADV_IMAGE_REQ;


#ifdef __cplusplus
extern "C" {
#endif

/* --- Initialize client --- */
DLLEXPORT NWC_CLIENT* nwc_init_client_option(int proj_type);
DLLEXPORT int nwc_delete_client_option(NWC_CLIENT* handler);
DLLEXPORT int nwc_connect(NWC_CLIENT* handler, const char* hostname, unsigned short port);
DLLEXPORT int nwc_disconnect(NWC_CLIENT* handler);
DLLEXPORT int nwc_is_connected(NWC_CLIENT* handler);
DLLEXPORT int nwc_set_turbo(NWC_CLIENT* handler, int turbo_flag);
DLLEXPORT int nwc_set_local_port(NWC_CLIENT* handler, u_short local_port);

/* --- Database related calls --- */
DLLEXPORT int nwc_get_mdb_list(NWC_CLIENT* handler, CSF_DB* db);
DLLEXPORT int nwc_free_mdb_list(CSF_DB* db);
DLLEXPORT int nwc_get_country_list(NWC_CLIENT* handle, int dbID, char * lang, DB_ENTRY_LIST* list);
DLLEXPORT void nwc_free_db_entry_list(DB_ENTRY_LIST *list);

/* --- Display data apis --- */
DLLEXPORT int nwc_get_map_list(NWC_CLIENT* handler,
                               const MAPID_REQ *req,
                               MAPID_OUT *out);
    
DLLEXPORT int nwc_get_map_list_2(NWC_CLIENT* handler,
                                 const MAPID_REQ *req,
                                 MAPID_OUT *out);
    
DLLEXPORT int nwc_get_display_data(NWC_CLIENT* handler,
                                   VMAP_ID *map,
                                   void *data);
    
DLLEXPORT int nwc_get_display_data_2(NWC_CLIENT* handler,
                                     int dbID,
                                     int cellCount,
                                     const int* cellIDs,
                                     int type,
                                     void *data);
DLLEXPORT int nwc_free_display_data(int type, void* data);

/* --- Geocoding/Rev-Geocoding --- */
DLLEXPORT int nwc_comp_geocode(NWC_CLIENT* handler, COMPGEO_REQ *req, GEO_OPTIONS *opt, 
                     GEO_INFO *info, RT_POINT *out);
DLLEXPORT int nwc_geocode(NWC_CLIENT* handler, GEO_REQ *req, GEO_OPTIONS *opt, 
                GEO_INFO *info, RT_POINT *out);
DLLEXPORT int nwc_geo_display_options(GEO_OPTIONS *coded_opt, GEO_OPTIONS *display_opt);

DLLEXPORT int kiv_comp_geocode(NWC_CLIENT* handler, COMPGEO_REQ *req, 
					 KIV_GEO_OPTIONS *opt, GEO_INFO *info, 
					 RT_POINT *out);
DLLEXPORT int kiv_geocode(NWC_CLIENT* handler, GEO_REQ *req, 
						  KIV_GEO_OPTIONS *opt, 
                          GEO_INFO *info, RT_POINT *out);
DLLEXPORT int kiv_free_geo_info(GEO_INFO *info);
DLLEXPORT int kiv_free_geo_opt(KIV_GEO_OPTIONS *opt);

DLLEXPORT int nwc_reverse_geocode(NWC_CLIENT* handler, REVGEO_REQ *req, RT_POINT *out, REVGEO_VECTOR* rdst, REVGEO_INFO *info);
DLLEXPORT int kiv_free_revgeo_info(REVGEO_INFO *info);

DLLEXPORT int nwc_reverse_geocode_streets(
    NWC_CLIENT* handle,
    STREETS_REVGEO_REQ *req,
    STREETS_REVGEO_INFO *info
    );


DLLEXPORT int nwc_reverse_geocode_intersections_along_street (
    NWC_CLIENT* handle,
    INTERSECTIONS_REVGEO_REQ *req,
    INTERSECTIONS_REVGEO_INFO *info
    );


DLLEXPORT int nwc_reverse_geocode_intersections_around_point(
    NWC_CLIENT* handle,
    STREETS_REVGEO_REQ *req,    
    INTERSECTIONS_REVGEO_INFO *info);
    
DLLEXPORT int kiv_freeStreetRevgeoInfo(STREETS_REVGEO_INFO *info);
DLLEXPORT int kiv_freeIntersectionRevgeoInfo(INTERSECTIONS_REVGEO_INFO *info);

/* --- Routing --- */
DLLEXPORT int nwc_rt_out_init(RT_OUT *out);
DLLEXPORT int nwc_calculate_route(NWC_CLIENT* handler, RT_REQ *req, RT_OUT *out);
DLLEXPORT int nwc_rt_out_free(RT_OUT *out);
DLLEXPORT int nw_create_line_shape(RT_OUT *out, const char *name);
DLLEXPORT int nw_create_rtpoint_shape(RT_OUT *out, const char *name);
DLLEXPORT int nw_create_point_shape(RT_POINT *pnt, int count, const char *name);
DLLEXPORT int nw_create_manv_shape(RT_MANV *pnt, int count, const char *name);

DLLEXPORT int kiv_calculate_route(NWC_CLIENT* handler, RT_REQ *req, RT_RES *rtres);
DLLEXPORT int kiv_calculate_e_route(NWC_CLIENT* handle, ERT_REQ *ertreq, ERT_OUT_ARRAY *ertout);

DLLEXPORT int kiv_get_route_info(NWC_CLIENT* handler, RT_INFO_REQ *req, RT_RES *output);
DLLEXPORT int nwc_rt_res_free(RT_RES *rtres);
DLLEXPORT int nwc_rt_solution_free(RT_SOLUTION *rtsoln);

/* --- Points of Intrests --- */
DLLEXPORT int nwc_get_poi_category_list(NWC_CLIENT* handler, POI_CATEGORIES *categories, char* lang);
DLLEXPORT int nwc_free_poi_category_list(POI_CATEGORIES *categories);
DLLEXPORT int nwc_get_poi_vid_list(NWC_CLIENT* handler, POI_VIDS *categories);
DLLEXPORT int nwc_free_poi_vid_list(POI_VIDS *categories);
DLLEXPORT int nwc_pois_free(POI_SEARCH_REPLY *reply);
DLLEXPORT int kiv_pois_free(KIV_POI_SEARCH_REPLY *reply);
DLLEXPORT int nwc_poi_search(NWC_CLIENT* handler, POI_SEARCH_REQUEST *request,
                   POI_SEARCH_REPLY *reply);
DLLEXPORT int kiv_poi_search(NWC_CLIENT* handler, POI_SEARCH_REQUEST *request,
                   KIV_POI_SEARCH_REPLY *reply);
DLLEXPORT int nwc_get_supplemental_fields(NWC_CLIENT *handle,
                                SUPPLEMENTAL_DB_REQUEST *request,
                                SUPPLEMENTAL_DB_REPLY *reply);

DLLEXPORT int nwc_free_supplemental_fields(SUPPLEMENTAL_DB_REPLY *reply);


/* --- image related calls --- */
DLLEXPORT int nwc_gen_route_url( NWC_CLIENT* handle, IMAGE_URL* image_url, int url_len,
                       char* result_url );
DLLEXPORT int nwc_gen_point_url( NWC_CLIENT* handle, IMAGE_URL* image_url, int url_len,
                       char* result_url );
DLLEXPORT void
translateNewImageToAdvImage(NEW_IMAGE_REQ* image_req,
                            ADV_IMAGE_REQ *advReq,
                            IMAGE_LINE *allLines,
                            char *numberArray,
                            int circleCount,
                            char **circleStrings);
DLLEXPORT int
nwc_get_image(NWC_CLIENT* handle,
              const ADV_IMAGE_REQ* imageReq,
              int* img_len,
              char** img_data,
              int *leg_len,
              char **leg_data);

DLLEXPORT int nwc_get_image_data( NWC_CLIENT* handler, IMAGE_REQ* image_req,
                       char** img_data );
DLLEXPORT int nwc_get_newimage_data( NWC_CLIENT* handler, NEW_IMAGE_REQ* image_req,
                       int* img_len, char** img_data, int* leg_len,
                       char **leg_data);

DLLEXPORT int nwc_free_image_data(char** img_data );
/* --- projection related calls --- */
DLLEXPORT void nwc_convert_back(int proj_type, int* x, int* y);
DLLEXPORT void nwc_convert_forw(int proj_type, int* x, int* y);
DLLEXPORT void nw_em_project(int world_long, int world_lat, double *x, double *y);

/* --- dynamic poi database operations related calls --- */
DLLEXPORT int kiv_managePoiData ( NWC_CLIENT* handle, POI_MANAGE_REQ *poireq);
DLLEXPORT int kiv_freePoiManageReq(POI_MANAGE_REQ *req);

DLLEXPORT int kiv_removePoiData ( NWC_CLIENT* handle, POI_REMOVE_REQ *poiRemoveReq);

DLLEXPORT int kiv_clearAllPoiData ( NWC_CLIENT* handle, POI_CLEARALL_REQ *poiClearAllReq);

DLLEXPORT int kiv_selectPoiData ( NWC_CLIENT* handle, POI_SELECT_REQ *poiSelectReq, POI_SELECT_RES *poiSelectRes);
DLLEXPORT int kiv_freePoiSelectRes(POI_SELECT_RES *res);

DLLEXPORT int kiv_srchSuppInfo( NWC_CLIENT* handle, POI_SRCHSUPPINFO_REQ *poiSrchSuppInfoReq, POI_SRCHSUPPINFO_RES *poiSrchSuppInfoRes);
DLLEXPORT int kiv_freeSrchSuppInfoReq(POI_SRCHSUPPINFO_REQ *req);
DLLEXPORT int kiv_freeSrchSuppInfoRes(POI_SRCHSUPPINFO_RES *res);


DLLEXPORT int kiv_poiOnAlongRoute ( NWC_CLIENT* handle, 
						            POI_ON_ALONG_ROUTE_REQ *poiOnAlongRouteReq,
						            POI_ON_ALONG_ROUTE_RES *poiOnAlongRouteRes);
DLLEXPORT int kiv_freePoiOnAlongRouteReq(POI_ON_ALONG_ROUTE_REQ *req);
DLLEXPORT int kiv_freePoiOnAlongRouteRes(POI_ON_ALONG_ROUTE_RES *res);

/* Calculates the cell ID of the level 3 or level 6 cell in which the given 
 * point rests. Currently valid values for cell_level are 3 and 6.
 */
DLLEXPORT int kiv_calculate_cellid(int latitude, int longitude, int cell_level);

#ifdef __cplusplus
}
#endif

#endif /* _CAPIS_H */
