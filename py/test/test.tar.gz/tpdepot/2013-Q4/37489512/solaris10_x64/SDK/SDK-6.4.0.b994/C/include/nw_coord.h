/* 
* (C) Copyright 2000-2004 by Kivera, Inc.  All rights reserved. >>./client/API/c/libclient/include/nw_coord.h.new
echo * 
* This material is protected by U.S. and international 
* copyright laws and may not be reproduced, modified, 
* distributed, publicly displayed or used to create derivative 
* works without the express written consent of Kivera, Inc.  
* The information contained herein is considered a trade 
* secret as defined in section 499C of the penal code of the 
* State of California. This copyright notice may not be 
* altered or removed. 
* 
*/ 
#ifndef _NW_COORD_H_
#define _NW_COORD_H_

#include "kivera.h"
#include "csf_point.h"
#include "client_windows.h"

#ifdef __cplusplus
extern "C" {
#endif


DLLEXPORT void
nwc_convert_forw(int proj_type, int* x, int* y);

DLLEXPORT void
nwc_convert_back(int proj_type, int* x, int* y);

/**
 Define funcs that were static in nw_coord.c
*/
DLLEXPORT 
double csf_worldToRadian(int y);
DLLEXPORT 
int csf_radianToWorld(double y);
DLLEXPORT 
double csf_mercatorForward(double y);
DLLEXPORT 
double csf_mercatorBackward(double y);


/**
   Neighbor struct has the cell id and the distance from the postion around
   which the Neighbor is being called. This is just a storage place
*/

typedef struct  Neighbor
{
    INT cell;
    double sMin;
} Neighbor;

/**
 * Return a list of neighboring cell ids sorted by distance.
 * @param postion point in worldLat Long around which cells are required
 * @param distance distance within which cell are required
 * @param numIds the number of cells being returned
 * @param unit distance unit
 **/
DLLEXPORT Neighbor *
getCellIds(CSF_POINT position, double distance, 
           int *numIds, char unit, int level); 


/// Get the cell level 3 ID.
/**
 * @param x the world X coordinate
 * @param y the world Y coordinate
 * @param cell the cell ID output variable
 * @return NW_OK
 **/
DLLEXPORT INT
nw_getCell3Number(INT x, INT y, INT *cell);


/// ???
DLLEXPORT INT
nw_getCellNumber(INT x, INT y, INT level, INT *cell);


/// Calculate the south-west corned of a given cell.
/**
 * @param cell the cell ID
 **/
DLLEXPORT INT
nw_getCellOrigin(INT cell, CSF_POINT *origin);


/// Calculate the cell boundary of a given cell.
/**
 * @param cell the cell ID
 * @param sw will contain the south-west corner
 * @param ne will contain the north-east corner
 **/
DLLEXPORT INT
nw_cellBoundary(INT cell, CSF_POINT *sw, CSF_POINT *ne);


/// Convert within-a-cell coordinates to real coordinates.
/**
 * @param cell the cell ID
 * @param nPoint the number of points
 * @param in the list of within-a-cell coordinates
 * @param out will contain the real coordinates
 **/
DLLEXPORT INT
nw_cellToWorld(INT cell, INT nPoint, const CSF_POINT *in, CSF_POINT *out);


/// Apply a projection to a number of points.
/**
 * @param proj the projection; UNPROJECTED or MERCATOR
 * @param nPoint the number of points
 * @param in the input list
 * @param out will contain the output list
 **/
DLLEXPORT INT
nw_projectForward(INT proj, INT nPoint, const CSF_POINT *in, CSF_POINT *out);


/// Convert world coordinates to spheroidal mercator coordinates.
/**
 * @param wx the world X coordinate
 * @param wy the world Y coordinate
 * @param x the spheroidal longitude output
 * @param y the spheroidal latitude output
 **/
DLLEXPORT void
nw_em_project(int wx, int wy, double *x, double *y);


/// Apply the reverse of a projection to a number of points.
/**
 * @param proj the projection; UNPROJECTED or MERCATOR
 * @param nPoint the number of points
 * @param in the input list
 * @param out will contain the output list
 **/
DLLEXPORT INT
nw_projectBackward(INT proj, INT nPoint, const CSF_POINT *in, CSF_POINT *out);


/// Calculate the distance between two points.
/**
 * @param dist the distance output
 * @param unit the distance unit; NW_UNIT_MILE, NW_UNIT_KM, NW_UNIT_FT, or NW_UNIT_M
 **/
DLLEXPORT INT
nw_getDistance(CSF_POINT one, CSF_POINT two, DOUBLE *dist, char unit);


/// Calculate the distance between two points.
/**
 * @param dist the distance output
 * @param unit the distance unit; NW_UNIT_MILE, NW_UNIT_KM, NW_UNIT_FT, or NW_UNIT_M
 **/
DLLEXPORT INT
nw_getDistance_lat_long(INT lat_one,
                        INT long_one,
                        INT lat_two,
                        INT long_two,
                        DOUBLE *dist,
                        char unit);

/// Calculate the angle and direction between to points.
/**
 * @param dist the direction output
 * @param direction the direction string output; will contain "N",
 *  "NE", "E", "SE", "S", "SW", "W", or "NW" on return
 **/
DLLEXPORT INT
nw_getDirection_lat_long(INT lat_one, INT long_one, INT lat_two,
                         INT long_two, SHORT *angle, CHAR *direction);


/// Check if a point is on a cell boundary at a given cell level.
DLLEXPORT INT
nw_chk_boundary(CSF_POINT dot, INT level);


/// Check if a point is at a corner of a cell at a given cell level.
DLLEXPORT INT
nw_chk_corner(CSF_POINT dot, INT level);

//Parameters are unprojected world coordinates.  East is zero,
//north is 90, etc.
DLLEXPORT
unsigned short nwAngleRelativeEast(int srcLat, int srcLon,
								   int dstLat, int dstLon);

/// Copy and deform points from one shape buffer to another.
//@param shift the right-shift to be applied to each point before
//comparisons take place.
DLLEXPORT
unsigned int copyAndDeformPoints(int* outBuffer,
							   const int* inBuffer,
							   const unsigned int nPts,
							   const int shift);
#ifdef __cplusplus
}
#endif

#endif // _NW_COORD_H_
