/*
 * � 2001, Kivera, Inc.  This material is protected by U.S. and international
 * copyright laws and may not be reproduced, modified, distributed, publicly
 * displayed or used to create derivative works without the express written
 * consent of Kivera, Inc.  This copyright notice may not be altered or
 * selected.
 *
 */

//package com.kivera.kle;

import java.lang.*;
import java.io.*;
import java.util.*;
import java.beans.*;
import com.kivera.klc.*;
import com.kivera.klc.poi.*;
import java.awt.event.*;

/**
 * This driver class demonstrates how to select a POI into the dynamic
 * poi database.
 * This driver makes use of Kivera's client beans package to access the Kivera
 * Location Engine.
 * It reads the vendor Id and POI Id values from the
 * poiSelectData.properties file and selects the poi having these values.
 * All the rest of the field values in the data file are ignored.
 *
 * @version 1.0
 */
public class POISelectDriver
{

	public static void main(String [] args) 
	{

		// Get the host and port from command line
		int intCounter = 0;
		int intPort    = 0;
		char parm      = '?';
		String strHost = "";

		for(intCounter=0;intCounter<args.length;intCounter++)
		{
			if (args[intCounter].charAt(0)=='-')
			{
				parm = Character.toLowerCase(args[intCounter].charAt(1));
			}
			switch(parm)
			{
				case 'h':
				    strHost = args[++intCounter];
				    break;
				case 'p':
				    intPort = Integer.parseInt(args[++intCounter]);
				    break;
				default:
				    showUsage();
				    break;
			}
		}
		if(strHost==null||strHost.equals("")||intPort<=0)
			showUsage();


		try
		{
			// Obtain the RequestProcessor object which is connected to the
			// KLE at the port and host input.

			RequestProcessor processor     = getProcessor(strHost, intPort);

			KivPOISearchBean searchBean = new KivPOISearchBean();
			searchBean.addRequestListener(processor);


			// Pick up the id values of the poi from the data file
			readPoiIds();


			KivPOIKey key = new KivPOIKey();
			// Set the necessary input fields in the bean
			if(POISelectDriver.vendorId != -2147483648 &&
			   POISelectDriver.poiId != -2147483648)
			{
				key.setId(POISelectDriver.poiId);
				key.setVendorId(POISelectDriver.vendorId);
			}
			else
			{
				throw new Exception("Could not obtain PoiId, VendorId of poi from data file.");
			}

			// Resolve the bean
			KivPOI kivPoi = searchBean.doSelect(key);


			// Check the result

			{
				System.out.println("\n");
				System.out.println("The select operation was successful\n");
				System.out.println("The POI selected is given below-\n");
				System.out.println(kivPoi.toString());
				System.out.println("\n");
			}

		}
		catch(Exception e)
		{
			System.out.println("\n");
			System.out.println("Exception resolving bean\n");
			e.printStackTrace();
			System.out.println("\n");
		}

	}


	/**
	 * Display executable usage.
	 */
	public static void showUsage()
	{
		System.out.println("usage: " + POISelectDriver.class.getName() + " -h <host> -p <port>");
		System.exit(0);
	}

	private static RequestProcessor getProcessor(String strHost, int intPort)
	{
		RequestProcessor processor = new RequestProcessor();
		processor.setHost(strHost);
		processor.setPort(intPort);
		processor.setProjection(new NoProjection());

		// Connect to the KLE
		processor.setStatus(Constants.CLIENT_STATUS_CONNECTED);

		return processor;
	}


	/**
	 * This method picks up the "id" values of the poi to be selected
	 * from the "poiSelectData.properties" file
	 *
	 */
	private static void readPoiIds()
	{
		// Reading the poi data from the poiSelectData.properties file
		java.util.Locale theLocale = new java.util.Locale("en", "");
		PropertyResourceBundle poiSelectDataBundle = 
			(PropertyResourceBundle)ResourceBundle.getBundle("poiSelectData", theLocale);

		String strTemp           = null;

		// Id of the POI which needs to be selected.

		 strTemp                 = poiSelectDataBundle.getString("poiKey-vendorId");
		POISelectDriver.vendorId = getIntValue(strTemp);

		 strTemp                 = poiSelectDataBundle.getString("poiKey-poiId");
		POISelectDriver.poiId    = getIntValue(strTemp);

	}


	private static int getIntValue(String strValue)
	{
		int intValue = 0;

		try
		{
			intValue = Integer.parseInt(strValue);
		}
		catch(NumberFormatException e)
		{
			intValue = 0;
		}
		return intValue;
	}
	
	private static int poiId    = -2147483648; 
	private static int vendorId = -2147483648; 
}
