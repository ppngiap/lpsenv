/*
 * � 2001, Kivera, Inc.  This material is protected by U.S. and international
 * copyright laws and may not be reproduced, modified, distributed, publicly
 * displayed or used to create derivative works without the express written
 * consent of Kivera, Inc.  This copyright notice may not be altered or
 * removed.
 *
 */

//package com.kivera.kle;

import java.lang.*;
import java.io.*;
import java.util.*;
import java.beans.*;
import com.kivera.klc.*;
import com.kivera.klc.poi.*;
import java.awt.event.*;

/**
 * This driver class demonstrates how to update a new POI into the dynamic
 * poi database.
 * This driver makes use of Kivera's client beans package to access the Kivera
 * Location Engine.
 * It reads the necessary KivPOI object values of the POI which needs to be
 * updated from the poiUpdData.properties file. The user needs to just update 
 * the value of the field which needs to be updated in this data file. Also
 * it should be ensured that the POIId in this file belongs to an already 
 * existing poi in the database.
 * In a typical scenario the ideal way to update a poi is to first get the
 * KivPOI object for that poi using the KivPOISelectBean, change the particular
 * field value which needs to be updated and then use the KivPOIManageBean to
 * do the update operation. In this driver class we are using a static data file
 * to read the KivPOI object instead of the KivPOISelectBean just for 
 * convenience.
 *
 * @version 1.0
 */
public class POIUpdateDriver
{

	public static void main(String [] args) 
	{

		// Get the host anf port from command line
		int intCounter = 0;
		int intPort    = 0;
		char parm      = '?';
		String strHost = "";

		for(intCounter=0;intCounter<args.length;intCounter++)
		{
			if (args[intCounter].charAt(0)=='-')
			{
				parm = Character.toLowerCase(args[intCounter].charAt(1));
			}
			switch(parm)
			{
				case 'h':
				    strHost = args[++intCounter];
				    break;
				case 'p':
				    intPort = Integer.parseInt(args[++intCounter]);
				    break;
				default:
				    showUsage();
				    break;
			}
		}
		if(strHost==null||strHost.equals("")||intPort<=0)
			showUsage();


		try
		{
			// Obtain the RequestProcessor object which is connected to the
			// KLE at the port and host input.

			RequestProcessor processor     = getProcessor(strHost, intPort);


			// Create the KivPOIManageBean for handling POI updates
			KivPOIManageBean poiManageBean = new KivPOIManageBean();

			// Connect the bean to the RequestProcessor
			poiManageBean.addRequestListener(processor);

			//Create the POI object for the POI which needs to be updated
			KivPOI existingPOI             = getPoi();

			// Check the result

			int status = poiManageBean.doUpdate(existingPOI, clientId, POIUpdateDriver.dateTimeStamp);
			if(status < 0)
			{
				System.out.println("\n");
				System.out.println("The update operation failed with status:" + status);
				System.out.println("\n");
			}
			else
			{
				System.out.println("\n");
				System.out.println("The update operation was successful\n");
				System.out.println("The id of the new POI is :: " + status);
				System.out.println("\n");
			}

		}
		catch(Exception e)
		{
			System.out.println("\n");
			System.out.println("Exception resolving bean\n");
			e.printStackTrace();
			System.out.println("\n");
		}

	}


	/**
	 * Display executable usage.
	 */
	public static void showUsage()
	{
		System.out.println("usage: " + POIUpdateDriver.class.getName() + " -h <host> -p <port>");
		System.exit(0);
	}

	private static RequestProcessor getProcessor(String strHost, int intPort)
	{
		RequestProcessor processor = new RequestProcessor();
		processor.setHost(strHost);
		processor.setPort(intPort);
		processor.setProjection(new NoProjection());

		// Connect to the KLE
		processor.setStatus(Constants.CLIENT_STATUS_CONNECTED);

		return processor;
	}


	/**
	 * This method picks up the field values of the poi to br updated
	 * from the "poiUpdData.properties" file and created a KivPOI object.
	 *
	 * @return poiObject KivPOI The POI object to be updated.
	 */
	private static KivPOI getPoi()
	{
		// Reading the poi data from the poiUpdData.properties file
		java.util.Locale theLocale = new java.util.Locale("en", "");
		PropertyResourceBundle poiUpdDataBundle = 
			(PropertyResourceBundle)ResourceBundle.getBundle("poiUpdData", theLocale);

		String strTemp = null;

		// Details of the POI which needs to be updated.

		strTemp             = poiUpdDataBundle.getString("clientId");
		POIUpdateDriver.clientId     = getIntValue(strTemp);

		// We don't pick up the date from the data file
		String format       = "MM.dd.yyyy hh:mm";
		java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat(format);
		POIUpdateDriver.dateTimeStamp  = sdf.format(new Date());

		// Since this is an update the poi Id in the file should match an
		// existing poi id in the database
		KivPOIKey poiKey       = new KivPOIKey();
		 strTemp            = poiUpdDataBundle.getString("poiKey-poiId");
		poiKey.setId(getIntValue(strTemp));

		 strTemp            = poiUpdDataBundle.getString("poiKey-vendorId");
		poiKey.setVendorId(getIntValue(strTemp));

		// The POI should have atleast one name
		KivPOIName poiName1 = new KivPOIName();
		poiName1.setPoiName(poiUpdDataBundle.getString("poiName1-name"));
		poiName1.setLanguage(poiUpdDataBundle.getString("poiName1-language"));
		strTemp             = poiUpdDataBundle.getString("poiName1-kindOfName");
		poiName1.setKindOfName(getIntValue(strTemp));

		KivPOIName poiName2 = new KivPOIName();
		poiName2.setPoiName(poiUpdDataBundle.getString("poiName2-name"));
		poiName2.setLanguage(poiUpdDataBundle.getString("poiName2-language"));
		strTemp             = poiUpdDataBundle.getString("poiName2-kindOfName");
		poiName2.setKindOfName(getIntValue(strTemp));

		KivPOIName[] poiNames = new KivPOIName[2];
		poiNames[0]           = poiName1;
		poiNames[1]           = poiName2;

		//The address of the POI
		KivPOIAddress poiAddr = new KivPOIAddress();
		poiAddr.setHouseNumber(poiUpdDataBundle.getString("poiAddr-houseNum"));
		poiAddr.setStreetName(poiUpdDataBundle.getString("poiAddr-streetName"));
		poiAddr.setCity(poiUpdDataBundle.getString("poiAddr-city"));
		poiAddr.setAdmin1(poiUpdDataBundle.getString("poiAddr-admin1"));
		poiAddr.setAdmin2(poiUpdDataBundle.getString("poiAddr-admin2"));
		poiAddr.setCountry(poiUpdDataBundle.getString("poiAddr-country"));
		poiAddr.setPostalCode(poiUpdDataBundle.getString("poiAddr-postalCode"));

		//Area code of the POI
		strTemp             = poiUpdDataBundle.getString("areaCode");
		int poiAreaCode     = getIntValue(strTemp);

		//Phone Number
		strTemp             = poiUpdDataBundle.getString("phoneNum");
		int poiPhoneNum     = getIntValue(strTemp);

		//Latitude and Longitude
		strTemp             = poiUpdDataBundle.getString("latitude");
		int poiLat          = getIntValue(strTemp);
		strTemp             = poiUpdDataBundle.getString("longitude");
		int poiLong         = getIntValue(strTemp);


		//The number of categories to be searched

		 strTemp            = poiUpdDataBundle.getString("numOfCategories");
		 int numOfCats      = getIntValue(strTemp);


		int poiCategories[] = new int[numOfCats];
		String catName      = "category";

		 for( int i=0; i<numOfCats; i++)
		 {
		 	strTemp         = poiUpdDataBundle.getString(catName + (i+1));
			poiCategories[i]= getIntValue(strTemp);
		 }

		// Supplementary information for the POI
		KivPOISuppInfo poiSuppInfo = new KivPOISuppInfo();

		// The supp info has the same key as the poi record
		poiSuppInfo.setPoiKey(poiKey);

		strTemp                    = poiUpdDataBundle.getString("suppInfo-intField1");
		int intField1              = getIntValue(strTemp);
		strTemp                    = poiUpdDataBundle.getString("suppInfo-intField2");
		int intField2              = getIntValue(strTemp);
		strTemp                    = poiUpdDataBundle.getString("suppInfo-intField3");
		int intField3              = getIntValue(strTemp);
		strTemp                    = poiUpdDataBundle.getString("suppInfo-intField4");
		int intField4              = getIntValue(strTemp);
		strTemp                    = poiUpdDataBundle.getString("suppInfo-intField5");
		int intField5              = getIntValue(strTemp);
		strTemp                    = poiUpdDataBundle.getString("suppInfo-intField6");
		int intField6              = getIntValue(strTemp);
		strTemp                    = poiUpdDataBundle.getString("suppInfo-intField7");
		int intField7              = getIntValue(strTemp);
		strTemp                    = poiUpdDataBundle.getString("suppInfo-intField8");
		int intField8              = getIntValue(strTemp);
		strTemp                    = poiUpdDataBundle.getString("suppInfo-intField9");
		int intField9              = getIntValue(strTemp);
		strTemp                    = poiUpdDataBundle.getString("suppInfo-intField10");
		int intField10             = getIntValue(strTemp);

		poiSuppInfo.setIntField1(intField1);
		poiSuppInfo.setIntField2(intField2);
		poiSuppInfo.setIntField3(intField3);
		poiSuppInfo.setIntField4(intField4);
		poiSuppInfo.setIntField5(intField5);
		poiSuppInfo.setIntField6(intField6);
		poiSuppInfo.setIntField7(intField7);
		poiSuppInfo.setIntField8(intField8);
		poiSuppInfo.setIntField9(intField9);
		poiSuppInfo.setIntField10(intField10);
		poiSuppInfo.setTextField1(poiUpdDataBundle.getString("suppInfo-textField1"));
		poiSuppInfo.setTextField2(poiUpdDataBundle.getString("suppInfo-textField2"));
		poiSuppInfo.setTextField3(poiUpdDataBundle.getString("suppInfo-textField3"));
		poiSuppInfo.setTextField4(poiUpdDataBundle.getString("suppInfo-textField4"));
		poiSuppInfo.setTextField5(poiUpdDataBundle.getString("suppInfo-textField5"));
		poiSuppInfo.setTextField6(poiUpdDataBundle.getString("suppInfo-textField6"));
		poiSuppInfo.setTextField7(poiUpdDataBundle.getString("suppInfo-textField7"));
		poiSuppInfo.setTextField8(poiUpdDataBundle.getString("suppInfo-textField8"));
		poiSuppInfo.setTextField9(poiUpdDataBundle.getString("suppInfo-textField9"));
		poiSuppInfo.setTextField10(poiUpdDataBundle.getString("suppInfo-textField10"));

		poiSuppInfo.setDateField1(poiUpdDataBundle.getString("suppInfo-dateField1"));
		poiSuppInfo.setDateField2(poiUpdDataBundle.getString("suppInfo-dateField2"));
		poiSuppInfo.setDateField3(poiUpdDataBundle.getString("suppInfo-dateField3"));
		poiSuppInfo.setDateField4(poiUpdDataBundle.getString("suppInfo-dateField4"));
		poiSuppInfo.setDateField5(poiUpdDataBundle.getString("suppInfo-dateField5"));
		poiSuppInfo.setDateField6(poiUpdDataBundle.getString("suppInfo-dateField6"));
		poiSuppInfo.setDateField7(poiUpdDataBundle.getString("suppInfo-dateField7"));
		poiSuppInfo.setDateField8(poiUpdDataBundle.getString("suppInfo-dateField8"));
		poiSuppInfo.setDateField9(poiUpdDataBundle.getString("suppInfo-dateField9"));
		poiSuppInfo.setDateField10(poiUpdDataBundle.getString("suppInfo-dateField10"));
		//poiSuppInfo.setBlobField1(poiUpdDataBundle.getString("suppInfo-blobField1"));

		// Create the POI object
		KivPOI thePOI       = new KivPOI();

		thePOI.setPoiKey(poiKey);
		thePOI.setPoiNames(poiNames);
		thePOI.setPoiAddress(poiAddr);
		thePOI.setAreaCode(poiAreaCode);
		thePOI.setPhoneNumber(poiPhoneNum);
		thePOI.setLatitude(poiLat);
		thePOI.setLongitude(poiLong);
		thePOI.setCategories(poiCategories);
		thePOI.setSuppInfo(poiSuppInfo);

		return thePOI;
	}


	private static int getIntValue(String strValue)
	{
		int intValue = 0;

		try
		{
			intValue = Integer.parseInt(strValue);
		}
		catch(NumberFormatException e)
		{
			intValue = 0;
		}
		return intValue;
	}

	private static int clientId;
	private static String dateTimeStamp;
}
