/* 
* (C) Copyright 2000-2004 by Kivera, Inc.  All rights reserved. >>./client/examples/source/kiv_poi_on_along_route_ex.c.new
echo * 
* This material is protected by U.S. and international 
* copyright laws and may not be reproduced, modified, 
* distributed, publicly displayed or used to create derivative 
* works without the express written consent of Kivera, Inc.  
* The information contained herein is considered a trade 
* secret as defined in section 499C of the penal code of the 
* State of California. This copyright notice may not be 
* altered or removed. 
* 
*/ 
/******************************************************
 * File: kiv_poi_on_along_route_ex.c                  *
 * -------------------------------------------------- *
 * Description:  An example program for exhibiting    *
 *               proper usage of the                  *
 *               kiv_poiOnAlongRoute function for     *
 *               searching the for pois on or         *
 *               along(around) a route.               *
 *               The POI_ON_ALONG_ROUTE_REQ structure *
 *               needs to be populated with the       *
 *               shape points for the route. Atleast  *
 *               2 shape points are needed. The shape *
 *               points array can be obtained from    *
 *               the RT_OUT structure returned by the *
 *               nwc_calculate_route function. The    *
 *               rt_shp array from that output can be *
 *               directly used here.                  *
 *               The user can set a search radius     *
 *               value greater than 0 if pois are     *
 *               needed around the route. The user can*
 *               optionally set the vendorId,         *
 *               categories or name of poi if pois    *
 *               matching a particular criteria are   *
 *               needed.                              *
 ******************************************************/

/******************************************************
 *Library Includes                                    *
 ******************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "capis.h"
#include "iso_codes.h"

#ifdef _MSC_VER
#include "win_getopt.h"
#include "WinSock2.h"
#endif

#ifdef LINUX
#include <unistd.h>
#endif
/******************************************************
 * Constant Definitions
 ******************************************************/

/******************************************************
 * Utility function prototypes
 ******************************************************/
/* gets host and port from command-line arguments */
int get_host_and_port(int argc, char *argv[], char **host, int * port);


/* prints information about  a poi */
void dump_poi(POI_EDIT_STRUCT *poi );


/******************************************************************
 * Geocode a point
 *****************************************************************/
int geocode_point(
    NWC_CLIENT *handle,
    int        *database_prefs,
    char       *line1,           /* first line of address */
    char       *line2,           /* second line of address */
    char       *country,         /* country containing address */
    RT_POINT   *point /* geocoded point, output */
    );

/**************************************************************************
 * Clean up memory allocated on the heap for geocoding client API calls. 
 **************************************************************************/
int cleanup_geocoding(
    GEO_REQ     *request, /* Geocoding request */
    GEO_INFO    *info,    /* Info about geocoded point returned from
                           * geocoding Client API */
    GEO_OPTIONS *options  /* list of options returned from Client API
                           * if geocoding fails */
    );

/************************************************************************
 * Does the routing part.
 ************************************************************************/
int do_route(
    NWC_CLIENT *handle,          /* location server handle */
    int        *database_prefs,  /* routing database preferences */
    RT_POINT   *source,          /* route origin */
    RT_POINT   *destination,     /* route destination */
	RT_REQ     *route_request,
	RT_OUT     *route
    );

/******************************************************************
 * Clean up memory allocated on heap by routing API
 *****************************************************************/
int cleanup_routing( RT_REQ *route_request,
                     RT_OUT *route);

/******************************************************
 * Poi search pois on/along route example function prototypes
 ******************************************************/

/* Demonstrates the use of pois on/along route API */
int poi_onAlongRoute( NWC_CLIENT *handle, POI_ON_ALONG_ROUTE_REQ *req, 
					  POI_ON_ALONG_ROUTE_RES *res, int noOfPoints,
					  int *shapePoints);


/******************************************************
 * Main program
 ******************************************************/
int main(int argc, char *argv[]) 
{

    /******************************************************
     * Declarations
     ******************************************************/
    int status = NW_OK;                   /* function return status */

    char *host                   = NULL;  /* host on which server is running */
    int   port                   = 0;     /* port on which server running */
    NWC_CLIENT *handle           = NULL;  /* server connection handle */

    RT_POINT
        source,           /* route source */
        destination;      /* route destination */

    RT_REQ route_request;        /* routing API input structure */
    RT_OUT route;                /* routing API output structure */

    CSF_DB server_dbs;   /* information about databases loaded on server */
    
    int primaryDbPref[NW_DB_MAX];          /* for geocoding/routing
                                            * with primary database only */


	POI_ON_ALONG_ROUTE_REQ onAlongRtReq; /* the onAlongRt request */
	POI_ON_ALONG_ROUTE_RES onAlongRtRes; /* the onAlongRt response */

    /**********************************************************************
     * Initialize structures
     **********************************************************************/
    memset(&source,                 0, sizeof(RT_POINT));
    memset(&destination,            0, sizeof(RT_POINT));
    //memset(&route_request,          0, sizeof(RT_REQ));
    //memset(&route,                  0, sizeof(RT_OUT));
    memset(primaryDbPref,          0, NW_DB_MAX * sizeof(int));

    memset(&onAlongRtReq, 0, sizeof(POI_ON_ALONG_ROUTE_REQ));
    memset(&onAlongRtRes, 0, sizeof(POI_ON_ALONG_ROUTE_RES));

    /**********************************************************************
     * Get host and port command line arguments
     **********************************************************************/
    if (get_host_and_port(argc, argv, &host, &port) == FALSE)
        exit(0);

    /**********************************************************************
     * Initialize client options
     **********************************************************************/
    handle = nwc_init_client_option(UNPROJECTED);

    if ( NULL == handle )
    {
        printf("Error initializing client options\n");
        exit( 1 );
    }

    /**********************************************************************
     * Connect to location server
     **********************************************************************/
    status = nwc_connect(handle, host, (u_short)port);

    if (status < 0)
    {
        printf("Error connecting to server, status = %d\n", status);
        exit( 1 );
    }


    /**********************************************************************
     * Get list of databases loaded on location server
     **********************************************************************/
    status = nwc_get_mdb_list(handle, &server_dbs);

    if (NW_OK != status)
    {
        printf("Error getting the server database list, status = %d\n",
               status);
        exit( 1 );
    }

    /**********************************************************************
     * Set up arrays of database preferences
     **********************************************************************/
    if (server_dbs.num < 1)
    {
        printf("Error - no databases available on server\n");
        exit(1);
    }
    else
    {
        primaryDbPref[0] = server_dbs.db[0].id;
    }

    /**********************************************************************
     * Geocode source
     **********************************************************************/
    status = geocode_point( handle,
                            primaryDbPref,
                            "",
                            "orinda,ca",
                            "USA",
                            &source );

    if (NW_OK != status)
    {
        printf("Error geocoding source, status = %d\n", status);
        exit(1);
    }
    

    /**********************************************************************
     * Geocode destination
     **********************************************************************/
    status = geocode_point( handle,
                            primaryDbPref,
                            "",
                            "oakland,ca",
                            "USA",
                            &destination );
    if (NW_OK != status)
    {
        printf("Error geocoding destination, status = %d\n", status);
        exit(1);
    }

    
	/**************************************************************
	 * Get the route.
	 **************************************************************/
    status = do_route( handle,
                       primaryDbPref,
                       &source,
                       &destination,
					   &route_request,
					   &route);

    if (NW_OK != status)
    {
        /* --- There is an error --- */
        printf( "simple_example failed, status = %d.\n\n",
                status);
    }

	/*
	 * Now that we have got a "route" we can send the shape points from the
	 * route to the search pois along route api.
	 */

    
    /**********************************************************************
     * poi on/along route example
     **********************************************************************/
    printf("\n\n"
           "==============================================================\n"
           "Poi search pois along route example\n"
           "==============================================================\n");
    status = poi_onAlongRoute( handle, &onAlongRtReq, &onAlongRtRes,
							   route.rt_scnt,      /* num of shape points */
							   route.rt_shp       /* shape point array   */
							   );

    cleanup_routing( &route_request, &route );
    
    /* --- Exit Program --- */
    status = nwc_disconnect(handle);

    if (NW_OK != status)
    {
        printf("Error disconnecting from server, status = %d\n", status);
        exit(1);
    }
    
    status = nwc_delete_client_option(handle);

    if (NW_OK != status)
    {
        printf("Error cleaning up client handler, status = %d\n", status);
        exit(1);
    }

    exit ( 0 );
  
}

/******************************************************
 * Print information on how to use this program
 ******************************************************/
void print_usage(char *prog_name)
{
    printf("Usage: %s [-?] -h <host> -p <port>\n"
           "       -? print this message\n"
           "       -h host machine name\n"
           "       -p port number\n\n",
           prog_name);
}

/******************************************************
 * Get host and port command line arguments
 ******************************************************/
int get_host_and_port(int argc, char *argv[], char **host, int * port){

    int helpFlag = FALSE, c;

    while ((c = getopt(argc, argv, "h:p:")) != EOF) {
        switch (c) {
        case 'p':
            /* get the port */
            *port = atoi(optarg);
            break;
        case 'h':
            /* get the host */
            *host = optarg;
            break;
        case '?':
        default:
            /* if unknown argument or "help" flag was specified, turn
             * on the help flag */
            helpFlag = TRUE;
            break;
        }
    }

    /* if host or port was not specified, turn on the help flag */
    if ((*host == NULL) || (*port == 0))
    {
        helpFlag = TRUE;
    }

    if(helpFlag)
    {
        print_usage(argv[0]);
        return FALSE;
    }
    return TRUE;
}

/******************************************************
 * Initialize geocoding input and output structures
 ******************************************************/
int initialize_geocoding(GEO_REQ     *request,   /* input structure */
                         GEO_OPTIONS *options,   /* output options list */
                         GEO_INFO    *info_list, /* output info list */
                         RT_POINT    *result)
{
    int i, j; /* loop control variables */


    /*****************************************************************
     * Validate input
     *****************************************************************/
    if ( (NULL == request) ||
         (NULL == options) ||
         (NULL == info_list) ||
         (NULL == result) )
    {
        return NW_ERROR_INIT;
    }

    /*****************************************************************
     * Clear all input structures
     *****************************************************************/
    memset(request,   0, sizeof(GEO_REQ));
    memset(options,   0, sizeof(GEO_OPTIONS));
    memset(info_list, 0, sizeof(GEO_INFO));
    memset(result,    0, sizeof(RT_POINT));


    /*****************************************************************
     * Allocate memory for list of choices returned by geocoding in
     * case geocoding fails.
     *****************************************************************/
    /* limit choices to 10 */
    options->limit = 10;
    
    /* allocate array for options->limit count of uchar arrays */
    options->list = (unsigned char **) calloc( options->limit,
                                               sizeof( uchar * ) );
    /* make sure that malloc worked */
    if (NULL == options->list)
    {
        printf("malloc failed - unable to create options->list\n");
        return -1;
    }

    /* populate array allocated above with uchar arrays for options */
    for ( i = 0; i < options->limit; i++ ) 
    {
        /* malloc uchar array big enough to hold largest option
           returned by server */
        options->list[i] = (unsigned char *) calloc( NW_LINE_MAX,
                                                     sizeof( uchar ) );
        /* make sure that malloc worked */
        if (NULL == options->list[i])
        {
            printf("malloc failed - unable to create options->list\n");

            /* clean up memory already allocated */
            for (j = i - 1;
                 j >= 0;
                 j--)
            {
                free(options->list[j]);
            }
            free(options->list);
            
            return -1;
        }
    }

    return NW_OK;
}

/**************************************************************************
 * Clean up memory allocated on the heap for geocoding client API calls. 
 **************************************************************************/
int cleanup_geocoding(
    GEO_REQ     *request, /* Geocoding request */
    GEO_INFO    *info,    /* Info about geocoded point returned from
                           * geocoding Client API */
    GEO_OPTIONS *options  /* list of options returned from Client API
                           * if geocoding fails */
    )
{
    int i; /* loop control variable */
    
    /*****************************************************************
     * Validate arguments
     *****************************************************************/
    if ( ( NULL == request ) ||
         ( NULL == info )    ||
         ( NULL == options ) )
    {
        return -1;
    }

    /*****************************************************************
     * Free options list
     *****************************************************************/
    for (i = 0;
         i < options->limit;
         i++)
    {
        if (NULL != options->list[i])
        {
            free(options->list[i]);
        }
    }
    free(options->list);
    return NW_OK;
}

/*****************************************************************
 * Initialize routing API structures
 *****************************************************************/
int initialize_routing(
    RT_REQ   *request,         /* routing input
                                * structure */
    RT_OUT   *output,          /* routing output
                                * structure */
    int      *mapDbPref        /* databases to be used in routing, in
                                * order of preference from most
                                * preferred to least preferred */
    )
{
    int status = 0;  /* for checking error returns */
    int i      = 0;  /* loop control variable */

    /*****************************************************************
     * Validate inputs
     *****************************************************************/
    if ( (NULL == request) ||
         (NULL == output) )
    {
        printf("Invalid arguments to initialize_routing\n");
        return -1;
    }

    /*****************************************************************
     * Initialize input structures
     *****************************************************************/
    memset(request, 0, sizeof(RT_REQ));
    memset(output,  0, sizeof(RT_OUT));

    /*
      Stopovers are always ordered, regardless of the value of
      request->ordered.
    */
    request->ordered = 1;

    /*
      lang2 and unit2 should always be set to 0, because only one
      explication language is supported at this time.  If they are
      non-zero there will still be only one explication language
      produced, but lang2 and unit2 will be validated in the same way
      lang1 and unit1 are.  If you don't memset the request or
      explicitly set these to 0 most likely you will get
      NWC_ERROR_PARAM back, telling you that you have set lang2/unit2
      to bad values.
    */

    request->lang2[0] = '\0';
    //strcpy(request->lang2, KVR_ISO_639_ENGLISH);
    request->unit2   = NW_UNIT_MILE;

    /*************************************************
     * Set default request values
     *************************************************/
    request->output_flags    = NW_RT_SHAPE | NW_RT_EXPL; /* explication
                                                          * and shape
                                                          * output */
    strcpy(request->lang1, KVR_ISO_639_ENGLISH); /* explication in english */
    request->unit1 = NW_UNIT_MILE;               /* route distance in miles */

    /**********************************************************************
     * If max_num_sols and max_extra_links are not set to USE_DEFAULT,
     * the values you pass will be used, even if you pass invalid
     * values.
     *
     * max_num_sols and max_extra_links affect how long the server
     * tries to find a better solution after the first solution is
     * found.  The server will stop searching for solutions when it
     * finds the number of solutions specified by max_num_sols, or
     * when it has explored max_extra_links beyond the first solution,
     * whichever comes first.
     *
     * The server will always try to find at least one solution,
     * regardless of how these values are set.
     **********************************************************************/
    request->max_num_sols    = USE_DEFAULT; 
    request->max_extra_links = USE_DEFAULT;
    
    /**********************************************************************
     * Heap size affects the amount of memory used during route
     * calculation.  If you are using a via point, you should set this
     * to LARGE_HEAP, or else your route may fail.
     **********************************************************************/
    request->heap_size       = DEFAULT_HEAP;
    
    request->time_of_travel  = 0; /* 0 means "now" */

    /******************************************************************
     * Copy database preference array.  Note that if you are keeping
     * your own array of database preferences in memory, you should
     * memset the array before putting in database preferences.
     * Kivera's client code assumes that anything other than 0 is a
     * valid database preference, and that the array of preferences is
     * NW_DB_MAX in length.
     *****************************************************************/
    for (i = 0;
         (i < NW_DB_MAX) && (0 != mapDbPref[i]);
         i++)
    {
        request->mapDbPref[i] = mapDbPref[i];
    }

    /******************************************************************
     * Call Client API to initialize routing output structure.
     *****************************************************************/
    status =  nwc_rt_out_init( output );
    if (NW_OK != status) 
    {
        /* --- An error has occurred --- */
        printf( "RT_OUT structure initialization failed, status = %d\n\n",
                status );
        return status;
    }

    return NW_OK;
}

/******************************************************************
 * Clean up memory allocated on heap by routing API
 *****************************************************************/
int cleanup_routing( RT_REQ *route_request,
                     RT_OUT *route)
{
    int status = NW_OK;

    if ( ( NULL == route_request ) ||
         ( NULL == route ) )
    {
        printf( "Bad arguments to cleanup_routing\n" );
        return -1;
    }

    status = nwc_rt_out_free(route);

    if ( NW_OK != status )
    {
        printf("Error freeing route\n");
    }

    return status;
}

/******************************************************************
 * Geocode a point
 *****************************************************************/
int geocode_point(
    NWC_CLIENT *handle,
    int        *database_prefs,
    char       *line1,           /* first line of address */
    char       *line2,           /* second line of address */
    char       *country,         /* country containing address */
    RT_POINT   *point /* geocoded point, output */
    )
{
    int         status = NW_OK; /* for checking return statuses */
    GEO_REQ     request;        /* geocoding input structure */
    GEO_INFO    info;           /* returned from geocoding -
                                 * information about geocoded point */
    GEO_OPTIONS options;        /* options list returned if geocoding
                                 * cannot resolve address */
    int         i = 0;          /* loop control variable */

    /*********************************************************************
     * Initialize geocoding structures
     *********************************************************************/
    status = initialize_geocoding( &request,
                                   &options,
                                   &info,
                                   point );

    if (NW_OK != status)
    {
        return status;
    }

    /*********************************************************************
     * Copy address to geocoding request
     *********************************************************************/
    strncpy( request.line1,
             line1,
             NW_LINE_MAX );
    strncpy( request.line2,
             line2,
             NW_LINE_MAX );
    strncpy( request.country,
             country,
             NW_LINE_MAX );

    /* line3 is reserved for future use */
    request.line3[0] = '\0';

    /*********************************************************************
     * Copy database preferences to geocoding request
     *********************************************************************/
    for (i = 0;
         ( (i < NW_DB_MAX) && (0 != database_prefs[i]) );
         i++)
    {
        request.mapDbPref[i] = database_prefs[i];
    }

    /*********************************************************************
     * Geocode to 10 feet from road
     *********************************************************************/
    request.offset = 10;
    request.unit   = NW_UNIT_FT;

    /*********************************************************************
     * Call client API to geocode point
     *********************************************************************/
    status = nwc_geocode( handle,
                          &request,
                          &options,
                          &info,
                          point);

    
    /*********************************************************************
     * Clean up memory allocated on heap for API calls.  
     *********************************************************************/
    cleanup_geocoding( &request,
                       &info,
                       &options );

    return status;
}

/************************************************************************
 * Does the routing part.
 ************************************************************************/
int do_route(
    NWC_CLIENT *handle,          /* location server handle */
    int        *database_prefs,  /* routing database preferences */
    RT_POINT   *source,          /* route origin */
    RT_POINT   *destination,     /* route destination */
	RT_REQ     *route_request,
	RT_OUT     *route
    )
{
    int    status = 0;           /* for checking error returns */

    if ( (NULL == source) ||
         (NULL == destination)
        )
    {
        printf("Error in parameters to simple_example\n");
        return -1;
    }

    
    /*********************************************************************
     * Initialize routing structures
     *********************************************************************/
    status = initialize_routing( route_request,
                                 route,
                                 database_prefs);
    if (status != NW_OK)
    {
        printf("simple_example: unable to intialize routing structures\n");
        return status;
    }

    /*********************************************************************
     * Set source and destination
     *********************************************************************/
    route_request->src = source;
    route_request->dst = destination;

    /*********************************************************************
     * Call routing API
     *********************************************************************/
    status = nwc_calculate_route( handle, route_request, route);

    if (status < 0)
    {
        printf("simple_example failed, status = %d, message = %s\n",
               status, route->rt_emsg);
        return status;
    }


    return NW_OK;
}


/******************************************************************
 * Clean up memory allocated on heap by on/along route API
 *****************************************************************/
int cleanup_poiOnAlongRt(POI_ON_ALONG_ROUTE_REQ *onAlongRt_req, 
						 POI_ON_ALONG_ROUTE_RES *onAlongRt_res)
{
    int status = NW_OK;

    if ( (NULL == onAlongRt_res) || (NULL == onAlongRt_req) ) 
    {
        printf( "Bad arguments to cleanup_poiOnAlongRt\n" );
        return -1;
    }

    status = kiv_freePoiOnAlongRouteReq(onAlongRt_req);

    if ( NW_OK != status )
    {
        printf("Error freeing search supp info request\n");
    }

    status = kiv_freePoiOnAlongRouteRes(onAlongRt_res);

    if ( NW_OK != status )
    {
        printf("Error freeing search supp info response\n");
    }

    return status;
}




/************************************************************************
 * A poi search along route example.
 ************************************************************************/
int poi_onAlongRoute(
    NWC_CLIENT *handle,                          /* location server handle  */
    POI_ON_ALONG_ROUTE_REQ   *onAlongRt_req,     /* poi onAlongRt request   */
    POI_ON_ALONG_ROUTE_RES   *onAlongRt_res,     /* poi onAlongRt response  */
	int noOfPoints,                              /* shape points from route */
	int *Points                                  /* shape points from route */
    )
{
    int    status = 0;                    /* for checking error returns */
	int i;

    if ( (NULL == onAlongRt_req) || (NULL == onAlongRt_res) )
    {
        printf("Error in parameters to poi_onAlongRoute\n");
        return -1;
    }


	/**********************************************************************
	 * Populate the poi onAlongRt request
	 **********************************************************************/
	 onAlongRt_req->vendorId       = 911;      

     
      onAlongRt_req->noOfCategories = 1;  

	/* allocate memory for the categories array */
	onAlongRt_req->categories = (int*)malloc(sizeof(int) * 1);


	/* Set the categories */
	onAlongRt_req->categories[0]   = 1200;

	/* Set the poi name if you want pois with certain name */
	/*
	strcpy(onAlongRt_req->name,"Shell");
	*/

	/* Radius of search. Make it 0.0 if you want pois on a route. */
	onAlongRt_req->radius     = 1.0;
	onAlongRt_req->radiusUnit = NW_UNIT_MILE;


	 onAlongRt_req->noOfPoints= noOfPoints;  /* The no. of shape points */
											 /* returned by routing api */

	 onAlongRt_req->shapePoints = 
						(int*)malloc(sizeof(int)*onAlongRt_req->noOfPoints*2);

	for(i=0; i<(onAlongRt_req->noOfPoints*2);i++)
	{
	 	memcpy(&onAlongRt_req->shapePoints[i], &Points[i], sizeof(int));    
											  /* The shape points        */
	}

    
    /*********************************************************************
     * Call search on/along route API
     *********************************************************************/
    status = kiv_poiOnAlongRoute( handle, onAlongRt_req, onAlongRt_res);

    if (status < 0)
    {
        printf("poi_onAlongRoute failed, status = %d\n", status);
    }
    else
    {
        printf("poi_onAlongRoute successful, status = %d\n", status);
        printf("\nThe number of POIS returned = %d\n\n", onAlongRt_res->noOfPois);
        printf("The POIS returned are:\n\n");
		for(i=0; i<onAlongRt_res->noOfPois;i++)
		{
			dump_poi(&onAlongRt_res->pois[i]);
			printf("\n");
		}
    }

	/* Since both the request and response allocate dynamic memory we */
	/* need to clean up after both.                                   */
    cleanup_poiOnAlongRt(onAlongRt_req, onAlongRt_res );

    return NW_OK;
}


/**************************************************************************
 * Dump information about the poi which matched the search criteria.
 **************************************************************************/
void dump_poi(POI_EDIT_STRUCT *poi)
{
	int i = 0;
    printf( "POI: vendorId = %d, poiId = %d, numOfNames = %d\n",
            poi->vendorId, poi->poiId, poi->numOfNames );

	for(i=0; i<poi->numOfNames; i++)
	{
		printf("POI: Name = %s ", poi->names[i].name);
	}


    printf( "POI: areaCode = %d, phoneNumber = %d, latitude = %d\n",
            poi->areaCode, poi->phoneNumber, poi->latitude );
    printf( "POI: longitude = %d, noOfCatefories = %d\n",
            poi->longitude, poi->noOfCategories);

   	printf( "POI: suppInfo = %s\n", poi->info.string5);
   	printf( "POI: distance = %f\n", poi->distance);
}
