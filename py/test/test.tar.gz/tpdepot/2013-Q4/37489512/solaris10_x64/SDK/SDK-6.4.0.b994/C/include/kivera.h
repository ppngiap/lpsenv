/* 
* (C) Copyright 2000-2004 by Kivera, Inc.  All rights reserved. >>./client/API/c/libclient/include/kivera.h.new
echo * 
* This material is protected by U.S. and international 
* copyright laws and may not be reproduced, modified, 
* distributed, publicly displayed or used to create derivative 
* works without the express written consent of Kivera, Inc.  
* The information contained herein is considered a trade 
* secret as defined in section 499C of the penal code of the 
* State of California. This copyright notice may not be 
* altered or removed. 
* 
*/ 
/*
 *  File:   kivera.h
 *
 *  Description:
 *          Kivera product header file
 *
 *  Author: 
 *
 *  Last update:
 *
 *  Notes:  None.
 *
 *  Bugs:   None.
 */

#ifndef _KIVERA_H
#define _KIVERA_H

#include <stdio.h>
#include <stdlib.h>

/*
** General definitions
*/

/*
 * Convenience Definitions.
 *
 * These definitions are meant to be of convenience for all
 * programmers.
 */


#if !defined TRUE
#define TRUE 1
#endif

#if !defined FALSE
#define FALSE 0
#endif

#if !defined NULL
#define NULL 0
#endif

#if !defined NULLSTRING
#define NULLSTRING '\0'
#endif

#if !defined NOT
#define NOT !
#endif

#if !defined NONE
#define NONE 0
#endif

#if !defined SUCCESS
#define SUCCESS 0
#endif

#if !defined OK
#define OK 0
#endif

/*
#if !defined FAILED
#define FAILED -1
#endif 
*/

#if !defined GENERAL_ERROR
#define GENERAL_ERROR -1
#endif

#if !defined ERR_GENERAL
#define ERR_GENERAL -1
#endif

/** @name Sizes used in creating names and paths */
//@{
#define MAX_NAME_SZ         40

#define SZ_LINE         256
#define SZ_FILENAME     512
#define SZ_PATHNAME     1024
#define SZ_COMMAND      1024

#define FILEPATH_LEN    256
#define FILENAME_LEN    256
//@}

/** @name Regions of the world. */
//@{
#define		NWAREA_US		"US"
#define		NWAREA_EU		"EU"
#define		NWAREA_AU		"AU"
//@}

/** @name Linear units used with coordinates, mapping and explication. */
//@{
#define NW_UNIT_MILE     'M'
#define NW_UNIT_KM       'K'
#define NW_UNIT_FT       'f'
#define NW_UNIT_M        'm'
#define NW_UNIT_W        'W'
//@}

/** @name Projection definitions */
//@{
#define UNPROJECTED             0
#define MERCATOR                1
#define ELLIPSE_MERCATOR        2   // unsupported at this time
// update value when new types added
#define MAX_PROJECTION          1
//@}

#ifndef _TYPEDEFS
#define _TYPEDEFS
/** @name General C data types intended to increase portability. */
//@{
#ifndef _WINNT
#ifndef _MSC_VER
typedef void            VOID;
typedef int             BOOLEAN;
#endif
#endif

#ifndef _MSC_VER
typedef int             boolean;
#endif

typedef int             INT;
typedef unsigned int    UINT;
typedef long            LONG;
typedef unsigned long   ULONG;
typedef short           SHORT;
typedef unsigned short  USHORT;
typedef char            CHAR;
typedef unsigned char   UCHAR;
typedef float           FLOAT;
typedef double          DOUBLE;
//@}
#endif

/** @name Kind masks. */
//@{
#ifndef K1_MASK
#define K1_MASK                 0xf000
#define K2_MASK                 0x0f00
#define K3_MASK                 0x00ff
#define K1K2_MASK               0xff00
#define K2K3_MASK               0x0fff
//@}

/** @name Link kind K1 information. */
//@{
#define L_K1_ROAD               0x1000
#define L_K1_RAIL               0x2000
#define L_K1_ADMIN              0x3000
#define L_K1_HYDRO              0x4000
#define L_K1_GREEN              0x5000
#define L_K1_URBAN              0x6000
#define L_K1_SITE               0x7000
#define L_K1_CARTOGRAPHY        0x3000
//@}

/** @name Link kind K2 information. */
//@{
#define L_K2_PSEUDO             0x0e00
//@}
#endif

/** @name Limits. */
//@{
#define LVL_3_C_CNT     1
#define LVL_4_C_CNT     16
#define LVL_5_C_CNT     256
#define LVL_6_C_CNT     4096
//@}

/** @name Cell Levels. */
//@{
#define CELL_LVL_2      2
#define CELL_LVL_3      3
#define CELL_LVL_4      4
#define CELL_LVL_5      5
#define CELL_LVL_6      6
#define LOWEST_LVL      6
//@}

/* ---  sign --- */
typedef struct s_sign
{
    UINT        numb;
    USHORT      nm_cnt;
    UINT        nm_idx;
} S_SIGN;

// returns database items: country names, languages, etc.
typedef struct
{
    int mapDbID;
    int count;
    char **list;
} DB_ENTRY_LIST;

#endif
