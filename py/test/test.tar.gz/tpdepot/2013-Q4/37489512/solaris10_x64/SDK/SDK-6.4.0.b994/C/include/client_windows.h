/* 
* (C) Copyright 2000-2004 by Kivera, Inc.  All rights reserved. >>./client/API/c/libclient/include/client_windows.h.new
echo * 
* This material is protected by U.S. and international 
* copyright laws and may not be reproduced, modified, 
* distributed, publicly displayed or used to create derivative 
* works without the express written consent of Kivera, Inc.  
* The information contained herein is considered a trade 
* secret as defined in section 499C of the penal code of the 
* State of California. This copyright notice may not be 
* altered or removed. 
* 
*/ 
#ifndef CLIENT_WINDOWS_H
#define CLIENT_WINDOWS_H

#ifdef _MSC_VER
typedef unsigned char   u_char;
typedef unsigned short  u_short;
typedef unsigned int    u_int;
typedef unsigned long   u_long;
typedef struct _quad { int val[2]; } quad_t;    /* used by UFS */
typedef quad_t          quad;                   /* used by UFS */  
#endif

#ifdef DLL_TRUE
#define DLLEXPORT extern __declspec(dllexport)
#else
#define DLLEXPORT 
#endif

#endif
