/* 
* (C) Copyright 2000-2004 by Kivera, Inc.  All rights reserved. >>./client/examples/source/kiv_select_poi_ex.c.new
echo * 
* This material is protected by U.S. and international 
* copyright laws and may not be reproduced, modified, 
* distributed, publicly displayed or used to create derivative 
* works without the express written consent of Kivera, Inc.  
* The information contained herein is considered a trade 
* secret as defined in section 499C of the penal code of the 
* State of California. This copyright notice may not be 
* altered or removed. 
* 
*/ 
/******************************************************
 * File: kiv_select_poi_ex.c                          *
 * -------------------------------------------------- *
 * Description:  An example program for exhibiting    *
 *               proper usage of the                  *
 *               kiv_selectPoiData function for       *
 *               selecting a poi from the             *
 *               dynamic pois database      .         *
 ******************************************************/

/******************************************************
 *Library Includes                                    *
 ******************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "capis.h"
#include "iso_codes.h"

#ifdef _MSC_VER
#include "win_getopt.h"
#include "WinSock2.h"
#endif

#ifdef LINUX
#include <unistd.h>
#endif

/********************************************************************
 * ID OF THE POI TO BE SELECTED. THIS POI SHOULD EXIST IN THE DATABASE
 * Run the poi insert, which will give you an id for that inserted POI.
 * Replace the follwoing POI_ID value by the one you got from inserting a POI.
 ********************************************************************/
#define POI_ID 4027988

/******************************************************
 * Constant Definitions
 ******************************************************/

/******************************************************
 * Utility function prototypes
 ******************************************************/
/* gets host and port from command-line arguments */
int get_host_and_port(int argc, char *argv[], char **host, int * port);


/* prints information about  a poi */
void dump_poi(POI_EDIT_STRUCT *poi );



/******************************************************
 * Poi select example function prototypes
 ******************************************************/

/* Demonstrates the use of select API */
int poi_select( NWC_CLIENT *handle, POI_SELECT_REQ *req, POI_SELECT_RES *res );


/******************************************************
 * Main program
 ******************************************************/
int main(int argc, char *argv[]) 
{

    /******************************************************
     * Declarations
     ******************************************************/
    int status = NW_OK;                   /* function return status */

    char *host                   = NULL;  /* host on which server is running */
    int   port                   = 0;     /* port on which server running */
    NWC_CLIENT *handle           = NULL;  /* server connection handle */

	POI_SELECT_REQ poiSelectReq;          /* the select request */
	POI_SELECT_RES poiSelectRes;          /* the select response */

    /**********************************************************************
     * Initialize structures
     **********************************************************************/
    memset(&poiSelectReq, 0, sizeof(POI_SELECT_REQ));
    memset(&poiSelectRes, 0, sizeof(POI_SELECT_RES));

    /**********************************************************************
     * Get host and port command line arguments
     **********************************************************************/
    if (get_host_and_port(argc, argv, &host, &port) == FALSE)
        exit(0);

    /**********************************************************************
     * Initialize client options
     **********************************************************************/
    handle = nwc_init_client_option(UNPROJECTED);

    if ( NULL == handle )
    {
        printf("Error initializing client options\n");
        exit( 1 );
    }

    /**********************************************************************
     * Connect to location server
     **********************************************************************/
    status = nwc_connect(handle, host, (u_short)port);

    if (status < 0)
    {
        printf("Error connecting to server, status = %d\n", status);
        exit( 1 );
    }

    
    /**********************************************************************
     * poi select example
     **********************************************************************/
    printf("\n\n"
           "==============================================================\n"
           "Poi select example\n"
           "==============================================================\n");
    status = poi_select( handle, &poiSelectReq, &poiSelectRes);

    
    /* --- Exit Program --- */
    status = nwc_disconnect(handle);

    if (NW_OK != status)
    {
        printf("Error disconnecting from server, status = %d\n", status);
        exit(1);
    }
    
    status = nwc_delete_client_option(handle);

    if (NW_OK != status)
    {
        printf("Error cleaning up client handler, status = %d\n", status);
        exit(1);
    }

    exit ( 0 );
  
}

/******************************************************
 * Print information on how to use this program
 ******************************************************/
void print_usage(char *prog_name)
{
    printf("Usage: %s [-?] -h <host> -p <port>\n"
           "       -? print this message\n"
           "       -h host machine name\n"
           "       -p port number\n\n",
           prog_name);
}

/******************************************************
 * Get host and port command line arguments
 ******************************************************/
int get_host_and_port(int argc, char *argv[], char **host, int * port){

    int helpFlag = FALSE, c;

    while ((c = getopt(argc, argv, "h:p:")) != EOF) {
        switch (c) {
        case 'p':
            /* get the port */
            *port = atoi(optarg);
            break;
        case 'h':
            /* get the host */
            *host = optarg;
            break;
        case '?':
        default:
            /* if unknown argument or "help" flag was specified, turn
             * on the help flag */
            helpFlag = TRUE;
            break;
        }
    }

    /* if host or port was not specified, turn on the help flag */
    if ((*host == NULL) || (*port == 0))
    {
        helpFlag = TRUE;
    }

    if(helpFlag)
    {
        print_usage(argv[0]);
        return FALSE;
    }
    return TRUE;
}


/******************************************************************
 * Clean up memory allocated on heap by select poi API
 *****************************************************************/
int cleanup_select_poi( POI_SELECT_RES *select_poi_res)
{
    int status = NW_OK;

    if ( NULL == select_poi_res ) 
    {
        printf( "Bad arguments to cleanup_select_poi\n" );
        return -1;
    }

    status = kiv_freePoiSelectRes(select_poi_res);

    if ( NW_OK != status )
    {
        printf("Error freeing poi select response\n");
    }

    return status;
}




/************************************************************************
 * A poi select example.
 ************************************************************************/
int poi_select(
    NWC_CLIENT *handle,                /* location server handle */
    POI_SELECT_REQ   *poi_sel_req,     /* poi select request */
    POI_SELECT_RES   *poi_sel_res      /* poi select response */
    )
{
    int    status = 0;                    /* for checking error returns */

    if ( (NULL == poi_sel_req) || (NULL == poi_sel_res) )
    {
        printf("Error in parameters to poi_select\n");
        return -1;
    }


	/**********************************************************************
	 * Populate the poi select request
	 **********************************************************************/
	 poi_sel_req->vendorId  = 911;      
	 poi_sel_req->poiId     = POI_ID;          /* An existing poi in the database */

    
    /*********************************************************************
     * Call select API
     *********************************************************************/
    status = kiv_selectPoiData( handle, poi_sel_req, poi_sel_res);

    if (status < 0)
    {
        printf("poi_select failed, status = %d\n", status);
    }
    else
    {
        printf("poi_select successful, status = %d\n", status);
        printf("The POI selected is:\n\n");
		dump_poi(poi_sel_res->poi);
    }

    cleanup_select_poi(poi_sel_res );

    return NW_OK;
}


/**************************************************************************
 * Dump information about the poi which needs to be selected
 **************************************************************************/
void dump_poi(POI_EDIT_STRUCT *poi)
{
    printf( "POI: vendorId = %d, poiId = %d, numOfNames = %d\n",
            poi->vendorId, poi->poiId, poi->numOfNames );
}
