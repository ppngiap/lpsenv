/*
 * � 2001, Kivera, Inc.  This material is protected by U.S. and international
 * copyright laws and may not be reproduced, modified, distributed, publicly
 * displayed or used to create derivative works without the express written
 * consent of Kivera, Inc.  This copyright notice may not be altered or
 * removed.
 *
 */

//package com.kivera.kle;

import java.lang.*;
import java.io.*;
import java.util.*;
import java.beans.*;
import com.kivera.klc.*;
import com.kivera.klc.poi.*;
import java.awt.event.*;

/**
 * This driver class demonstrates how to insert a new POI into the dynamic
 * poi database.
 * This driver makes use of Kivera's client beans package to access the Kivera
 * Location Engine.
 *
 * @version 1.0
 */
public class POIInsertDriver
{

	public static void main(String [] args) 
	{

		// Get the host anf port from command line
		int intCounter = 0;
		int intPort    = 0;
		char parm      = '?';
		String strHost = "";

		for(intCounter=0;intCounter<args.length;intCounter++)
		{
			if (args[intCounter].charAt(0)=='-')
			{
				parm = Character.toLowerCase(args[intCounter].charAt(1));
			}
			switch(parm)
			{
				case 'h':
				    strHost = args[++intCounter];
				    break;
				case 'p':
				    intPort = Integer.parseInt(args[++intCounter]);
				    break;
				default:
				    showUsage();
				    break;
			}
		}
		if(strHost==null||strHost.equals("")||intPort<=0)
			showUsage();


		try
		{
			// Obtain the RequestProcessor object which is connected to the
			// KLE at the port and host input.

			RequestProcessor processor     = getProcessor(strHost, intPort);


			// Create the KivPOIManageBean for handling POI inserts
			KivPOIManageBean poiManageBean = new KivPOIManageBean();

			// Connect the bean to the RequestProcessor
			poiManageBean.addRequestListener(processor);

			//Create the POI object for the POI which needs to be inserrted
			KivPOI newPOI = getPoi();

			int status = poiManageBean.doInsert(newPOI, clientId, POIInsertDriver.dateTimeStamp);
			if(status <= 0)
			{
				System.out.println("\n");
				System.out.println("The insert operation failed with status:" + status);
				System.out.println("\n");
			}
			else
			{
				System.out.println("\n");
				System.out.println("The insert operation was successful\n");
				System.out.println("The id of the new POI is :: " + status);
				System.out.println("\n");
			}

		}
		catch(Exception e)
		{
			System.out.println("\n");
			System.out.println("Exception resolving bean\n");
			e.printStackTrace();
			System.out.println("\n");
		}

	}


	/**
	 * Display executable usage.
	 */
	public static void showUsage()
	{
		System.out.println("usage: " + POIInsertDriver.class.getName() + " -h <host> -p <port>");
		System.exit(0);
	}

	private static RequestProcessor getProcessor(String strHost, int intPort)
	{
		RequestProcessor processor = new RequestProcessor();
		processor.setHost(strHost);
		processor.setPort(intPort);
		processor.setProjection(new NoProjection());

		// Connect to the KLE
		processor.setStatus(Constants.CLIENT_STATUS_CONNECTED);

		return processor;
	}


	/**
	 * This method picks up the field values of the poi to br inserted
	 * from the "poiInsData.properties" file and created a KivPOI object.
	 *
	 * @return poiObject KivPOI The POI object to be inserted.
	 */
	private static KivPOI getPoi()
	{
		// Reading the poi data from the poiInsData.properties file
		java.util.Locale theLocale = new java.util.Locale("en", "");
		PropertyResourceBundle poiInsDataBundle = 
			(PropertyResourceBundle)ResourceBundle.getBundle("poiInsData", theLocale);

		String strTemp = null;

		// Details of the POI which needs to be inserted.

		strTemp             = poiInsDataBundle.getString("clientId");
		int poiClientId     = getIntValue(strTemp);

		// We don't pick up the date from the data file
		String format       = "MM.dd.yyyy hh:mm";
		java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat(format);
		String poiDateTime  = sdf.format(new Date());

		POIInsertDriver.clientId      = poiClientId;
		POIInsertDriver.dateTimeStamp = poiDateTime;


		// Since this is an insert we should not be populating the POI id.
		KivPOIKey poiKey       = new KivPOIKey();
		 strTemp            = poiInsDataBundle.getString("poiKey-vendorId");
		poiKey.setVendorId(getIntValue(strTemp));

		// The POI should have atleast one name
		KivPOIName poiName1 = new KivPOIName();
		poiName1.setPoiName(poiInsDataBundle.getString("poiName1-name"));
		poiName1.setLanguage(poiInsDataBundle.getString("poiName1-language"));
		strTemp             = poiInsDataBundle.getString("poiName1-kindOfName");
		poiName1.setKindOfName(getIntValue(strTemp));

		KivPOIName poiName2 = new KivPOIName();
		poiName2.setPoiName(poiInsDataBundle.getString("poiName2-name"));
		poiName2.setLanguage(poiInsDataBundle.getString("poiName2-language"));
		strTemp             = poiInsDataBundle.getString("poiName2-kindOfName");
		poiName2.setKindOfName(getIntValue(strTemp));

		KivPOIName[] poiNames = new KivPOIName[2];
		poiNames[0]           = poiName1;
		poiNames[1]           = poiName2;

		//The address of the POI
		KivPOIAddress poiAddr = new KivPOIAddress();
		poiAddr.setHouseNumber(poiInsDataBundle.getString("poiAddr-houseNum"));
		poiAddr.setStreetName(poiInsDataBundle.getString("poiAddr-streetName"));
		poiAddr.setCity(poiInsDataBundle.getString("poiAddr-city"));
		poiAddr.setAdmin1(poiInsDataBundle.getString("poiAddr-admin1"));
		poiAddr.setAdmin2(poiInsDataBundle.getString("poiAddr-admin2"));
		poiAddr.setCountry(poiInsDataBundle.getString("poiAddr-country"));
		poiAddr.setPostalCode(poiInsDataBundle.getString("poiAddr-postalCode"));

		//Area code of the POI
		strTemp             = poiInsDataBundle.getString("areaCode");
		int poiAreaCode     = getIntValue(strTemp);

		//Phone Number
		strTemp             = poiInsDataBundle.getString("phoneNum");
		int poiPhoneNum     = getIntValue(strTemp);

		//Latitude and Longitude
		strTemp             = poiInsDataBundle.getString("latitude");
		int poiLat          = getIntValue(strTemp);
		strTemp             = poiInsDataBundle.getString("longitude");
		int poiLong         = getIntValue(strTemp);

		//The number of categories to be searched

		 strTemp            = poiInsDataBundle.getString("numOfCategories");
		 int numOfCats      = getIntValue(strTemp);


		int poiCategories[] = new int[numOfCats];
		String catName      = "category";

		 for( int i=0; i<numOfCats; i++)
		 {
		 	strTemp         = poiInsDataBundle.getString(catName + (i+1));
			poiCategories[i]= getIntValue(strTemp);
		 }


		// Supplementary information for the POI
		KivPOISuppInfo poiSuppInfo = new KivPOISuppInfo();

		// The supp info has the same key as the poi record
		poiSuppInfo.setPoiKey(poiKey);

		strTemp                    = poiInsDataBundle.getString("suppInfo-intField1");
		int intField1              = getIntValue(strTemp);
		strTemp                    = poiInsDataBundle.getString("suppInfo-intField2");
		int intField2              = getIntValue(strTemp);
		strTemp                    = poiInsDataBundle.getString("suppInfo-intField3");
		int intField3              = getIntValue(strTemp);
		strTemp                    = poiInsDataBundle.getString("suppInfo-intField4");
		int intField4              = getIntValue(strTemp);
		strTemp                    = poiInsDataBundle.getString("suppInfo-intField5");
		int intField5              = getIntValue(strTemp);
		strTemp                    = poiInsDataBundle.getString("suppInfo-intField6");
		int intField6              = getIntValue(strTemp);
		strTemp                    = poiInsDataBundle.getString("suppInfo-intField7");
		int intField7              = getIntValue(strTemp);
		strTemp                    = poiInsDataBundle.getString("suppInfo-intField8");
		int intField8              = getIntValue(strTemp);
		strTemp                    = poiInsDataBundle.getString("suppInfo-intField9");
		int intField9              = getIntValue(strTemp);
		strTemp                    = poiInsDataBundle.getString("suppInfo-intField10");
		int intField10             = getIntValue(strTemp);

		poiSuppInfo.setIntField1(intField1);
		poiSuppInfo.setIntField2(intField2);
		poiSuppInfo.setIntField3(intField3);
		poiSuppInfo.setIntField4(intField4);
		poiSuppInfo.setIntField5(intField5);
		poiSuppInfo.setIntField6(intField6);
		poiSuppInfo.setIntField7(intField7);
		poiSuppInfo.setIntField8(intField8);
		poiSuppInfo.setIntField9(intField9);
		poiSuppInfo.setIntField10(intField10);
		poiSuppInfo.setTextField1(poiInsDataBundle.getString("suppInfo-textField1"));
		poiSuppInfo.setTextField2(poiInsDataBundle.getString("suppInfo-textField2"));
		poiSuppInfo.setTextField3(poiInsDataBundle.getString("suppInfo-textField3"));
		poiSuppInfo.setTextField4(poiInsDataBundle.getString("suppInfo-textField4"));
		poiSuppInfo.setTextField5(poiInsDataBundle.getString("suppInfo-textField5"));
		poiSuppInfo.setTextField6(poiInsDataBundle.getString("suppInfo-textField6"));
		poiSuppInfo.setTextField7(poiInsDataBundle.getString("suppInfo-textField7"));
		poiSuppInfo.setTextField8(poiInsDataBundle.getString("suppInfo-textField8"));
		poiSuppInfo.setTextField9(poiInsDataBundle.getString("suppInfo-textField9"));
		poiSuppInfo.setTextField10(poiInsDataBundle.getString("suppInfo-textField10"));

		poiSuppInfo.setDateField1(poiInsDataBundle.getString("suppInfo-dateField1"));
		poiSuppInfo.setDateField2(poiInsDataBundle.getString("suppInfo-dateField2"));
		poiSuppInfo.setDateField3(poiInsDataBundle.getString("suppInfo-dateField3"));
		poiSuppInfo.setDateField4(poiInsDataBundle.getString("suppInfo-dateField4"));
		poiSuppInfo.setDateField5(poiInsDataBundle.getString("suppInfo-dateField5"));
		poiSuppInfo.setDateField6(poiInsDataBundle.getString("suppInfo-dateField6"));
		poiSuppInfo.setDateField7(poiInsDataBundle.getString("suppInfo-dateField7"));
		poiSuppInfo.setDateField8(poiInsDataBundle.getString("suppInfo-dateField8"));
		poiSuppInfo.setDateField9(poiInsDataBundle.getString("suppInfo-dateField9"));
		poiSuppInfo.setDateField10(poiInsDataBundle.getString("suppInfo-dateField10"));
		//poiSuppInfo.setBlobField1(poiInsDataBundle.getString("suppInfo-blobField1"));

		// Create the POI object
		KivPOI thePOI       = new KivPOI();

		thePOI.setPoiKey(poiKey);
		thePOI.setPoiNames(poiNames);
		thePOI.setPoiAddress(poiAddr);
		thePOI.setAreaCode(poiAreaCode);
		thePOI.setPhoneNumber(poiPhoneNum);
		thePOI.setLatitude(poiLat);
		thePOI.setLongitude(poiLong);
		thePOI.setCategories(poiCategories);
		thePOI.setSuppInfo(poiSuppInfo);

		return thePOI;
	}


	private static int getIntValue(String strValue)
	{
		int intValue = 0;

		try
		{
			intValue = Integer.parseInt(strValue);
		}
		catch(NumberFormatException e)
		{
			intValue = 0;
		}
		return intValue;
	}

	private static int clientId;
	private static String dateTimeStamp;
}
