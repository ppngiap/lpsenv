#ifndef REVGEO_DEF_H
#define REVGEO_DEF_H

/**
 * The reverse geocoding definitions.
 *
 * @file revgeo_def.h
 *
 * � 2001, Kivera, Inc.  This material is protected by U.S. and
 * international copyright laws and may not be reproduced, modified,
 * distributed, publicly displayed or used to create derivative works
 * without the express written consent of Kivera, Inc.  This copyright
 * notice may not be altered or removed.
 **/

#include "geostd_def.h"


/* lang = language for explication */
typedef struct
{
    int world_long;
    int world_lat;
    int distance;
    char unit;
    int mapDbPref[NW_DB_MAX];
    int flag;
    unsigned char lang[NW_LINE_MAX];
} REVGEO_REQ;

typedef struct
{
    double  distance;
    char    unit;
    short   angle;
    char    direction[NW_DIRECTION_SIZE];
} REVGEO_VECTOR;

typedef struct
{
    GEO_INFO info;
    REVGEO_VECTOR xStreetDist;
    int artery;
    int type;
    int speed;
} REVGEO_INFO;


#endif
