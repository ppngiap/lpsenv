/* 
* (C) Copyright 2000-2004 by Kivera, Inc.  All rights reserved. >>./client/examples/source/nw_calculate_route_ex.c.new
echo * 
* This material is protected by U.S. and international 
* copyright laws and may not be reproduced, modified, 
* distributed, publicly displayed or used to create derivative 
* works without the express written consent of Kivera, Inc.  
* The information contained herein is considered a trade 
* secret as defined in section 499C of the penal code of the 
* State of California. This copyright notice may not be 
* altered or removed. 
* 
*/ 
/******************************************************
 * File: nw_calculate_route_ex.c                      *
 * -------------------------------------------------- *
 * Description:  An example program for exhibiting    *
 *               proper usage of the                  *
 *               nw_calculate_route function.         *
 ******************************************************/

/******************************************************
 *Library Includes                                    *
 ******************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "capis.h"
#include "iso_codes.h"

#ifdef _MSC_VER
#include "win_getopt.h"
#include <WinSock2.h>
#endif

#ifdef LINUX
#include <unistd.h>
#endif
/******************************************************
 * Constant Definitions
 ******************************************************/
#define SRC_ID 0
#define DST_ID 1

/******************************************************
 * Utility function prototypes
 ******************************************************/
/* gets host and port from command-line arguments */
int get_host_and_port(int argc, char *argv[], char **host, int * port);

/* intializes geocoding input/output structures */
int initialize_geocoding( GEO_REQ *request,    GEO_OPTIONS *options,
                          GEO_INFO *info_list, RT_POINT *result);

/* frees resources used in geocoding input/output structures */
int cleanup_geocoding(GEO_REQ *request, GEO_INFO *info,
                      GEO_OPTIONS *options);

/* geocodes an address */
int geocode_point( NWC_CLIENT *handle, int *database_prefs,
                   char *line1, char *line2,
                   char *country, RT_POINT *point);

/* intializes routing input/output structures */
int initialize_routing( RT_REQ *request, RT_OUT *output, int *mapDbPref);

/* prints information about a point */
void dump_point( RT_POINT *point,
                 char     *point_label);

/* prints information about  a route */
void dump_route( char *test_label,
                 RT_REQ *route_request,
                 RT_OUT *route );



/******************************************************
 * Routing example function prototypes
 ******************************************************/

/* Demonstrates simplest use of routing API */
int simple_example( NWC_CLIENT *handle, int      *mapDbPref,
                    RT_POINT   *source, RT_POINT *destination, int avoid_bridge );

/* Demonstrates generation of ESRI shape files */
int shape_file_example( NWC_CLIENT *handle, int      *mapDbPref,
                        RT_POINT   *source, RT_POINT *destination );

/* Demonstrates generation of route URLs */
int url_example( NWC_CLIENT *handle, int      *mapDbPref,
                 RT_POINT   *source, RT_POINT *destination,
                 char *base_url);

/* Demonstrates calling routing API with stopover or via point */
int stopover_or_via_example( NWC_CLIENT *handle,   int      *mapDbPref,
                             RT_POINT   *source,   RT_POINT *destination,
                             RT_POINT   *stopover, int       is_via_point );

/******************************************************
 * Main program
 ******************************************************/
int main(int argc, char *argv[]) {
  

    /******************************************************
     * Declarations
     ******************************************************/
    int status = NW_OK;  /* function return status */

    char *host = NULL;          /* host on which server is running */
    int   port = 0;             /* port on which server running */
    NWC_CLIENT *handle = NULL;  /* server connection handle */
    RT_POINT
        source,           /* route source */
        destination,      /* route destination */
        stopover,         /* route stopover */
        via_point,        /* route via point */
        secondary_source; /* secondary database source */

    CSF_DB server_dbs;   /* information about databases loaded on server */
    
    int primaryDbPref[NW_DB_MAX];          /* for geocoding/routing
                                            * with primary database only */
    int secondaryDbPref[NW_DB_MAX];        /* for geocoding/routing
                                            * with secondary database
                                            * only */
    int primarySecondaryDbPref[NW_DB_MAX]; /* for geocoding/routing on
                                            * primary database if
                                            * possible, then on
                                            * secondary database */


    /**********************************************************************
     * Initialize structures
     **********************************************************************/
    memset(&source,                 0, sizeof(RT_POINT));
    memset(&destination,            0, sizeof(RT_POINT));
    memset(&stopover,               0, sizeof(RT_POINT));
    memset(&via_point,              0, sizeof(RT_POINT));
    memset(primaryDbPref,          0, NW_DB_MAX * sizeof(int));
    memset(secondaryDbPref,        0, NW_DB_MAX * sizeof(int));
    memset(primarySecondaryDbPref, 0, NW_DB_MAX * sizeof(int));

    /**********************************************************************
     * Get host and port command line arguments
     **********************************************************************/
    if (get_host_and_port(argc, argv, &host, &port) == FALSE)
        exit(0);

    /**********************************************************************
     * Initialize client options
     **********************************************************************/
    handle = nwc_init_client_option(UNPROJECTED);

    if ( NULL == handle )
    {
        printf("Error initializing client options\n");
        exit( 1 );
    }

    /**********************************************************************
     * Connect to location server
     **********************************************************************/
    status = nwc_connect(handle, host, (u_short)port);

    if (status < 0)
    {
        printf("Error connecting to server, status = %d\n",
               status);
        exit( 1 );
    }

    /**********************************************************************
     * Get list of databases loaded on location server
     **********************************************************************/
    status = nwc_get_mdb_list(handle, &server_dbs);

    if (NW_OK != status)
    {
        printf("Error getting the server database list, status = %d\n",
               status);
        exit( 1 );
    }

    /**********************************************************************
     * Set up arrays of database preferences
     **********************************************************************/
    if (server_dbs.num < 1)
    {
        printf("Error - no databases available on server\n");
        exit(1);
    }
    else
    {
        primaryDbPref[0] = server_dbs.db[0].id;

        /******************************************************************
         * If more than one database on server, set up database
         * preference array containing only secondary database, and
         * database preference array containing both primary and
         * secondary database.
         ******************************************************************/
        if (server_dbs.num > 1)
        {
            secondaryDbPref[0] = server_dbs.db[1].id;
            primarySecondaryDbPref[0] = server_dbs.db[0].id;
            primarySecondaryDbPref[1] = server_dbs.db[1].id;
        }
    }

    /**********************************************************************
     * Geocode source
     **********************************************************************/
    status = geocode_point( handle,
                            primaryDbPref,
                            "299 Lakeside Dr",
                            "Oakland CA",
                            "USA",
                            &source );

    if (NW_OK != status)
    {
        printf("Error geocoding source, status = %d\n", status);
        exit(1);
    }
    

    /**********************************************************************
     * Geocode destination
     **********************************************************************/
    status = geocode_point( handle,
                            primaryDbPref,
                            "Woz Way",
                            "San Jose, CA",
                            "USA",
                            &destination );
    if (NW_OK != status)
    {
        printf("Error geocoding destination, status = %d\n", status);
        exit(1);
    }
    
    /**********************************************************************
     * Geocode stopover
     **********************************************************************/
    status = geocode_point( handle,
                            primaryDbPref,
                            "45000 fremont blvd",
                            "Fremont CA",
                            "USA",
                            &stopover );
    if (NW_OK != status)
    {
        printf("Error geocoding stopover, status = %d\n", status);
        exit(1);
    }
    
    /**********************************************************************
     * Geocode via point
     **********************************************************************/
    status = geocode_point( handle,
                            primaryDbPref,
                            "",
                            "Half Moon Bay CA",
                            "USA",
                            &via_point );
    if (NW_OK != status)
    {
        printf("Error geocoding via point, status = %d\n", status);
        exit(1);
    }
    
    /**********************************************************************
     * simple routing example
     **********************************************************************/
    printf("\n\n"
           "==============================================================\n"
           "Simple routing example\n"
           "==============================================================\n");
    status = simple_example( handle,
                             primaryDbPref,
                             &source,
                             &destination,
                             0);

    if (NW_OK != status)
    {
        /* --- There is an error --- */
        printf( "simple_example failed, status = %d.\n\n",
                status);
    }


    /**********************************************************************
     * shape file example
     **********************************************************************/
/*
    printf("\n\n"
           "==============================================================\n"
           "Shape file example\n"
           "==============================================================\n");
    status = shape_file_example( handle,
                                 primaryDbPref,
                                 &source,
                                 &destination);

    if (NW_OK != status)
    {
        // --- There is an error --- 
        printf( "shape file example failed, status = %d.\n\n",
                status);
    }

*/


    /**********************************************************************
     * Route URL generation example
     **********************************************************************/

    printf("\n\n"
           "==============================================================\n"
           "Route URL example\n"
           "==============================================================\n");
    status = url_example( handle,
                          primaryDbPref,
                          &source,
                          &destination,
                          "base_url");

    if (NW_OK != status)
    {
        // --- There is an error --- 
        printf( "url_example failed, status = %d.\n\n",
                status);
    }



    /**********************************************************************
     * stopover example
     **********************************************************************/
    printf("\n\n"
           "==============================================================\n"
           "Stopover example\n"
           "==============================================================\n");
    status = stopover_or_via_example( handle,
                                      primaryDbPref,
                                      &source,
                                      &destination,
                                      &stopover,
                                      0);

    if (NW_OK != status)
    {
        /* --- There is an error --- */
        printf( "stopover example failed, status = %d.\n\n",
                status);
    }

    /**********************************************************************
     * via point example
     **********************************************************************/
    printf("\n\n"
           "==============================================================\n"
           "Via point example\n"
           "==============================================================\n");
    status = stopover_or_via_example( handle,
                                      primaryDbPref,
                                      &source,
                                      &destination,
                                      &via_point,
                                      1);

    if (NW_OK != status)
    {
        /* --- There is an error --- */
        printf( "via point example failed, status = %d.\n\n",
                status);
    }

    /**********************************************************************
     * Geocode another database destination
     **********************************************************************/
    status = geocode_point( handle,
                            primaryDbPref,
                            "24 Willie Mays Plaza",
                            "San Francisco CA",
                            "USA",
                            &destination );
    if (NW_OK != status)
    {
        printf("Error geocoding destination for cross database route, status = %d\n", status);
        exit(1);
    }


    /**********************************************************************
     * Routing example with avoid flags.
     *
     * This example will illustrate routing avoiding bridges.
     **********************************************************************/
    printf("\n\n"
           "==============================================================\n"
           "Simple routing example with avoid flag\n"
           "==============================================================\n");
    status = simple_example( handle,
                             primaryDbPref,
                             &source,
                             &destination,
                             1);

    if (NW_OK != status)
    {
        /* --- There is an error --- */
        printf( "simple_example with avoid flag failed, status = %d.\n\n",
                status);
    }





    /**********************************************************************
     * Cross database routing example.
     *
     * Note that the only difference between this example and
     * simple_example is that the source for this route was geocoded
     * to a database other than the one listed first in the array of
     * routing database preferences.  Routing will begin on the
     * non-primary database, and will switch over as soon as possible
     * to the primary database. Needs both primary and secondary databases.
     **********************************************************************/
    if (server_dbs.num > 1)
    {
        /**********************************************************************
         * Geocode secondary database source
         **********************************************************************/
        status = geocode_point( handle,
                                secondaryDbPref,
                                "3 Pine Way",
                                "Donner CA",
                                "USA",
                                &secondary_source );
        if (NW_OK != status)
        {
            printf("Error geocoding origin for cross database route, status = %d\n", status);
            exit(1);
        }
    
    
        printf("\n\n"
               "==============================================================\n"
               "Cross database routing example\n"
               "==============================================================\n");
        status = simple_example( handle,
                                 primarySecondaryDbPref,
                                 &secondary_source,
                                 &destination,
                                 0);

        if (NW_OK != status)
        {
            /* --- There is an error --- */
            printf( "cross database routing example failed, status = %d.\n\n",
                    status);
        }
    }
    
    /* --- Exit Program --- */
    status = nwc_disconnect(handle);

    if (NW_OK != status)
    {
        printf("Error disconnecting from server, status = %d\n", status);
        exit(1);
    }
    
    status = nwc_delete_client_option(handle);

    if (NW_OK != status)
    {
        printf("Error cleaning up client handler, status = %d\n", status);
        exit(1);
    }

    exit ( 0 );
  
}

/******************************************************
 * Print information on how to use this program
 ******************************************************/
void print_usage(char *prog_name)
{
    printf("Usage: %s [-?] -h <host> -p <port>\n"
           "       -? print this message\n"
           "       -h host machine name\n"
           "       -p port number\n\n",
           prog_name);
}

/******************************************************
 * Get host and port command line arguments
 ******************************************************/
int get_host_and_port(int argc, char *argv[], char **host, int * port){

    int helpFlag = FALSE, c;

    while ((c = getopt(argc, argv, "h:p:")) != EOF) {
        switch (c) {
        case 'p':
            /* get the port */
            *port = atoi(optarg);
            break;
        case 'h':
            /* get the host */
            *host = optarg;
            break;
        case '?':
        default:
            /* if unknown argument or "help" flag was specified, turn
             * on the help flag */
            helpFlag = TRUE;
            break;
        }
    }

    /* if host or port was not specified, turn on the help flag */
    if ((*host == NULL) || (*port == 0))
    {
        helpFlag = TRUE;
    }

    if(helpFlag)
    {
        print_usage(argv[0]);
        return FALSE;
    }
    return TRUE;
}

/******************************************************
 * Initialize geocoding input and output structures
 ******************************************************/
int initialize_geocoding(GEO_REQ     *request,   /* input structure */
                         GEO_OPTIONS *options,   /* output options list */
                         GEO_INFO    *info_list, /* output info list */
                         RT_POINT    *result)
{
    int i, j; /* loop control variables */


    /*****************************************************************
     * Validate input
     *****************************************************************/
    if ( (NULL == request) ||
         (NULL == options) ||
         (NULL == info_list) ||
         (NULL == result) )
    {
        return NW_ERROR_INIT;
    }

    /*****************************************************************
     * Clear all input structures
     *****************************************************************/
    memset(request,   0, sizeof(GEO_REQ));
    memset(options,   0, sizeof(GEO_OPTIONS));
    memset(info_list, 0, sizeof(GEO_INFO));
    memset(result,    0, sizeof(RT_POINT));


    /*****************************************************************
     * Allocate memory for list of choices returned by geocoding in
     * case geocoding fails.
     *****************************************************************/
    /* limit choices to 10 */
    options->limit = 10;
    
    /* allocate array for options->limit count of uchar arrays */
    options->list = (unsigned char **) calloc( options->limit,
                                               sizeof( uchar * ) );
    /* make sure that malloc worked */
    if (NULL == options->list)
    {
        printf("malloc failed - unable to create options->list\n");
        return -1;
    }

    /* populate array allocated above with uchar arrays for options */
    for ( i = 0; i < options->limit; i++ ) 
    {
        /* malloc uchar array big enough to hold largest option
           returned by server */
        options->list[i] = (unsigned char *) calloc( NW_LINE_MAX,
                                                     sizeof( uchar ) );
        /* make sure that malloc worked */
        if (NULL == options->list[i])
        {
            printf("malloc failed - unable to create options->list\n");

            /* clean up memory already allocated */
            for (j = i - 1;
                 j >= 0;
                 j--)
            {
                free(options->list[j]);
            }
            free(options->list);
            
            return -1;
        }
    }

    return NW_OK;
}

/**************************************************************************
 * Clean up memory allocated on the heap for geocoding client API calls. 
 **************************************************************************/
int cleanup_geocoding(
    GEO_REQ     *request, /* Geocoding request */
    GEO_INFO    *info,    /* Info about geocoded point returned from
                           * geocoding Client API */
    GEO_OPTIONS *options  /* list of options returned from Client API
                           * if geocoding fails */
    )
{
    int i; /* loop control variable */
    
    /*****************************************************************
     * Validate arguments
     *****************************************************************/
    if ( ( NULL == request ) ||
         ( NULL == info )    ||
         ( NULL == options ) )
    {
        return -1;
    }

    /*****************************************************************
     * Free options list
     *****************************************************************/
    for (i = 0;
         i < options->limit;
         i++)
    {
        if (NULL != options->list[i])
        {
            free(options->list[i]);
        }
    }

    free(options->list);

    return NW_OK;
}

/*****************************************************************
 * Initialize routing API structures
 *****************************************************************/
int initialize_routing(
    RT_REQ   *request,         /* routing input
                                * structure */
    RT_OUT   *output,          /* routing output
                                * structure */
    int      *mapDbPref        /* databases to be used in routing, in
                                * order of preference from most
                                * preferred to least preferred */
    )
{
    int status = 0;  /* for checking error returns */
    int i      = 0;  /* loop control variable */

    /*****************************************************************
     * Validate inputs
     *****************************************************************/
    if ( (NULL == request) ||
         (NULL == output) )
    {
        printf("Invalid arguments to initialize_routing\n");
        return -1;
    }

    /*****************************************************************
     * Initialize input structures
     *****************************************************************/
    memset(request, 0, sizeof(RT_REQ));
    memset(output,  0, sizeof(RT_OUT));

    /*
      Stopovers are always ordered, regardless of the value of
      request->ordered.
    */
    request->ordered = 1;

    /*
      lang2 and unit2 should always be set to 0, because only one
      explication language is supported at this time.  If they are
      non-zero there will still be only one explication language
      produced, but lang2 and unit2 will be validated in the same way
      lang1 and unit1 are.  If you don't memset the request or
      explicitly set these to 0 most likely you will get
      NWC_ERROR_PARAM back, telling you that you have set lang2/unit2
      to bad values.
    */

    request->lang2[0] = '\0';
    //strcpy(request->lang2, KVR_ISO_639_ENGLISH);
    request->unit2   = NW_UNIT_MILE;

    /*************************************************
     * Set default request values
     *************************************************/
    request->output_flags    = NW_RT_SHAPE | NW_RT_EXPL; /* explication
                                                          * and shape
                                                          * output */
    strcpy(request->lang1, KVR_ISO_639_ENGLISH); /* explication in english */
    request->unit1 = NW_UNIT_MILE;               /* route distance in miles */

    /**********************************************************************
     * If max_num_sols and max_extra_links are not set to USE_DEFAULT,
     * the values you pass will be used, even if you pass invalid
     * values.
     *
     * max_num_sols and max_extra_links affect how long the server
     * tries to find a better solution after the first solution is
     * found.  The server will stop searching for solutions when it
     * finds the number of solutions specified by max_num_sols, or
     * when it has explored max_extra_links beyond the first solution,
     * whichever comes first.
     *
     * The server will always try to find at least one solution,
     * regardless of how these values are set.
     **********************************************************************/
    request->max_num_sols    = USE_DEFAULT; 
    request->max_extra_links = USE_DEFAULT;
    
    /**********************************************************************
     * Heap size affects the amount of memory used during route
     * calculation.  If you are using a via point, you should set this
     * to LARGE_HEAP, or else your route may fail.
     **********************************************************************/
    request->heap_size       = DEFAULT_HEAP;
    
    request->time_of_travel  = 0; /* 0 means "now" */

    /******************************************************************
     * Copy database preference array.  Note that if you are keeping
     * your own array of database preferences in memory, you should
     * memset the array before putting in database preferences.
     * Kivera's client code assumes that anything other than 0 is a
     * valid database preference, and that the array of preferences is
     * NW_DB_MAX in length.
     *****************************************************************/
    for (i = 0;
         (i < NW_DB_MAX) && (0 != mapDbPref[i]);
         i++)
    {
        request->mapDbPref[i] = mapDbPref[i];
    }

    /******************************************************************
     * Call Client API to initialize routing output structure.
     *****************************************************************/
    status =  nwc_rt_out_init( output );
    if (NW_OK != status) 
    {
        /* --- An error has occurred --- */
        printf( "RT_OUT structure initialization failed, status = %d\n\n",
                status );
        return status;
    }

    return NW_OK;
}

/******************************************************************
 * Clean up memory allocated on heap by routing API
 *****************************************************************/
int cleanup_routing( RT_REQ *route_request,
                     RT_OUT *route)
{
    int status = NW_OK;

    if ( ( NULL == route_request ) ||
         ( NULL == route ) )
    {
        printf( "Bad arguments to cleanup_routing\n" );
        return -1;
    }

    status = nwc_rt_out_free(route);

    if ( NW_OK != status )
    {
        printf("Error freeing route\n");
    }

    return status;
}

/******************************************************************
 * Geocode a point
 *****************************************************************/
int geocode_point(
    NWC_CLIENT *handle,
    int        *database_prefs,
    char       *line1,           /* first line of address */
    char       *line2,           /* second line of address */
    char       *country,         /* country containing address */
    RT_POINT   *point /* geocoded point, output */
    )
{
    int         status = NW_OK; /* for checking return statuses */
    GEO_REQ     request;        /* geocoding input structure */
    GEO_INFO    info;           /* returned from geocoding -
                                 * information about geocoded point */
    GEO_OPTIONS options;        /* options list returned if geocoding
                                 * cannot resolve address */
    int         i = 0;          /* loop control variable */

    /*********************************************************************
     * Initialize geocoding structures
     *********************************************************************/
    status = initialize_geocoding( &request,
                                   &options,
                                   &info,
                                   point );

    if (NW_OK != status)
    {
        return status;
    }

    /*********************************************************************
     * Copy address to geocoding request
     *********************************************************************/
    strncpy( request.line1,
             line1,
             NW_LINE_MAX );
    strncpy( request.line2,
             line2,
             NW_LINE_MAX );
    strncpy( request.country,
             country,
             NW_LINE_MAX );

    /* line3 is reserved for future use */
    request.line3[0] = '\0';

    /*********************************************************************
     * Copy database preferences to geocoding request
     *********************************************************************/
    for (i = 0;
         ( (i < NW_DB_MAX) && (0 != database_prefs[i]) );
         i++)
    {
        request.mapDbPref[i] = database_prefs[i];
    }

    /*********************************************************************
     * Geocode to 10 feet from road
     *********************************************************************/
    request.offset = 10;
    request.unit   = NW_UNIT_FT;

    /*********************************************************************
     * Call client API to geocode point
     *********************************************************************/
    status = nwc_geocode( handle,
                          &request,
                          &options,
                          &info,
                          point);

    
    /*********************************************************************
     * Clean up memory allocated on heap for API calls.  
     *********************************************************************/
    cleanup_geocoding( &request,
                       &info,
                       &options );

    return status;
}

/************************************************************************
 * A simple routing example.  Calculate a route from a source to a
 * destination without a stopover or via point, and without setting
 * any advanced routing options.
 ************************************************************************/
int simple_example(
    NWC_CLIENT *handle,          /* location server handle */
    int        *database_prefs,  /* routing database preferences */
    RT_POINT   *source,          /* route origin */
    RT_POINT   *destination,     /* route destination */
    int        avoid_bridge      /* Avoid flag for bridges */
    )
{
    int    status = 0;           /* for checking error returns */
    RT_REQ route_request;        /* routing API input structure */
    RT_OUT route;                /* routing API output structure */

    if ( (NULL == source) ||
         (NULL == destination)
        )
    {
        printf("Error in parameters to simple_example\n");
        return -1;
    }

    
    /*********************************************************************
     * Initialize routing structures
     *********************************************************************/
    status = initialize_routing( &route_request,
                                 &route,
                                 database_prefs);
    if (status != NW_OK)
    {
        printf("simple_example: unable to intialize routing structures\n");
        return status;
    }

    /*********************************************************************
     * Set source and destination
     *********************************************************************/
    route_request.src = source;
    route_request.dst = destination;
    if(avoid_bridge)
    {
        route_request.avoid_flags = NW_AVOID_BRIDGES;
    }

    /*********************************************************************
     * Call routing API
     *********************************************************************/
    status = nwc_calculate_route( handle, &route_request, &route);

    if (status < 0)
    {
        printf("simple_example failed, status = %d, message = %s\n",
               status, route.rt_emsg);
        return status;
    }
    else
    {
        dump_route( "simple_example",
                    &route_request,
                    &route );
    }

    cleanup_routing( &route_request, &route );

    return NW_OK;
}


/**************************************************************************
 * Demonstrates how to route with a stopover or via point
 **************************************************************************/
int stopover_or_via_example(
    NWC_CLIENT *handle,         /* location server handle */
    int        *database_prefs, /* preferred routing databases */
    RT_POINT   *source,         /* route origin */
    RT_POINT   *destination,    /* route destination */
    RT_POINT   *stopover,       /* stopover/via point */
    int         is_via_point    /* is point a via point? */
    )
{
    int      status = 0;         /* for checking return values */
    RT_REQ   route_request;      /* input structure to routing client API */
    RT_OUT   route;              /* output structure from routing client API */
    RT_STOP  stopovers[1];       /* array of stopovers */

    if ( (NULL == source) ||
         (NULL == destination) ||
         (NULL == stopover)
        )
    {
        printf("Error in parameters to stopover_or_via_example\n");
        return -1;
    }

    
    /*********************************************************************
     * Initialize routing structures
     *********************************************************************/
    status = initialize_routing( &route_request,
                                 &route,
                                 database_prefs );
    if (status != NW_OK)
    {
        printf("stopover_or_via_example: unable to intialize routing structures\n");
        return status;
    }

    /*********************************************************************
     * Set source and destination
     *********************************************************************/
    route_request.src = source;
    route_request.dst = destination;

    /*********************************************************************
     * Set stopover/via point
     *********************************************************************/
    if (is_via_point)
    {
        /******************************************************************
         * If routing with via point, set heap_size to LARGE_HEAP.
         * The via point causes the route to diverge from the "best
         * cost" path, and may require more memory than routing
         * without a via point.  Setting heap_size to LARGE_HEAP
         * increases the likelihood that an optimal route will be
         * returned when using a via point.
         ******************************************************************/
        route_request.heap_size = LARGE_HEAP;
        stopovers[0].stop_flags = POINT_IS_VIAPOINT;
    }
    else
    {
        stopovers[0].stop_flags = POINT_IS_STOPOVER;
        route_request.ordered   = 1;
    }
    
    stopovers[0].stop_info  = stopover;
    route_request.rt_stops  = stopovers;
    route_request.stops_cnt = 1;

    /*********************************************************************
     * Call routing API
     *********************************************************************/
    status = nwc_calculate_route( handle, &route_request, &route);

    /*********************************************************************
     * Check return status before looking at RT_OUT.
     *********************************************************************/
    if (status < 0)
    {
        printf("stopover_or_via_example failed, status = %d, message = %s\n",
               status, route.rt_emsg);
        return status;
    }
    else
    {
        dump_route( "stopover_or_via_example",
                    &route_request,
                    &route );
    }

    cleanup_routing( &route_request, &route );

    return NW_OK;
}

/************************************************************************
 * Example of how to generate ESRI shape files from a route.
 ************************************************************************/
int shape_file_example(
    NWC_CLIENT *handle,          /* location server connection handle */
    int        *database_prefs,  /* map databases to be routed on */
    RT_POINT   *source,          /* route origin */
    RT_POINT   *destination      /* route destination */
    )
{
    int    status = 0;               /* for checking error return status */
    RT_REQ route_request;            /* routing input structure */
    RT_OUT route;                    /* routing output structure */
#ifndef _MSC_VER
	char   file_name[FILENAME_MAX];  /* shape file name */
#endif
	
    if ( (NULL == source) ||
         (NULL == destination)
        )
    {
        printf("Error in parameters to shape_file_example\n");
        return -1;
    }

#ifndef _MSC_VER
	memset(file_name, 0x0, FILENAME_MAX);
#endif
    
    /*********************************************************************
     * Initialize routing structures
     *********************************************************************/
    status = initialize_routing( &route_request, &route, database_prefs );
    if (status != NW_OK)
    {
        printf("shape_file_example: unable to intialize routing structures\n");
        return status;
    }

    /*********************************************************************
     * Set source and destination
     *********************************************************************/
    route_request.src = source;
    route_request.dst = destination;

    /*********************************************************************
     * Call routing API
     *********************************************************************/
    status = nwc_calculate_route( handle, &route_request, &route);

    if (status < 0)
    {
        printf("shape_file_example failed, status = %d, message = %s\n",
               status, route.rt_emsg);
        return status;
    }
    else
    {
        /*************************************************************
         * Print route information
         *************************************************************/
        dump_route( "shape_file_example",
                    &route_request,
                    &route );

        /*************************************************************
         * Create line shape file - this file contains one entry for
         * every link in the route that contains all of the shape
         * points for that link
         *************************************************************/
#ifndef _MSC_VER
        sprintf((char *) file_name, "%s", "lineshape");
        nw_create_line_shape (&route, file_name);
#endif
 
        /*************************************************************
         * Create point shape file - this file contains one entry for
         * the source, one for each stopover, and one for the
         * destination.
         *************************************************************/
#ifndef _MSC_VER
        sprintf((char *) file_name, "%s", "pointshape");
        nw_create_point_shape(route.rt_pshp, route.rt_ptcnt, file_name);
#endif
    }

    cleanup_routing( &route_request, &route );

    return NW_OK;
}


/************************************************************************
 * Example of how to generate maneuver and overview image URLs for a
 * route
 ************************************************************************/
int url_example(
    NWC_CLIENT *handle,         /* location server handle */
    int        *database_prefs, /* routing database preferences */
    RT_POINT *source,           /* route origin */
    RT_POINT *destination,      /* route destination */
    char     *base_url          /* base URL for image server */
    )
{
    int       status = 0;           /* used to check return status  */
    RT_REQ    route_request;        /* input structure for routing API */
    RT_OUT    route;                /* Route returned from API */
    IMAGE_URL url_request;          /* URL request structure */
                                                  /* Maximum size of URL - limit is
                                     * approx. 1.2k */
    char      url_result[2000]; /* URL returned from API */

    memset(&url_request, 0, sizeof(IMAGE_URL));
    memset(url_result,  0, sizeof(char *));

    if ( (NULL == source) ||
         (NULL == destination) ||
         (NULL == base_url)
        )
    {
        printf("Error in parameters to url_example\n");
        return -1;
    }

    
    /*********************************************************************
     * Initialize routing structures
     *********************************************************************/
    status = initialize_routing( &route_request, &route, database_prefs );
    if (status != NW_OK)
    {
        printf("url_example: unable to intialize routing structures\n");
        return status;
    }

    /*********************************************************************
     * Set source and destination
     *********************************************************************/
    route_request.src = source;
    route_request.dst = destination;

    /*********************************************************************
     * Call routing API
     *********************************************************************/
    status = nwc_calculate_route( handle, &route_request, &route);

    if (status < 0)
    {
        printf("url_example failed, status = %d, message = %s\n",
               status, route.rt_emsg);
        return status;
    }
    else
    {
        dump_route( "url_example",
                    &route_request,
                    &route );

        url_request.zoom       = 1;
        url_request.height     = 400;
        url_request.width      = 400;
        url_request.manv_index = 0;
        url_request.format     = 1;
        url_request.base_url   = base_url;
        url_request.route      = &route;	
        url_request.point      = source;
        
        /*********************************************************************
         * Request URL for 400x400 image at zoom level 1, starting at
         * source.
         *********************************************************************/
        status = nwc_gen_point_url(  handle,
                                     &url_request,
                                     1000000,
                                     url_result );

        if (NW_OK != status)
        {
            printf( "ERROR - Source URL generation failed, status = %d\n\n",
                    status );
            return status;
        }
        else
        {
           printf("\n\n"
               "==============================================================\n"
               "URL for the starting point of the route.\n"
               "==============================================================\n");
            printf("%s\n", url_result);
        }

        
        /*********************************************************************
         * Request URL for 400x400 image containing entire route.
         * Image will be generated at the closest zoom level that can
         * display the entire route at the requested size.
         *********************************************************************/
        status = nwc_gen_route_url( handle, &url_request, 1000000, url_result );
        
        if (NW_OK != status)
        {
            printf( "ERROR - Route URL generation failed, status = %d\n\n",
                    status );
            return status;
        }
        else
        {
           printf("\n\n"
               "==============================================================\n"
               "URL for the entire route.\n"
               "==============================================================\n");
            printf("%s\n", url_result);
        }

        url_request.manv_index = 1;
        status = nwc_gen_route_url( handle, &url_request, 1000000, url_result );
        
        if (NW_OK != status)
        {
            printf( "ERROR - Route URL generation failed, status = %d\n\n",
                    status );
            return status;
        }
        else
        {
           printf("\n\n"
               "==============================================================\n"
               "URL for the first manuever of the route.\n"
               "==============================================================\n");
            printf("%s\n", url_result);
        }
        
    }

    cleanup_routing( & route_request, &route );

    return NW_OK;
}


/**************************************************************************
 * Dump information about a route point (source, destination,
 * stopover, via point)
 **************************************************************************/
void dump_point( RT_POINT *point,
                 char     *point_label)
{
    printf( "%s: cell %x, link %d, street %s\n",
            point_label,
            point->vmapID.mapID,
            point->link,
            point->street );
}
    

/**************************************************************************
 * Dump information about a route
 **************************************************************************/
void dump_route( char *test_label,
                 RT_REQ *route_request,
                 RT_OUT *route )
{
    int   maneuver = 0;
    char *stop_label = NULL;
    float latitude, longitude;
    
    printf( "Results for test %s\n", test_label );

    /*****************************************************************
     * Print info about source and destination
     *****************************************************************/
    
    dump_point(route_request->src, "Route origin" );
    dump_point(route_request->dst, "Route destination");

    /*****************************************************************
     * If route had a stopover or a via point, print info about it
     *****************************************************************/
    if ( route_request->stops_cnt > 0 )
    {
        if ( POINT_IS_STOPOVER == (POINT_IS_STOPOVER &
                                   route_request->rt_stops[0].stop_flags) )
        {
            stop_label = "Stopover";
        }
        else
        {
            stop_label = "Via point";
        }
        dump_point( route_request->rt_stops[0].stop_info, stop_label );
    }

    /*****************************************************************
     * If we requested explication, print it out.
     *
     * The line of explication in each route->rt_manv[maneuver].text1
     * is in the language specified by request->lang1, and uses the
     * units of measure specified by request->unit1.
     *****************************************************************/
    if (NW_RT_EXPL == (NW_RT_EXPL & route_request->output_flags))
    {
        printf("Directions for route\n");
        printf("--------------------\n");
        printf("count: (lat, long) text\n");

        /* There are rt_mcnt maneuvers in the route */
        for ( maneuver = 0;
              maneuver < route->rt_mcnt;
              maneuver++ )
        {
            /* convert latitude and longitude from world coordinates */
            latitude  =
                (float)((route->rt_manv[maneuver].world_lat)  / NW_DEG2WORLD);
            longitude =
                (float)((route->rt_manv[maneuver].world_long) / NW_DEG2WORLD);
            
            printf(
                "%4d: (%4.5f, %4.5f) %s\n",
                maneuver,
                latitude,
                longitude,
                route->rt_manv[maneuver].text ); 
        }
    }
    else
    {
        printf("No explication requested\n");
    }
}
