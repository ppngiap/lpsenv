#! /bin/sh

/bin/ln -s ../OriginalDistribution/*.jar .
